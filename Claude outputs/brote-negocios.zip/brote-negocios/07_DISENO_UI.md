# 07 · Diseño de interfaz

> **Vinculante.** Se lee junto con `BROTE_DESIGN_SYSTEM.md` del repo, que manda en todo
> lo que no esté acá. Este documento resuelve lo único que ese archivo no cubre: cómo se
> ve Brote cuando el usuario **no** es una persona jugando, sino una empresa trabajando.

---

## 1. El problema de diseño

Pediste calidad Apple con utilidad de Amazon o Mercado Libre, sin salirte del estilo de
Brote. Esas tres cosas tiran para lados distintos:

- **Apple** = una decisión por pantalla, aire, jerarquía brutal, cero ruido.
- **Amazon / MELI** = densidad, comparabilidad, filtros, el dato a mano.
- **Brote / "Bitácora Viva"** = terminal de campo, hairlines, editorial, una gradiente
  ganada, movimiento en todo.

**Se resuelven así: son tres superficies distintas y cada una toma lo que le sirve.**

| Superficie | Toma de | Se siente como |
|---|---|---|
| **Mercado** (catálogo) | Densidad de MELI + tipografía y hairlines de Bitácora Viva | Un catálogo serio, no un e-commerce ni una revista |
| **Ficha de listado** | Jerarquía de Apple: una decisión, un botón | Una página de producto que respeta al lector |
| **Negocio** (workspace) | Terminal financiera: tabular, denso, monocromo salvo el dato | Un panel de gestión, no una app de hábitos |

Y una regla que las une: **Bitácora Viva ya dice que la voz de Brote es una terminal
financiera aplicada al ambiente.** El espacio de negocio no es una excepción al estilo:
es el lugar donde ese estilo por fin es literal. Esa continuidad es lo que hace que no
parezca otra app pegada con cinta.

---

## 2. Reglas que se heredan sin cambios

Del `BROTE_DESIGN_SYSTEM.md`, valen igual acá:

- **Gradiente de marca solo en el titular principal, el número clave y el CTA
  primario.** Una vez por pantalla. En el espacio de negocio, **todavía menos**: solo
  en la métrica principal del resumen.
- **Emoji nunca como ícono funcional.** `lucide-react` siempre. En el espacio de negocio
  **tampoco en el copy**: la voz de Pip no entra acá.
- **Hairlines antes que cajas.** `divide-y divide-border` con padding generoso.
  `<Card>` solo para objetos genuinamente distintos.
- **Movimiento obligatorio.** `<Reveal>`, `<CountUp>`, `<ChipRail>`, hover en todo lo
  clickeable, `<Skeleton>` en vez de spinner, `active:scale-[0.97]`.
- **Micro-etiquetas** en mayúscula, `text-[11px] font-semibold uppercase tracking-[0.1em]`,
  arriba de cada titular y cada grupo de filas.
- **Colores de dominio** son identidad: los 13 mantienen su hex en tags, puntos y chips.
- **Nunca un número inventado.** Todo `<CountUp>` traza a un dato real.
- **Un solo `.leaf-clip` por página, como máximo.**

### 2.1 Las tres trampas que el repo ya pisó

Documentadas en `BROTE_DESIGN_SYSTEM.md` y en el plan. **No las repitas:**

1. **Animación de entrada que arranca en `opacity: 0`.** Si el frame loop está
   estrangulado, el elemento queda invisible para siempre. Le pasó dos veces al proyecto
   (CountUp y NewsNudge). Regla: **todo elemento crítico se renderiza visible y anima
   desde ahí**, o no anima.
2. **Clase de Tailwind que no existe en la paleta.** `bg-brote-aqua` estaba referenciada
   y no definida: el estado activo era invisible. Antes de usar un token, verificalo en
   `tailwind.config.ts`.
3. **`<ProgressBar>` toma `0..1`, no un porcentaje.** Dos llamadas del repo pasaron 0-100
   y las barras vivieron al 100%. Hay muchas barras de progreso en este trabajo:
   **revisá cada llamada.**

---

## 3. El shell de negocio

### 3.1 Qué NO tiene

Es la mitad del diseño, y es la parte que pediste explícitamente:

- ❌ `BottomTabBar` — es una barra de app de hábitos.
- ❌ El FAB de Pip y el chat.
- ❌ Mundo 3D, racha, puntos, rango, liga, confeti, `RewardLayer`.
- ❌ Publicidad de ningún tipo.
- ❌ Emoji en cualquier control o encabezado.
- ❌ Celebraciones. Cerrar un objetivo muestra una **confirmación**, no una fiesta.

### 3.2 Qué sí tiene

```
┌─────────────────────────────────────────────────────────────────┐
│ 🌱 Brote        [Panadería del Sur ▾]              [avatar ▾]  │ ← 56px, hairline abajo
├──────────────┬──────────────────────────────────────────────────┤
│              │                                                  │
│ Resumen      │  MEJORA · PROGRAMA                               │ ← eyebrow
│ Mejora     ● │  Tus objetivos                                   │ ← display-l
│ Listados     │                                                  │
│ Analítica    │  ─────────────────────────────────────────────   │
│ Verificación │  hairline + filas densas, py-3                   │
│ Equipo       │                                                  │
│ Plan         │                                                  │
│              │                                                  │
│ ──────────── │                                                  │
│ NIVEL 2      │                                                  │
│ Documentado  │                                                  │
└──────────────┴──────────────────────────────────────────────────┘
```

- **Barra lateral 220px** en ≥1024px; en móvil colapsa a una fila de tabs superior con
  scroll horizontal, usando el `<ChipRail>` que ya existe.
- **Selector de negocio** en la barra superior: nombre + chevron. Al abrir muestra los
  negocios del usuario, "Tu cuenta personal" y "Crear un negocio".
- **Chip de nivel** fijo al pie de la barra lateral. Siempre visible: es el indicador
  que todo el sistema orbita.
- **Fondo:** el canvas crema/tinta de siempre. **Nunca** el gris `#F3F4F6` de plantilla
  de dashboard — está prohibido explícitamente en el sistema de diseño.

### 3.3 Densidad

Es una pantalla **operativa**, y el sistema de diseño ya dice qué hacer con esas:
hairlines y hover-reveal con padding de fila `py-2`–`py-3`, no padding de tarjeta. Las
tablas se estilan: encabezado, hover de fila, indicador de orden. Nunca un `<table>` sin
estilar.

---

## 4. Pantalla por pantalla

### 4.1 `/negocio` — Resumen

Una franja de estado y tres bloques. Nada más.

```
NEGOCIO · PANADERÍA DEL SUR
Nivel 2 · Documentado                          [Cómo subir a Nivel 3 →]
────────────────────────────────────────────────────────────────────────
  3            2/3            847            12
  OBJETIVOS    LISTADOS       VISITAS 30D    SALIDAS 30D
────────────────────────────────────────────────────────────────────────
```

- La franja de números es el **`<PulseStrip>` en tinta oscura** que ya existe en
  Explorar. Es exactamente el momento "terminal en vivo" que el sistema de diseño
  reserva para datos reales, y acá son todos reales. `<CountUp>` en los cuatro.
- **Una sola vez** por pantalla, como manda la regla del strip oscuro.
- Debajo: "Lo próximo" (máximo 3 acciones concretas, hairlines), "Tus objetivos"
  (las 3 filas activas) y "Tus listados" (las 3 con más salidas).
- La gradiente de marca aparece **una sola vez**: en el número más importante.

### 4.2 `/negocio/alta` — Alta en 5 pasos

- Barra de progreso finita arriba, `1 de 5`. Un paso por pantalla.
- **Nada de "wizard con 30 campos".** Cada paso cabe sin scroll en un móvil.
- Autoguardado en cada cambio de paso, con la leyenda *"Guardado"* discreta.
- Paso 3 (descripción) es un `<Textarea>` grande con placeholder guía y **chips que
  inyectan preguntas** debajo si el texto es corto. Esos chips son la diferencia entre
  un dossier pobre y uno bueno, y por lo tanto entre objetivos malos y buenos.
- Al enviar: una pantalla de espera honesta.

> *"Listo. Lo estamos revisando."*
> *"Vamos a mirar tu solicitud y te avisamos acá mismo. Suele tardar menos de 48 horas.
> Mientras tanto podés ir completando la verificación de tu sitio — eso acelera todo."*

### 4.3 `/negocio/verificacion`

Los métodos como filas con hairline, ordenados de más fuerte a más liviano, cada uno
con su chip de fuerza (`Fuerte` / `Media`).

```
MÉTODO RECOMENDADO
Etiqueta en tu sitio                                        [Fuerte]
Pegá esta línea dentro del <head> de tu página principal.

  <meta name="brote-site-verification" content="brote-verify-a7f3k2m9x1c4">
  [Copiar]

  [Ya la pegué, verificá]           Último intento: hace 3 minutos
  ✗ Entramos a tu sitio pero no encontramos la etiqueta.
    Fijate que esté dentro del <head> y que hayas publicado los cambios.
```

**El error es humano y accionable, siempre.** Es literalmente el punto F15.5 del
backlog del repo ("cero mensajes técnicos al usuario"): nunca "fetch failed", nunca un
código HTTP.

### 4.4 `/negocio/mejora` — El programa

La pantalla más importante del lado empresa.

```
MEJORA
Tu programa                                    [Ver dossier] [+ Objetivo]

  PROGRESO DE MEJORA
  ████████████░░░░░░░░  62 / 100
  4 ciclos cerrados con evidencia. El próximo cierre te acerca al Nivel 4.

  ACTIVOS · 3 de 3
  ─────────────────────────────────────────────────────────────────────
  ENERGÍA · TRIMESTRAL · VENCE EN 34 DÍAS          Intermedio · 3 h/mes
  Bajar 8% el consumo eléctrico del salón
  1.240 → 1.141 kWh/mes                    ●───────────────  38%
  ─────────────────────────────────────────────────────────────────────
  RESIDUOS · TRIMESTRAL · EN RIESGO                  Básico · 2 h/mes
  Separar cartón y vidrio del residuo mixto
  6 → 5 bolsas/semana                      ●──────           12%
  ─────────────────────────────────────────────────────────────────────

  CERRADOS
  ─────────────────────────────────────────────────────────────────────
  ✓ Medir el consumo eléctrico mensual         Logrado · marzo 2026
  ✓ Cambiar a proveedor de harina local        Parcial · enero 2026
```

- Cada fila tiene su **eyebrow** con dominio, horizonte y estado; su título; su
  **antes → después** con unidad; y su barra.
- Chips de **ambición** y **esfuerzo/mes** a la derecha. El esfuerzo se muestra siempre
  porque es la promesa del producto: *esto no te va a comer el día*.
- **`en riesgo` en ámbar, no en rojo.** No es un fracaso, es un aviso. El rojo se reserva
  para lo que ya venció.
- Sin puntos, sin insignias, sin celebración. Un tilde y una fecha.

### 4.5 `/negocio/mejora/[goalId]` — Ficha de objetivo

Layout de dos columnas en escritorio, apiladas en móvil.

**Izquierda (el objetivo):** título; *"Por qué esto"*; métrica con antes/ahora/meta;
método de medición; pasos como checklist real (se tildan y se guardan); qué evidencia
hace falta; *"Si no llegás"* en tono sobrio.

**Derecha (la conversación):**

```
AJUSTAR
¿Algo no cierra? Contame y lo ajustamos.

[ No llego a ese número ] [ Esto ya lo hacemos ]
[ No aplica a mi negocio ] [ Necesito más tiempo ]

┌────────────────────────────────────────────────┐
│                                                │
└────────────────────────────────────────────────┘
                                      [Enviar]

HISTORIAL
─────────────────────────────────────────────────
Versión 2 · hace 12 días
Dijiste: "No llego a 1.141, con suerte llego a 1.180."
Ajuste: extendimos el horizonte a semestral y mantuvimos
la meta. Preferimos darte más tiempo antes que bajar
el número.                                [Ver versión 1]
```

**El historial visible es el diseño.** Es lo que convierte esto de "una IA me tiró unas
metas" a "tengo un programa con seguimiento". Es lo que se le muestra a un cliente que
pregunta si vale la pena pagar.

### 4.6 `/negocio/listados/nuevo` — El formulario de listado

El punto donde se hace imposible el greenwashing, y tiene que sentirse **cómodo**, no
policial.

- Pasos: básicos → imágenes → destino → **afirmaciones**.
- En afirmaciones: un `<ChipRail>` con los 16 tipos. Al elegir uno, **aparecen los campos
  de ese tipo**, con su explicación breve al lado.

```
AFIRMACIONES AMBIENTALES
Elegí qué querés afirmar de este producto. Cada una tiene su propio nivel
de evidencia — no hace falta que tengas certificaciones para empezar.

[Orgánico] [Reciclable] [Contenido reciclado] [Compostable] ...

  ── Contenido reciclado ─────────────────────────────── Nivel 1 ──
  ¿Qué parte del producto?     [ el envase                      ]
  ¿Qué porcentaje?             [ 80 ] %
  ¿Tenés cómo respaldarlo?     [ Subir ficha técnica ]  → sube a Nivel 2

  Así se va a ver:
  "Envase con 80% de contenido reciclado · Declarado por el comercio"
```

Tres decisiones de diseño que importan:

1. **La vista previa en vivo.** La empresa ve exactamente qué va a leer el usuario,
   incluida la etiqueta de nivel. Nadie se sorprende después.
2. **El camino a subir de nivel está a la vista.** *"→ sube a Nivel 2"* al lado del
   botón de subir archivo. La escalera se enseña sola.
3. **Nunca un campo de texto libre para la afirmación.** No hay dónde escribir "es
   ecológico". Ese es todo el mecanismo.

### 4.7 `/mercado` — El catálogo

Acá entra la densidad de MELI, filtrada por Bitácora Viva.

```
MERCADO
Comprale a quien lo hace bien                    ← hero, gradiente, UNA vez

[Todo] [Alimentos] [Almacén a granel] [Limpieza] [Cuidado personal] ...   ← ChipRail
Nivel mínimo: [Todos ▾]   Zona: [Online + CABA ▾]   Orden: [Recomendados ▾]

┌──────────┐ ┌──────────┐ ┌──────────┐
│  imagen  │ │  imagen  │ │  imagen  │
│──────────│ │──────────│ │──────────│
│ NIVEL 3  │ │ NIVEL 1  │ │ NIVEL 2  │   ← chip de nivel, color por nivel
│ Harina   │ │ Jabón    │ │ Café de  │
│ orgánica │ │ sólido   │ │ especial.│
│ Molino…  │ │ Taller…  │ │ Tostad…  │   ← negocio, atenuado
│ $ 4.200  │ │ $ 2.800  │ │ $ 9.500  │   ← "precio de referencia"
└──────────┘ └──────────┘ └──────────┘
```

- Grilla de 2 columnas en móvil, 3 en tablet, 4 en escritorio.
- **El nivel siempre visible en la tarjeta.** No se esconde el E1 — se etiqueta.
- **Colores de nivel** (nuevos tokens en `tailwind.config.ts`, no reciclar los de
  dominio):
  - Nivel 1 · `#8A8F98` gris pizarra — neutro, honesto, no alarmante
  - Nivel 2 · `#2DB4D4` el cian de agua — hay documentación
  - Nivel 3 · `#0E7A52` el verde profundo de la marca — certificado
  - Nivel 4 · el gradiente de marca en el borde, no en el relleno
- Scroll infinito por cursor, con `<Skeleton>` (no spinner) y `<BackToTop>`, que ya
  existe.
- **Nada de AdSense en `/mercado`.**

### 4.8 `/mercado/[slug]` — Ficha de listado

Jerarquía Apple: **una decisión**.

```
                    ┌───────────────────────┐
                    │                       │
                    │   imagen grande       │   ← .leaf-clip, la única de la página
                    │                       │
                    └───────────────────────┘

MOLINO DEL VALLE · NIVEL 3 · CERTIFICADO
Harina orgánica de trigo, 1 kg               ← text-hero, gradiente

Precio de referencia informado por el comercio
$ 4.200

        [  Ver en el sitio de Molino del Valle  ]     ← pill, gradiente, único CTA

────────────────────────────────────────────────────────────────
QUÉ AFIRMA ESTE PRODUCTO
────────────────────────────────────────────────────────────────
Orgánico                                              NIVEL 3
Trigo certificado por [certificadora], cert. Nº 12345,
vigente hasta 03/2027.
────────────────────────────────────────────────────────────────
Envase reciclable                                     NIVEL 1
Papel kraft. Reciclable donde haya recolección de papel.
Declarado por el comercio, sin verificar.
────────────────────────────────────────────────────────────────

Sobre el nivel de evidencia →        Reportar este listado →
```

**Lo más importante de esta pantalla:** las dos afirmaciones muestran **niveles
distintos en el mismo producto**. Ahí se ve, de un vistazo, que el sistema es honesto y
que la certificación de un insumo no tiñe todo lo demás. Es la regla antihalo hecha
interfaz, y es lo que hace que un usuario confíe en el catálogo entero.

### 4.9 `/mercado/salir/[id]` — La salida

Hoja modal, no página completa. Medio segundo de lectura.

```
        Estás saliendo de Brote

        Vas a ir a molinodelvalle.com.ar

        La compra, el precio, el envío y la atención son
        responsabilidad de Molino del Valle. Brote no vende
        ni interviene en la operación.

        [ Ir al sitio ]        [ Volver ]

        [ ] No me lo muestres más para este comercio
```

A partir de la tercera vez en 30 días, se reduce a un toast y la redirección es
inmediata. **La fricción tiene que enseñar una vez, no molestar siempre.**

### 4.10 `/panel/negocios/[id]` — Revisión

Diseñada para **menos de 2 minutos**. Todo lo decisivo arriba del pliegue.

```
Panadería del Sur · Gastronomía · Vicente López · 2-10 personas
Solicitud de hace 6 horas

┌─────────────────────────────────────────────────────────────┐
│  IA · 78/100 · APROBAR CON OBSERVACIONES                    │
│  "Panadería real y verificada por dominio; la descripción   │
│   de actividad es breve pero alcanza para armar objetivos."  │
│                                                             │
│  [descripcion_vaga]                                         │
└─────────────────────────────────────────────────────────────┘

Verificación:  ✓ Dominio (etiqueta) · Fuerte · hace 2 h
Sitio:         ✓ responde 200 · panaderiadelsur.com.ar ↗
CUIT:          30-71234567-8 · dígito verificador válido · declarado
Duplicado:     no

QUÉ HACEN, EN SUS PALABRAS
"Somos una panadería de barrio, hacemos pan de masa madre..."

[ Aprobar ]  [ Pedir más datos ]  [ Rechazar ]
Nota para el negocio: [                                        ]
```

Atajos de teclado: `A` aprobar, `P` pedir datos, `R` rechazar, `J`/`K` navegar la cola.
Con volumen alto es la diferencia entre 2 minutos y 20 segundos.

---

## 5. Tokens nuevos

En `tailwind.config.ts`, junto a los existentes:

```ts
colors: {
  nivel: {
    1: '#8A8F98',   // gris pizarra — declarado
    2: '#2DB4D4',   // cian — documentado (mismo hex que el dominio agua, a propósito:
                    // el cian ya significa "verificable" en el lenguaje visual de Brote)
    3: '#0E7A52',   // verde profundo — certificado
  },
},
```

El Nivel 4 no tiene color propio: usa `bg-brand-gradient` **en el borde**, nunca en el
relleno. Es el único lugar del espacio de negocio donde la gradiente aparece dos veces,
y se lo gana.

**Nada más.** Cero radios nuevos, cero sombras nuevas, cero fuentes nuevas.

---

## 6. Movimiento en el espacio de negocio

Se mantiene, pero **más sobrio**. Bitácora Viva dice que nada se rompe de golpe, y eso
vale acá también:

| Elemento | Movimiento |
|---|---|
| Filas de objetivos y listados | `<Reveal index={i}>` — escalonado 60ms |
| Todo número | `<CountUp>` |
| Barras de progreso | Animan al valor en 400ms |
| Cambio de sección | `<SectionTabs>` con el subrayado deslizante |
| Carga | `<Skeleton>` — jamás un spinner |
| Aprobación de un objetivo | Cambio de estado con `duration-base`. **Sin confeti** |
| Cierre de objetivo | Un tilde que se dibuja en 300ms y una fecha. Nada más |

**El contraste es intencional.** Que en la app de personas cerrar algo dispare confeti y
acá dispare un tilde es lo que le dice al usuario, sin palabras, que está en otro lugar.

---

## 7. Accesibilidad

Lo que el repo ya sostiene y no se relaja:

- Foco visible AA en todo control (`focus-visible` ya está en `globals.css`).
- Contraste AA en el texto, AAA en los números de las franjas oscuras.
- **El nivel nunca se comunica solo por color.** Siempre color **+** el número **+**
  la palabra ("Nivel 3 · Certificado"). Con daltonismo el catálogo tiene que seguir
  siendo legible.
- `prefers-reduced-motion` respetado (ya está en `globals.css`).
- Toda tabla con `<caption>` accesible y encabezados asociados.
- Los atajos del panel de revisión no capturan teclas si el foco está en un input.

---

## 8. Móvil

Todo funciona a 360px. Específicamente:

- La barra lateral del negocio se vuelve tabs con scroll horizontal.
- La ficha de objetivo apila: objetivo arriba, conversación abajo.
- El catálogo va a 2 columnas.
- El formulario de listado: un paso por pantalla, con la vista previa colapsable.
- La cola de revisión de `/panel` es usable en móvil, aunque esté pensada para
  escritorio: **vas a querer aprobar una empresa desde el teléfono**.
