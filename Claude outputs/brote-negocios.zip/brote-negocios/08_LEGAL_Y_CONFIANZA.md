# 08 · Legal y confianza

> **Advertencia.** No soy abogado y esto no es asesoramiento legal. Es un diseño de
> producto construido sobre el texto de las normas citadas, pensado para minimizar
> exposición. **Antes de cobrarle a la primera empresa, hacé revisar los términos por un
> abogado argentino de consumo.** Es barato comparado con una sanción de Lealtad
> Comercial, y `09_MONETIZACION.md` lo presupuesta.

---

## 1. La pregunta que hay que responder bien

Si un usuario compra por un enlace de Brote y el producto no era lo que decía, **¿Brote
responde?**

La respuesta depende de si Brote está dentro de la **cadena de comercialización**. Todo
el diseño del producto existe para que la respuesta sea "no", y —más importante— para
que sea **demostrable**.

---

## 2. Ley 24.240, artículo 40

> *"Si el daño al consumidor resulta del vicio o riesgo de la cosa o de la prestación
> del servicio, responderán el productor, el fabricante, el importador, el distribuidor,
> el proveedor, el vendedor y **quien haya puesto su marca en la cosa o servicio**. […]
> La responsabilidad es solidaria […]. Sólo se liberará total o parcialmente quien
> demuestre que la causa del daño le ha sido ajena."*

### 2.1 Lo obvio

No producimos, no fabricamos, no importamos, no distribuimos y no vendemos. Fuera de
esas seis categorías.

### 2.2 Lo que casi todos pasan por alto

**"Quien haya puesto su marca en la cosa o servicio" responde igual.**

Un badge que diga *"Producto ecológico verificado por Brote"* sobre un listado ajeno es
exactamente la situación que ese pasaje describe. Y la única salida del art. 40 es
probar **causa ajena**: que el daño vino de una esfera que no controlábamos.

### 2.3 La regla de redacción, sin excepciones

**El badge describe nuestro proceso y el nivel de prueba. Nunca la calidad del
producto.**

| ❌ Prohibido | ✅ Correcto |
|---|---|
| "Producto ecológico verificado por Brote" | "Nivel 3 · Certificación de tercero vigente" |
| "Garantía Brote" | "Nivel 2 · Documentación revisada por Brote" |
| "Aprobado por Brote" | "Nivel 1 · Declarado por el comercio, sin verificar" |
| "Certificado eco" | "Certificado por [certificadora], Nº 12345, vigente hasta 03/2027" |
| "El mejor producto orgánico" | "Orgánico · certificación de tercero presentada" |

Fijate en la diferencia gramatical: la columna correcta describe **un documento y un
estado de revisión**, no una propiedad del producto. Un certificado vigente es un hecho
verificable sobre un papel. "Producto ecológico" es una afirmación sobre una cosa.

> **Chequeo para el revisor y para cada componente:** ¿el badge podría ser falso aunque
> el documento sea auténtico? Si la respuesta es sí, está mal redactado.

Esto vale en **todo** lugar donde aparezca un nivel: tarjeta del catálogo, ficha,
página del negocio, notificaciones, emails, capturas de marketing, redes.

---

## 3. Las nueve separaciones operativas

Lo que sostiene la causa ajena no es una cláusula: es que la plataforma **realmente no
puede** intervenir. Todas son verificables mirando el código.

1. **No hay carrito ni checkout.** No existe la ruta.
2. **No cobramos al consumidor.** Ni un centavo pasa por nosotros. Solo cobramos la
   suscripción **a la empresa**, por el servicio de estar en la plataforma.
3. **No manejamos stock.** No hay campo de stock.
4. **No manejamos envíos.** No hay dirección de entrega en ningún lado.
5. **El precio es de referencia** y se etiqueta literalmente
   *"precio de referencia informado por el comercio"*. **Nunca "precio".**
6. **La descripción es de la empresa y se atribuye.** Brote no reescribe el texto
   comercial. La IA puede sugerirle a la empresa una redacción; el texto publicado es el
   que la empresa aprobó.
7. **Toda salida pasa por el interstitial**, con el aviso de §4.
8. **No hay atención al cliente por producto.** Los reportes son sobre el *listado*
   dentro de Brote, no sobre la compra.
9. **No damos puntos por comprar.** Ni uno. Además de proteger la marca, evita que se
   argumente que incentivamos la transacción.

---

## 4. Textos legales, literales

### 4.1 Interstitial de salida

> **Estás saliendo de Brote**
>
> Vas a ir a **{dominio}**.
>
> La compra, el precio, el envío y la atención al cliente son responsabilidad de
> **{nombre del comercio}**. Brote no vende, no cobra ni interviene en la operación.

### 4.2 Etiquetas de nivel — texto exacto

| Nivel | Etiqueta corta | Explicación |
|---|---|---|
| 1 | **Declarado por el comercio** | "El comercio afirma esto. Brote no verificó documentación de respaldo." |
| 2 | **Documentación revisada** | "El comercio presentó documentación de respaldo y Brote la revisó. No es una certificación de tercero." |
| 3 | **Certificación de tercero** | "Hay una certificación de un organismo externo, con número y vigencia. Brote verificó que el certificado exista y esté vigente; no realizó la certificación." |
| 4 | **Referente** | "Certificación de tercero vigente y un historial de mejora verificado por Brote a lo largo del tiempo." |

Cada etiqueta linkea a `/legal/niveles`, una página pública que explica la escalera
completa. **Que sea pública y explícita es parte de la defensa:** nadie puede decir que
el nivel lo confundió.

### 4.3 Pie de la ficha de listado

> Brote es una plataforma de difusión. Los datos, imágenes, precios y afirmaciones de
> este listado fueron provistos por **{comercio}**, que es responsable por ellos.
> El nivel de evidencia indica qué documentación revisó Brote, no una garantía sobre el
> producto. [Cómo funcionan los niveles →] · [Reportar este listado →]

### 4.4 Cabecera de `/mercado`

> **Qué es esto**
> Un catálogo de productos y servicios de negocios que están en el programa de Brote.
> No vendemos: cuando toques un producto vas al sitio del comercio. Cada afirmación
> ambiental tiene un nivel según la documentación que presentaron.
> [Cómo lo revisamos →]

---

## 5. Decreto 274/2019 — Lealtad Comercial

### 5.1 Lo que dice y lo que nos obliga

- **Art. 11** prohíbe toda presentación o publicidad que *"mediante inexactitudes u
  ocultamientos"* pueda inducir a error sobre características, origen, calidad, cantidad,
  precio o técnicas de producción.
- **Art. 10.a** define como competencia desleal inducir a error sobre atributos,
  beneficios o condiciones de bienes y servicios.
- **Art. 21** responsabiliza a fabricantes, productores, envasadores, importadores y
  fraccionadores por los rótulos — y **al comerciante si no puede aportar la
  documentación que identifique al verdadero fabricante o importador**.
- **Art. 57** prevé apercibimiento, multas de 1 a 10 millones de Unidades Móviles,
  suspensión de registros, pérdida de beneficios, clausura de hasta 30 días y
  **publicidad correctiva**.

### 5.2 Los tres mecanismos que responden a cada artículo

**Art. 21 → Trazabilidad completa.** Cada afirmación guarda quién la hizo (`business_id`,
`created_by`), cuándo, con qué texto exacto, con qué documento (`evidencia_path`), quién
la revisó y cuándo. Ante cualquier reclamo, identificamos al responsable real en un clic.
Es literalmente la defensa que el artículo describe. **Nada se borra: se marca
`vencida` o `rechazada`.** El historial es el activo legal.

**Art. 11 → Los calificadores obligatorios.** El artículo castiga la inexactitud **y el
ocultamiento**. Por eso el formulario no deja publicar "reciclable" sin decir dónde, ni
"biodegradable" sin plazo, ni "contenido reciclado" sin porcentaje. El campo obligatorio
no es una molestia de UX: es el cumplimiento del artículo.

**Art. 57 → El botón de corrección.** Que la publicidad correctiva sea un remedio
previsto significa que tenemos que poder ejecutarla en minutos:

- `/panel/listados/[id]` → **Despublicar ahora**, sin confirmación en cadena.
- Opción de dejar una **nota de corrección pública** en la ficha del negocio.
- El trigger de dos reportes independientes (`04_ESQUEMA_DB` §4.6) hace lo mismo
  automáticamente mientras dormís.

---

## 6. Ley 24.240, art. 8 — la publicidad obliga al oferente

Las precisiones publicitarias integran el contrato. Por eso:

- El texto del listado es **de la empresa**, atribuido a la empresa.
- Brote **no** genera automáticamente descripciones comerciales.
- La IA sugiere; la empresa acepta o edita; **lo publicado es lo que la empresa aprobó**,
  y queda registrado quién y cuándo lo aprobó.

Si Brote redactara la descripción, se estaría haciendo oferente de un producto ajeno.
Ese es el motivo por el que el screening de IA devuelve `texto_sugerido` y **no** pisa
el campo.

---

## 7. Términos y condiciones de negocios

Documento nuevo en `/legal/negocios` (el repo ya tiene el patrón `LegalDoc` y las
páginas de términos y privacidad). Cláusulas mínimas:

1. **Qué es Brote y qué no es.** Plataforma de difusión. No vendedor, no intermediario
   de pago, no certificador.
2. **Declaración de veracidad.** La empresa declara que toda afirmación es cierta, que
   tiene la documentación de respaldo y que la aportará si se la pedimos. **Cláusula de
   indemnidad** frente a reclamos de terceros por sus afirmaciones.
3. **Los niveles no son certificación.** Explícito: Brote revisa documentación, no
   certifica. Un nivel puede bajar si la documentación vence o se desmiente.
4. **Derecho a despublicar.** Sin aviso previo, ante reporte fundado, vencimiento,
   enlace caído o falta de pago.
5. **Sin garantía de tráfico ni de ventas.** Se cobra el acceso a la plataforma, nunca
   un resultado.
6. **Contenido de la empresa.** Le pertenece; nos da licencia no exclusiva para mostrarlo
   dentro de Brote y en comunicaciones de la plataforma.
7. **Datos del dossier.** Confidenciales, nunca públicos, nunca vendidos, nunca usados
   para otra cosa que generar sus objetivos. **Ponelo por escrito** — es una objeción
   de venta que va a aparecer en la primera reunión.
8. **Baja.** Cómo se da de baja, qué pasa con sus datos, plazo de conservación.
9. **Ley aplicable y jurisdicción.** Argentina.
10. **Cambios de precio.** Con cuánta antelación se avisan y qué pasa con los precios de
    fundador.

### 7.1 Privacidad

Se amplía `/legal/privacidad`, que ya existe:

- Qué datos de la empresa se guardan y por cuánto tiempo.
- Que el dossier **no se publica nunca**, ni siquiera agregado y anonimizado, sin
  consentimiento explícito.
- Que los clics salientes se registran de forma agregada, sin identificar a la persona
  frente al comercio. **La empresa nunca ve quién hizo clic.**
- Qué se manda a Google Gemini y qué no. **Nunca** el CUIT, ni datos de contacto
  personales, ni el nombre de la persona. Solo el contenido operativo necesario.

---

## 8. Moderación

### 8.1 Reportes

Motivos tipificados, jamás texto libre como única entrada:
`afirmacion_falsa` · `enlace_roto` · `no_es_el_producto` · `precio_muy_distinto` ·
`no_responde` · `otro` (este sí con detalle obligatorio).

| Evento | Consecuencia |
|---|---|
| 1 reporte | Notificación al revisor y a la empresa. Sigue publicado |
| 2 reportes de `afirmacion_falsa` de personas distintas en 30 días | **Despublicación automática** |
| Reporte confirmado | Penalización de score, aviso a la empresa, 30 días para corregir |
| 3 reportes confirmados en 12 meses | El nivel de la empresa baja un escalón |
| Reporte desestimado | Sin efecto. **No penaliza a quien reportó de buena fe** |

Un usuario no puede reportar el mismo listado dos veces (índice único en el esquema).
Es el ataque obvio y queda cerrado a nivel base de datos, no a nivel UI.

### 8.2 Derecho de descargo

Antes de confirmar un reporte, la empresa recibe el motivo y tiene **7 días** para
responder con evidencia. Es justo, y además es lo que evita que el sistema se use para
sabotear a un competidor.

### 8.3 Qué no se acepta en el catálogo

Rubros incompatibles, chequeados en el alta y en cada listado: apuestas, tabaco y
vapeo, armas, criptomonedas y minería de cripto, combustibles fósiles como actividad
principal, productos que requieren receta, suplementos con afirmaciones de salud,
cualquier cosa dirigida a menores.

**Sobre las afirmaciones de salud:** *"orgánico"* es una afirmación de proceso productivo
y es aceptable con evidencia. *"Cura"*, *"previene"*, *"desintoxica"*, *"refuerza las
defensas"* son afirmaciones de salud y **se rechazan siempre**, tenga la certificación
que tenga. Son competencia de ANMAT y no es un terreno donde queramos estar. Va en la
lista negra del validador determinista, no solo en el prompt.

---

## 9. Protección de menores

Coherente con lo que el proyecto ya sostiene en feed, noticias y publicidad:

| Cuenta | Mercado | Crear empresa | "Dónde conseguirlo" | Precios |
|---|---|---|---|---|
| `kid` | ❌ Nada | ❌ | ❌ | ❌ |
| `teen` | Solo categorías no comerciales sensibles | ❌ | ❌ | ❌ ocultos |
| `adult` | Completo | ✅ | ✅ | ✅ |

Se aplica **en el servidor** (RPC y RLS), no escondiendo componentes en el cliente. El
proyecto ya verificó esto para el feed social ("un chico ve 0 posteos de usuario / 92
noticias"); acá se hace el mismo test en la Fase 5.

---

## 10. Checklist antes de cobrarle a la primera empresa

- [ ] `/legal/negocios` publicado y **revisado por un abogado**
- [ ] `/legal/privacidad` ampliado con dossier, clics e IA
- [ ] `/legal/niveles` publicado y linkeado desde cada badge
- [ ] Interstitial de salida funcionando en el 100% de las salidas
- [ ] Ningún badge del código dice "verificado", "garantizado" o "aprobado" **sobre un
      producto** — `grep` sobre `messages/es.json` como prueba
- [ ] La palabra "precio" nunca aparece sola: siempre "precio de referencia"
- [ ] Botón de despublicación inmediata probado
- [ ] Trigger de dos reportes probado con dos usuarios distintos
- [ ] Lista negra de afirmaciones de salud activa en el validador **determinista**
- [ ] Rubros incompatibles bloqueados en el alta
- [ ] Test automatizado: cuenta `kid` no puede leer `listings`, `businesses` ni crear una
      empresa
- [ ] Test automatizado: usuario ajeno no puede leer `improvement_dossiers`
- [ ] La empresa acepta los términos con casilla explícita, y queda registrado quién,
      cuándo y qué versión aceptó
