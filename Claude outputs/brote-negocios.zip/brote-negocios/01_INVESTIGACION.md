# 01 · Investigación

> Por qué cada decisión de diseño se sostiene en algo externo y verificable, y no en
> una opinión. Cada hallazgo termina en una fila **"→ Qué hacemos"** que apunta al
> lugar de la carpeta donde eso se convierte en código.

---

## 1. El problema real de un directorio "eco"

Un directorio de productos ecológicos falla siempre por uno de dos lados:

- **Demasiado estricto:** exige certificación de tercero para entrar. Resultado: 12
  listados, ninguna PyME argentina puede pagar una certificación, el catálogo está
  muerto.
- **Demasiado laxo:** cualquiera se autodeclara "eco". Resultado: greenwashing, el
  usuario deja de creer, y la plataforma responde legalmente por afirmaciones ajenas.

La salida no es elegir un extremo: es **tipificar la afirmación y graduar la prueba**.
Todo lo que sigue es la evidencia que hace que esa graduación sea defendible.

---

## 2. Qué es una afirmación ambiental legítima

### 2.1 ISO 14021 — autodeclaraciones (Tipo II)

ISO 14021 es la norma internacional de **afirmaciones ambientales autodeclaradas**:
las que hace el propio fabricante, sin certificador externo. Su exigencia central es
que una autodeclaración sea **específica, verificable, relevante y no engañosa** — es
decir, que exista *algo* contra lo cual contrastarla. Términos vagos y absolutos
("verde", "amigable con el ambiente") son precisamente el caso que la norma existe
para desalentar.

> **→ Qué hacemos.** El nivel **E1 "Declarado"** no es "cualquier cosa": es una
> autodeclaración que pasa el test de especificidad de Tipo II. Una empresa puede
> entrar sin certificación, pero no puede entrar diciendo "somos eco".
> Ver `referencia/RUBRICA_EVIDENCIA.md`.

### 2.2 FTC Green Guides — la rúbrica, afirmación por afirmación

Los *Green Guides* de la Federal Trade Commission de EE.UU. son la guía operativa más
detallada que existe sobre qué prueba requiere cada tipo de afirmación. No nos obligan
legalmente en Argentina, pero **nos dan la única rúbrica lista para convertir en
código**. Lo relevante, textual en su sustancia:

| Afirmación | Regla | Calificación obligatoria |
|---|---|---|
| **Beneficio ambiental general** ("eco", "verde") | Evitar el término sin calificar | Debe ser específica, clara y prominente; solo beneficios significativos; analizar contrapartidas |
| **Reciclable** | Calificar si no hay instalaciones disponibles | Calificar si menos del **60%** de consumidores tiene acceso; lenguaje más fuerte si son pocas comunidades |
| **Contenido reciclado** | Solo material recuperado o desviado del flujo de residuos | Indicar **porcentaje** si es parcial |
| **Compostable** | Debe degradarse a compost útil, seguro y en tiempo razonable | Calificar si no es compostable en casa, o si no hay instalaciones municipales para una mayoría sustancial |
| **Degradable / biodegradable** | Descomposición completa | Probar descomposición total **en un año**; no aplicar a lo que va a relleno o incineración sin calificar |
| **Libre de** | Solo trazas o niveles de fondo | Tres condiciones: solo trazas; la cantidad no causa el daño asociado; **no fue agregada intencionalmente**. No vale si hay otra sustancia de riesgo equivalente |
| **No tóxico** | Seguro para personas **y** ambiente | Evidencia científica competente y confiable para ambos |
| **Energía renovable** | Todos o casi todos los procesos significativos | Especificar la fuente; no reclamar "uso" si se vendieron los certificados |
| **Materiales renovables** | Compuesto entera o sustancialmente de material renovable | Identificar el material y explicar por qué es renovable |
| **Reducción en origen** | Debe indicar la base de comparación | "10% menos que *nuestro producto anterior*", no "10% menos" |
| **Recargable / rellenable** | Debe existir el mecanismo de recarga | Explicar cómo se recarga |
| **Compensación de carbono** | Evidencia científica y contabilidad sin doble venta | Informar si la reducción tarda **2+ años**; no vale compensar algo ya exigido por ley |
| **Sellos y certificaciones** | Funcionan como **aval**: el que los usa responde por lo que implican | Declarar vínculos materiales con el certificador; el sello debe decir sobre qué certifica |

> **→ Qué hacemos.** Esta tabla **es** el motor de validación. Cada fila se vuelve un
> `claim_kind` con: qué evidencia lo sube de nivel, qué calificador es obligatorio en
> el texto público, y qué patrones lo rechazan automáticamente. Es lo que permite que
> un screener automático diga algo mejor que "parece razonable".
> Ver `referencia/RUBRICA_EVIDENCIA.md` y `06_PROMPTS_IA.md` §4.

Dos consecuencias que se suelen pasar por alto y que acá son decisiones de producto:

1. **"Reciclable" casi nunca es simple.** La regla del 60% de acceso significa que en
   Argentina, con recolección diferenciada desigual, la mayoría de las afirmaciones de
   reciclabilidad **necesitan un calificador de disponibilidad local**. Nuestro
   formulario lo pide como campo obligatorio, no como texto libre.
2. **Un sello es un aval, y el que lo muestra responde.** Por eso Brote muestra sellos
   de terceros **con número de certificado y vencimiento**, o no los muestra.

---

## 3. Qué objetivo es realista para una PyME

### 3.1 SBTi — la ruta simplificada para PyMEs

La Science Based Targets initiative tiene una **ruta específica para PyMEs**, y de ahí
sale el número que ancla todo nuestro motor de objetivos:

- **Contracción absoluta mínima: 4,2% × (año objetivo − año base).** Un objetivo a 5
  años exige al menos **21%** de reducción.
- **Año base:** 2015 o posterior, año calendario o fiscal completo, sin promedios
  multianuales, y no se cambia una vez elegido.
- **Horizonte cercano:** 5 a 10 años desde la presentación; **2030** es el default.
- **Cero neto:** 2050 a más tardar, con al menos **90%** de reducción real.
- **Alcance 3:** la PyME debe **medirlo y reducirlo**, pero no se le exige objetivo
  numérico en el horizonte cercano.
- **La ruta PyME excluye** a quien supere **10.000 tCO₂e** en alcances 1 y 2, a
  entidades financieras, a petroleras y gasíferas y a sectores FLAG obligatorios.

> **→ Qué hacemos.** Tres cosas concretas:
>
> 1. **~4,2% anual es la vara de ambición**, no un número inventado. Un objetivo
>    trimestral razonable en una métrica continua es **1% a 2%**. La IA tiene prohibido
>    proponer 50% en un trimestre, y tiene prohibido proponer 0,2% (insultante).
>    Ver `05_ALGORITMOS.md` §5.
> 2. **Sin año base no hay objetivo de reducción.** Si la empresa no tiene línea de
>    base, el **primer objetivo es medirla**. Esto es exactamente lo que hace un
>    programa profesional y es lo que separa nuestro output de un generador de
>    frases motivacionales.
> 3. **El alcance 3 se pide como medición, no como meta.** Igual que SBTi. Es lo que
>    evita proponerle a una panadería que "reduzca las emisiones de sus proveedores".

### 3.2 B Corp / B Impact Assessment — la forma de la escalera

La certificación B Corp exige **80 puntos sobre 200** en el B Impact Assessment. El
dato útil no es el 80: es la **forma** del instrumento. Un negocio común arranca muy
por debajo del umbral y sube por acumulación de prácticas verificables, con un
*Improvement Report* que le dice qué mover a continuación.

> **→ Qué hacemos.** Nuestra escalera E0→E4 imita esa forma: niveles alcanzables por
> acumulación, con la cima (**E4 Referente**) exigiendo lo que exige una certificación
> real — verificación de tercero **más** un historial de mejora sostenido. Nadie llega
> a E4 pagando.

---

## 4. Marco legal argentino

### 4.1 Ley 24.240 art. 40 — responsabilidad solidaria de la cadena

El texto es el que decide toda nuestra arquitectura comercial:

> *"Si el daño al consumidor resulta del vicio o riesgo de la cosa o de la prestación
> del servicio, responderán el productor, el fabricante, el importador, el
> distribuidor, el proveedor, el vendedor y **quien haya puesto su marca en la cosa o
> servicio**. […] La responsabilidad es solidaria […]. Sólo se liberará total o
> parcialmente quien demuestre que la causa del daño le ha sido ajena."*

Dos lecturas, y la segunda es la que casi todos ignoran:

1. Si no vendemos, no somos vendedor ni proveedor de esa cosa. Bien.
2. Pero **"quien haya puesto su marca en la cosa o servicio"** responde igual. Un
   badge de Brote que diga *"Producto ecológico verificado"* sobre un listado ajeno es
   exactamente el riesgo de que se argumente que pusimos nuestra marca sobre el
   producto. Y la única salida del art. 40 es probar **causa ajena**.

> **→ Qué hacemos.** Regla de redacción de badges, sin excepciones: **el badge describe
> nuestro proceso y el nivel de prueba, nunca la calidad del producto.**
>
> - Prohibido: "Producto ecológico verificado por Brote", "Garantía Brote".
> - Correcto: **"Nivel 3 · Certificación de tercero vigente presentada"**,
>   **"Nivel 1 · Declarado por el comercio, sin verificar"**.
>
> Y la separación operativa que sostiene la causa ajena: sin carrito, sin precio
> cobrado por nosotros, sin stock, sin envío, sin pago, con salida explícita por
> interstitial. Ver `08_LEGAL_Y_CONFIANZA.md` §2 y §3.

### 4.2 Decreto 274/2019 — Lealtad Comercial

- **Art. 11 · Publicidad engañosa.** Prohíbe *"toda presentación, publicidad o
  propaganda que mediante inexactitudes u ocultamientos pueda inducir a error, engaño o
  confusión"* sobre características, origen, calidad, cantidad, precio o técnicas de
  producción.
- **Art. 10.a · Actos de engaño.** Inducir a error sobre naturaleza, características,
  pureza, calidad y "en general, sobre los atributos, beneficios o condiciones" de
  bienes y servicios es competencia desleal.
- **Art. 21 · Rótulos.** Responden fabricantes, productores, envasadores, importadores
  y fraccionadores. **El comerciante responde si no puede aportar la documentación que
  identifique al verdadero fabricante o importador.**
- **Art. 57 · Sanciones.** Apercibimiento, multas de 1 a 10 millones de Unidades
  Móviles, suspensión de registros de proveedores del Estado, pérdida de beneficios y
  clausura de hasta 30 días. Y puede ordenarse **publicidad correctiva**.

> **→ Qué hacemos.** Tres mecanismos, cada uno atado a un artículo:
>
> - **Art. 21 → trazabilidad.** Cada afirmación guarda **quién la hizo, cuándo y con
>   qué documento**, con el archivo en Storage. Ante un reclamo podemos identificar al
>   responsable en un clic. Es literalmente la defensa que el artículo describe.
> - **Art. 11 → el validador.** El screener de afirmaciones existe para bloquear
>   inexactitudes **y ocultamientos**: por eso los calificadores obligatorios (la
>   disponibilidad de reciclaje, el plazo de biodegradación, el porcentaje de contenido
>   reciclado) no son opcionales.
> - **Art. 57 → botón de corrección.** Existe una acción de admin que **despublica en
>   el acto** y, si hace falta, deja una nota de corrección pública en la ficha del
>   negocio. Que la publicidad correctiva sea un remedio previsto significa que hay que
>   poder ejecutarla en minutos, no en un deploy.

### 4.3 Ley 24.240 art. 8 — la publicidad obliga al oferente

Las precisiones publicitarias integran el contrato con el consumidor.

> **→ Qué hacemos.** El texto de un listado es **de la empresa y se muestra atribuido a
> la empresa**. Brote no reescribe la descripción comercial. La IA puede *sugerirle* a
> la empresa una redacción más clara, pero el texto publicado es el que la empresa
> aprueba y firma. Ver `08_LEGAL_Y_CONFIANZA.md` §4.

---

## 5. Certificaciones que existen de verdad en Argentina

Para que el nivel E3 signifique algo, el registro de certificaciones reconocidas tiene
que ser real y estar vivo.

- **Producción orgánica:** regulada por la **Ley 25.127** y controlada por **SENASA**,
  que mantiene un **registro público de entidades certificadoras habilitadas**
  (actualizado periódicamente; la versión pública más reciente que pudimos ubicar es de
  2025). Entre las certificadoras que operan en el país figuran **OIA**, **Argencert**,
  **Letis**, **Food Safety** y **Ecocert Argentina**. **MAPO** (Movimiento Argentino
  para la Producción Orgánica) es la referencia sectorial.
- **Internacionales frecuentes en productos locales:** FSC, Rainforest Alliance,
  Fairtrade, Leaping Bunny / Cruelty Free International, Vegan Society, ISO 14001,
  Sistema B.

> ⚠️ **Honestidad sobre esta lista.** El PDF del registro oficial de SENASA no pudo
> leerse automáticamente (bloqueo de acceso). Los nombres de arriba son un **semillero
> a verificar contra el registro oficial antes de publicar**, no una lista cerrada. La
> Fase 3 incluye esa verificación como tarea explícita con el enlace al registro.
>
> **→ Qué hacemos.** `referencia/CERTIFICACIONES.md` es una **tabla en base de datos**,
> no una constante en el código, justamente para poder corregirla sin deploy. Cada
> entrada guarda: emisor, qué certifica, si el certificado tiene número verificable, si
> vence, y a qué `claim_kind` habilita.

---

## 6. Arranque en frío de un mercado de dos lados

El patrón conocido: sin oferta no hay demanda, sin demanda no hay oferta, y el lado
difícil de sembrar es el que necesita esfuerzo. Acá el lado difícil es **la empresa**,
que además tiene que **pagar desde el día uno**.

Lo que la evidencia de mercados de dos lados sugiere, y que aplicamos:

- **Sembrar de a un nicho, no a lo ancho.** Un rubro y una zona con densidad real
  vale más que cien listados dispersos.
- **Dar valor antes de tener tráfico.** Es exactamente el rol de **Mejora**: la
  empresa recibe un programa de objetivos útil el primer día, incluso con cero
  visitas al Mercado. Es lo que justifica la cuota antes de que exista la audiencia.
- **Exploración forzada para la oferta nueva.** Sin un empujón temporal, el orden por
  calidad congela el catálogo en los primeros que llegaron.

> **→ Qué hacemos.** El empujón de exploración con decaimiento y la re-ordenación por
> diversidad están especificados en `05_ALGORITMOS.md` §4. El argumento de venta
> "Mejora primero, Mercado después" es el eje del arranque en frío de la Fase 5 §6.

**Nota de reutilización:** el repo ya resolvió un problema idéntico de diversidad en el
ranking de noticias — penalización `0.7^apariciones` por fuente (migración `0019`).
Usamos **el mismo patrón** para no tener dos filosofías de ranking en el mismo producto.

---

## 7. Presupuesto de IA

Límites vigentes de la capa gratuita de la API de Gemini:

| Modelo | RPM | Solicitudes/día | TPM |
|---|---|---|---|
| Gemini 2.5 Flash | 15 | **1.500** | 1.000.000 |
| Gemini 2.5 Flash-Lite | 30 | **1.500** | 1.000.000 |
| Gemini 2.5 Pro | 5 | **50** | 1.000.000 |

> **→ Qué hacemos.** Todo con **Flash**, nunca Pro (50/día no alcanza para nada serio).
> Y una regla de arquitectura: **ninguna llamada a IA ocurre durante el render de una
> página.** Las llamadas se disparan en eventos discretos y de bajo volumen (envío de
> dossier, pedido de replanificación, envío de listado) y se **cachean por hash de
> entrada** en la tabla `ai_jobs`. Con 100 empresas activas el consumo estimado es
> **menos de 50 solicitudes por día** — 3% del techo gratuito.
> Ver `06_PROMPTS_IA.md` §1.

---

## Fuentes

- [ISO 14021:2016 — Self-declared environmental claims (Type II)](https://www.iso.org/standard/66652.html)
- [ISO 14021:2026 — Self-declared environmental claims](https://www.iso.org/standard/14021)
- [FTC — Environmental Claims: Summary of the Green Guides](https://www.ftc.gov/business-guidance/resources/environmental-claims-summary-green-guides)
- [FTC Issues Final Revisions to the Green Guides — Kelley Drye](https://www.kelleydrye.com/viewpoints/client-advisories/ftc-issues-final-revisions-to-the-green-guides-new-guidance-for-substantiating-environmental-marketing-claims)
- [SBTi — FAQs for SMEs (v6.2, PDF)](https://docs.sbtiservices.com/resources/FAQsforSMEs.pdf)
- [SBTi — Standards and guidance](https://sciencebasedtargets.org/standards-and-guidance)
- [B Lab — Increasing your score to achieve 80 points](https://kb.bimpactassessment.net/en/support/solutions/articles/43000524458-increasing-your-score-to-achieve-80-points)
- [Ley 24.240 de Defensa del Consumidor — Argentina.gob.ar](https://www.argentina.gob.ar/normativa/nacional/ley-24240-638)
- [Ley 24.240 art. 40 — texto y comentario (Proconsumer)](https://proconsumer.org.ar/art-40/)
- [Decreto DNU 274/2019 — Lealtad Comercial, texto oficial](https://www.argentina.gob.ar/normativa/nacional/norma-322236/texto)
- [Decreto 274/2019 — Boletín Oficial](https://www.boletinoficial.gob.ar/detalleAviso/primera/205888/20190422)
- [SENASA — Entidades certificadoras de producción orgánica](https://www.argentina.gob.ar/senasa/programas-sanitarios/producci%C3%B3n-organica/entidades-certificadoras)
- [SENASA — Registro de entidades certificadoras (PDF)](https://www.argentina.gob.ar/sites/default/files/2018/08/registro_de_entidades_certificadoras_de_prod_organicos_abril_2025.pdf)
- [Ecocert — Certificación orgánica Argentina](https://www.ecocert.com/es-AR/detaile-de-certification/agricultura-organica-argentina)
- [MAPO — Certificación](https://mapo.org.ar/certificacion/)
- [Mercado Pago — API de suscripciones (preapproval)](https://www.mercadopago.com.ar/developers/es/reference/subscriptions/_preapproval/post)
- [Mercado Pago — Gestión de pagos recibidos, suscripciones](https://www.mercadopago.com.mx/developers/es/docs/subscriptions/additional-content/payment-management)
- [Gemini API — límites de la capa gratuita 2026](https://tokenmix.ai/blog/gemini-api-free-tier-limits)
- [Two-Sided Marketplace Strategy — Stripe](https://stripe.com/resources/more/two-sided-marketplace-strategy)
- [Marketplace Cold-Start Playbook: First 100 Users](https://techvinta.com/blog/marketplace-cold-start-playbook-first-100-users)
