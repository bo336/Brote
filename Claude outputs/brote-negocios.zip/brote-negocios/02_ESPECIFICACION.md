# 02 · Especificación funcional

> El producto completo. Qué existe, qué hace cada cosa, qué ve cada actor y qué pasa en
> cada borde. Si una fase y este documento se contradicen, **manda este documento**.

---

## 1. Actores

| Actor | Quién es | Dónde vive |
|---|---|---|
| **Persona** | Usuario de Brote de siempre (`kid`/`teen`/`adult`) | `/` y todo lo existente |
| **Miembro de negocio** | Una persona `adult` con rol en una empresa | `/negocio/*` al cambiar de contexto |
| **Dueño (`owner`)** | Quien creó la empresa; único que gestiona plan y equipo | `/negocio/*` |
| **Revisor** | Vos. Aprueba altas, afirmaciones y cierres | `/panel/negocios`, `/panel/listados` |
| **Visitante del Mercado** | Cualquier persona `adult` (y `teen` con límites) | `/mercado/*` |

Una **cuenta** es siempre una persona. Una **empresa** es una entidad separada a la que
personas pertenecen. Nunca se hace login "como empresa".

---

## 2. Mapa del producto

```
PERSONA (existente, intacto)                     EMPRESA (nuevo)
┌──────────────────────────┐                   ┌──────────────────────────┐
│ Hoy · Acciones · Explorar│                   │ /negocio                 │
│ Ranking · Perfil · Mundo │                   │  ├─ Resumen              │
│ Competencias · Aprendé   │                   │  ├─ Mejora   ← objetivos │
└───────────┬──────────────┘                   │  ├─ Listados ← vidriera  │
            │                                  │  ├─ Analítica            │
            │  "¿Dónde consigo esto?"          │  ├─ Equipo               │
            ▼                                  │  ├─ Verificación         │
┌──────────────────────────┐                   │  └─ Plan                 │
│ /mercado                 │◄──── publica ─────┤                          │
│  catálogo público        │                   └──────────────────────────┘
│  ordenado por evidencia  │                                │
└───────────┬──────────────┘                                │ revisa
            │ salida                                        ▼
            ▼                                  ┌──────────────────────────┐
   sitio de la empresa                         │ /panel/negocios          │
   (Brote no interviene)                       │ /panel/listados          │
                                               │ /panel/reportes          │
                                               └──────────────────────────┘
```

---

## 3. Alta de una empresa

### 3.1 Quién puede

- Cuenta `adult`, verificada por email, con al menos **1 día** de antigüedad.
- `kid` y `teen`: bloqueado. El punto de entrada ni siquiera se muestra.
- Una persona puede pertenecer a **varias** empresas y ser `owner` de hasta **3**
  (freno anti-spam; ajustable en `app_state`).

### 3.2 El formulario, en 5 pasos

Deliberadamente conversacional y corto. Se guarda como borrador en cada paso: nadie
pierde lo escrito. Objetivo: **menos de 6 minutos**.

**Paso 1 · Quiénes son**
`nombre_comercial`, `razon_social` (opcional), `cuit` (opcional pero recomendado, con
validación de dígito verificador en cliente), `rubro` (una de 12 opciones), `tamaño`
(1 / 2-10 / 11-50 / 51-200 / 200+), `provincia`, `ciudad`.

**Paso 2 · Dónde encontrarlos**
`sitio_web` y/o `instagram`, `whatsapp_comercial` (opcional), `email_contacto`.
Al menos uno de sitio o Instagram es **obligatorio**: es lo que después se verifica.

**Paso 3 · Qué hacen**
Un textarea guiado, no un formulario. Placeholder con voseo:

> *"Contanos en tus palabras qué hace tu negocio, qué vendés o qué servicio das, y qué
> cosas ya hacés hoy que cuidan el ambiente. No hace falta que suene lindo — cuanto más
> concreto, mejores van a ser los objetivos que te propongamos."*

Mínimo 120 caracteres. Debajo, tres chips que **inyectan preguntas** si el texto es
pobre: *"¿De dónde vienen tus insumos?"*, *"¿Qué hacés con los residuos?"*, *"¿Cómo
llegan tus productos al cliente?"*.

**Paso 4 · Qué querés hacer acá**
Checkboxes: *"Quiero mejorar mi impacto con objetivos"*, *"Quiero mostrar mis
productos"*, *"Las dos"*. Define qué se le muestra primero después de aprobar.

**Paso 5 · Verificación**
Ver §3.3. Puede saltearse y completarse después, pero **sin verificar no se publica
ningún listado** (Mejora sí funciona).

### 3.3 Verificación de identidad

Objetivo: probar que quien se dio de alta **controla** el negocio, sin pedir papeles ni
trámites. Se genera un token único `brote-verify-<12 chars>` por empresa.

**Métodos, de más fuerte a más liviano. Alcanza con uno.**

| # | Método | Cómo | Fuerza | Automático |
|---|---|---|---|---|
| 1 | **Meta tag en el sitio** | Pegar `<meta name="brote-site-verification" content="TOKEN">` en el `<head>` de la home | Alta | Sí — la edge function hace `fetch` y busca el token |
| 2 | **Registro DNS TXT** | Agregar `brote-site-verification=TOKEN` como TXT en el dominio raíz | Alta | Sí — resolución DNS por DoH |
| 3 | **Archivo en la raíz** | Subir `/.well-known/brote-verify.txt` con el token | Alta | Sí — `fetch` directo |
| 4 | **Email del dominio** | Código de 6 dígitos a una casilla `@sudominio.com` | Alta | Sí |
| 5 | **Token en la bio de Instagram** | Pegar el token en la bio + subir captura | Media | Parcial — Gemini Vision lee la captura; el revisor ve el perfil |

**Sobre el método 5, con honestidad:** Instagram bloquea el scraping. No prometemos
verificación automática fuerte ahí. Lo que hacemos es: la empresa pega el token en su
bio, sube una captura, Gemini Vision confirma que **el handle y el token aparecen en la
misma imagen**, y el revisor abre el perfil real de un clic para confirmar. Es media
fuerza y así se etiqueta internamente — nunca se le presenta al usuario como si fuera
lo mismo que el dominio.

**El CUIT** se guarda como **declarado**, no verificado. Suma muchísima confianza en
Argentina a costo cero y le da al revisor algo real que mirar, pero la ficha pública
dice *"CUIT declarado por el comercio"*, jamás *"CUIT verificado"*.

**Reintentos:** el chequeo automático se puede reintentar 1 vez cada 10 minutos, 20
veces por día. La empresa ve exactamente qué falló (*"Entramos a tu sitio pero no
encontramos el meta tag. ¿Lo pegaste dentro del `<head>`?"*), nunca un error técnico.

### 3.4 La cola de revisión (tu parte)

`/panel/negocios` muestra las solicitudes ordenadas por antigüedad. Cada fila:

- Nombre, rubro, provincia, tamaño, antigüedad de la solicitud.
- **Estado de verificación** con el método y la fuerza.
- **Puntaje de la IA (0-100)** y su **veredicto de una línea**.
- Chips de riesgo: `sin verificar` · `afirmaciones vagas` · `sitio caído` ·
  `sin descripción de actividad` · `posible duplicado`.

Al abrir, el revisor ve el **informe de la IA**: resumen del negocio en 2 líneas, qué
afirmó, qué evidencia hay, qué falta, y una recomendación explícita
(`aprobar` / `aprobar con observaciones` / `pedir más datos` / `rechazar`) **con el
motivo**. Tres botones grandes y un campo de nota.

- **Aprobar** → estado `approved`, se le habilita el espacio de trabajo, notificación.
- **Pedir más datos** → estado `submitted` con `revision_note`; la empresa ve
  exactamente qué falta y reenvía. No se pierde nada de lo cargado.
- **Rechazar** → `rejected` con motivo. Puede volver a aplicar a los 30 días.

**Objetivo de tiempo: menos de 2 minutos por empresa.** Si en la práctica lleva más,
el informe de la IA está mal diseñado, no vos.

---

## 4. Mejora — el programa de objetivos

> Esta es la sección que tiene que sentirse **profesional**. Sin puntos, sin emojis en
> controles, sin celebraciones, sin racha. Un panel de gestión, no un juego.

### 4.1 Dossier

Es la fuente de verdad del motor. Se completa una vez y se puede editar cuando quieran
(cada edición ofrece replanificar). Bloques:

1. **Operación** — qué producen o venden, volumen aproximado, estacionalidad.
2. **Energía** — tipo de suministro, si tienen la factura a mano, equipos grandes.
3. **Residuos** — qué tiran, cuánto, si separan, si tienen quién retire reciclables.
4. **Agua** — si es un insumo relevante, medición.
5. **Insumos y proveedores** — de dónde vienen, cuántos proveedores clave, si tienen
   poder de cambiarlos.
6. **Logística** — cómo llega el producto al cliente, flota propia o tercerizada.
7. **Ya hecho** — qué cambiaron en los últimos 2 años. **Campo crítico**: evita
   proponerles lo que ya hicieron, que es la forma más rápida de perder credibilidad.
8. **Restricciones** — presupuesto de inversión (`ninguno` / `hasta $X` / `evaluamos
   caso por caso`), local alquilado o propio, horas de gente disponibles por mes.

Cada bloque acepta *"No sé"* como respuesta válida y explícita. **"No sé" es
información**: dispara un objetivo de medición en lugar de un objetivo de reducción.

### 4.2 Cómo se generan los objetivos

Al enviar el dossier:

1. Se arma un **hash de entrada**; si ya existe en `ai_jobs`, se reutiliza.
2. Se llama a Gemini con el prompt de `06_PROMPTS_IA.md` §2, que recibe el dossier + la
   biblioteca de palancas filtrada por rubro + las reglas de realismo.
3. La IA devuelve **JSON estricto** con 3 a 5 objetivos propuestos.
4. Se **valida cada objetivo** contra el validador determinista (`05_ALGORITMOS.md` §5).
   Los que no pasan se descartan **en silencio** y se reemplazan por palancas del
   catálogo. La empresa nunca ve un objetivo inválido.
5. Se presentan como **propuesta**, no como hecho consumado.

**Si no hay clave de Gemini o la llamada falla:** se seleccionan 3 palancas del catálogo
por rubro/tamaño con un scoring determinista, se rellenan sus plantillas con los datos
del dossier, y se marca `generated_by='reglas'`. **La empresa no ve ninguna diferencia
de calidad aparente** — las palancas del catálogo ya vienen escritas en voz de producto.

### 4.3 Qué es un objetivo

Todo objetivo lleva, sin excepción:

| Campo | Ejemplo | Por qué |
|---|---|---|
| `titulo` | "Bajar 8% el consumo eléctrico del salón" | Legible de un vistazo |
| `porque` | 2-3 líneas: qué mueve y por qué importa en tu rubro | Sin esto es una orden arbitraria |
| `metrica` | `kwh_mes` | Medible |
| `linea_base` + `unidad` | 1.240 kWh/mes | Sin base no hay objetivo |
| `origen_linea_base` | `factura` / `estimado` / `a_medir` | Honestidad sobre el dato |
| `objetivo` | 1.141 kWh/mes | El número duro |
| `horizonte` | `trimestral` | Nunca diario ni semanal |
| `ambicion` | `basico` / `intermedio` / `avanzado` | Tier del objetivo |
| `esfuerzo_horas_mes` | 3 | **El campo que evita que sea la tarea principal** |
| `inversion_estimada` | `ninguna` / `baja` / `media` | Respeta la restricción declarada |
| `como_medir` | "Comparar la factura de marzo con la de diciembre" | Debe usar algo que ya tienen |
| `pasos[]` | 3 a 6 pasos concretos | Ejecutable, no aspiracional |
| `evidencia_requerida` | "Foto de las dos facturas" | Qué hay que subir para cerrarlo |
| `si_no_llegas` | "Cerralo igual con lo logrado; cuenta como avance parcial" | Quita el miedo a fallar |
| `confianza` | `alta` / `media` / `baja` | La IA declara su incertidumbre |

### 4.4 Reglas de realismo (obligatorias, validadas por código)

Están completas en `05_ALGORITMOS.md` §5. El resumen operativo:

- **Ambición anclada en SBTi:** ~4,2% anual en métricas continuas → **1% a 2% por
  trimestre** es lo normal. Máximo absoluto en un trimestre: **8%**, y solo si el
  cambio es un evento único que la empresa declaró factible (cambiar de proveedor,
  reemplazar luminaria).
- **Techo de esfuerzo:** ≤ **6 h/mes** por objetivo, ≤ **12 h/mes** entre todos los
  activos, máximo **3 objetivos activos** a la vez.
- **Sin base, se mide primero.** Si `origen_linea_base = a_medir`, el objetivo del ciclo
  **es medir**, no reducir. Ambición `basico`, esfuerzo ≤ 2 h/mes.
- **Nada fuera de su control.** Prohibido proponer que la empresa cambie a terceros que
  no elige, a su municipio o a sus clientes.
- **Nada que exija plata que no declararon.** Si dijeron `presupuesto: ninguno`,
  `inversion_estimada` debe ser `ninguna`.
- **Nada ya hecho.** Se cruza contra el campo "Ya hecho" antes de proponer.
- **Alcance 3 se mide, no se pone como meta** (igual que SBTi para PyMEs).
- **Sin números inventados.** La IA no puede afirmar un consumo que la empresa no dio.
  Si no lo tiene, `a_medir`.

### 4.5 El ciclo de vida y el feedback

```
 propuesto ──aceptar──► activo ──┬── cerrar con evidencia ──► logrado
     │                            │
     │                            ├── vence sin cerrar ─────► incumplido
   descartar                      │
     │                            └── replanificar ─────────► activo (v2)
     ▼
  descartado                    (en cualquier momento: en_riesgo)
```

**El feedback es la funcionalidad central de Mejora**, no un extra. En la ficha de un
objetivo hay un cuadro de texto permanente:

> *"¿Algo no cierra? Contame y lo ajustamos."*

Con cuatro atajos que precargan el texto:

- **"No llego a ese número"** → pide cuánto sí puede, y replanifica.
- **"Esto ya lo hacemos"** → pide desde cuándo y con qué prueba; si hay evidencia, el
  objetivo pasa a `logrado` **retroactivo** y se propone el siguiente escalón.
- **"No aplica a mi negocio"** → lo retira y pide una alternativa del mismo dominio.
- **"Necesito más tiempo"** → extiende el horizonte un escalón (trimestral →
  semestral), **sin bajar el objetivo**.

Cada intercambio crea un `goal_checkin` y dispara una **replanificación**: Gemini recibe
el objetivo original + el historial completo de check-ins + el dossier, y devuelve una
**versión nueva** del objetivo. **La versión anterior nunca se borra** — queda el
historial visible, que es lo que hace que el programa se sienta serio y lo que sostiene
el nivel E4.

**Límite:** 8 replanificaciones por empresa por semana (protege el presupuesto de IA y
evita el ping-pong infinito). Al llegar al límite, el ajuste se puede hacer igual de
forma manual con los controles determinísticos (bajar meta, extender plazo, retirar).

### 4.6 Cierre y evidencia

Para cerrar un objetivo la empresa sube lo que dice `evidencia_requerida` (foto,
factura, captura, planilla) y el valor final de la métrica. Entonces:

- Estado → `en_revision`.
- El revisor ve el objetivo, el antes/después y el archivo. Aprueba o pide corrección.
- Aprobado → `logrado`. Suma al **Progreso de Mejora** y cuenta para E4.
- Si el valor final no alcanzó la meta pero hubo avance real → `logrado_parcial`.
  Cuenta la mitad. **Que exista el parcial es lo que hace que la gente reporte la
  verdad** en lugar de abandonar el objetivo.

### 4.7 Progreso de Mejora (distinto del Nivel de Evidencia)

Dos indicadores, deliberadamente separados:

- **Nivel de Evidencia (E0-E4)** — qué **probaron**. Gobierna el Mercado.
- **Progreso de Mejora (0-100)** — qué **están haciendo**. Ciclos cerrados con
  evidencia, con decaimiento si dejan de participar.

Están separados porque si se mezclaran, una empresa podría comprar visibilidad
"haciendo objetivos" sin probar nada de lo que vende. La evidencia manda en el catálogo;
el progreso da un empujón **dentro** del nivel, nunca lo cambia de nivel.

---

## 5. Mercado — la vidriera

### 5.1 Qué es un listado

Producto o servicio. Campos:

- `titulo`, `descripcion` (texto de la empresa, atribuido), hasta **4 imágenes**.
- `tipo`: `producto` | `servicio`.
- `categoria` (taxonomía propia del Mercado, ver §5.2) + `dominios[]` (los 13 de Brote,
  para conectar con acciones e intereses).
- `precio_referencia` **opcional y explícitamente informativo** — *"precio de
  referencia informado por el comercio"*. No cobramos, no garantizamos.
- `url_destino` — a dónde va el usuario. Obligatoria, `https`, dominio verificado o
  declarado por la empresa.
- `disponibilidad`: `online` / `local` / `ambas`, y `zonas[]` de entrega si aplica.
- **`afirmaciones[]`** — el corazón: 1 a 5 afirmaciones tipificadas.

### 5.2 Categorías del Mercado

12, pensadas para conectar con acciones diarias existentes:

`alimentos-frescos` · `almacen-granel` · `bebidas` · `limpieza-hogar` ·
`cuidado-personal` · `indumentaria` · `hogar-y-deco` · `jardin-y-huerta` ·
`mascotas` · `movilidad` · `servicios-profesionales` · `reparacion-y-reuso`

### 5.3 Afirmaciones tipificadas

Nadie escribe "es ecológico" en un campo libre. Se elige un **tipo de afirmación** de
las 16 de `referencia/RUBRICA_EVIDENCIA.md`, y el formulario **cambia según el tipo**:

- Elegís `contenido_reciclado` → aparece un campo **porcentaje obligatorio**.
- Elegís `reciclable` → aparece **disponibilidad de reciclaje en tu zona**, obligatorio.
- Elegís `biodegradable` → aparece **plazo en meses** y **condiciones**, obligatorios.
- Elegís `certificacion_tercero` → aparece **certificadora** (del registro),
  **número de certificado** y **vencimiento**, obligatorios.
- Elegís `organico` → certificadora SENASA + número, o baja a nivel declarado.

Es imposible hacer una afirmación vaga porque **la interfaz no tiene un campo donde
escribirla**. Ese es el diseño: no validamos texto libre, evitamos que exista.

### 5.4 Validación de un listado

Al enviar:

1. **Validador determinista** — campos obligatorios por tipo, URL viva (HEAD request),
   imágenes presentes, sin patrones prohibidos en título/descripción (lista negra de
   términos absolutos sin calificar: "100% ecológico", "carbono neutral", "totalmente
   natural", "no contamina").
2. **Screener de IA** (`06_PROMPTS_IA.md` §4) — lee título, descripción y afirmaciones y
   devuelve por afirmación: `nivel_sugerido`, `problemas[]`, `texto_sugerido`, y un
   puntaje global.
3. **Cola de revisión** — el revisor ve el listado renderizado como lo vería un usuario,
   con las observaciones de la IA al costado. Publica, pide cambios o rechaza.

Después de la **primera** aprobación, una empresa con verificación fuerte y sin
reportes entra en **publicación acelerada**: los listados nuevos se publican solos si el
screener no marca nada, y quedan en una cola de auditoría posterior. Sin esto, vos sos
el cuello de botella para siempre.

### 5.5 Nivel de evidencia de una afirmación

| Nivel | Nombre | Qué exige | Etiqueta pública |
|---|---|---|---|
| **E1** | Declarado | Afirmación específica y calificada, sin documento | *"Declarado por el comercio"* |
| **E2** | Documentado | Identidad verificada + documento de respaldo (ficha técnica, composición, foto del proceso, factura de proveedor) revisado | *"Con documentación revisada"* |
| **E3** | Certificado por tercero | Certificación del registro, con número y vigencia | *"Certificación de tercero vigente"* |

E0 y E4 son de **empresa**, no de afirmación: E0 = no listado; E4 = referente
(ver §5.6).

**La regla antihalo (D2):** el nivel es de **la afirmación en ese listado**. Una
certificación orgánica de harina da E3 a la afirmación "orgánico" del pan, y **no toca**
la afirmación "envase reciclable" del mismo pan, ni nada de la línea de limpieza.

### 5.6 Nivel de la empresa

| Nivel | Requisitos |
|---|---|
| **E0** | Alta enviada, sin aprobar. No aparece en ningún lado |
| **E1** | Aprobada. Puede publicar con afirmaciones declaradas |
| **E2** | Identidad verificada por método fuerte + ≥1 afirmación en E2 |
| **E3** | ≥1 afirmación en E3 vigente |
| **E4 · Referente** | E3 + **≥2 ciclos de mejora cerrados con evidencia aprobada** + sin reportes abiertos + revisión en los últimos 12 meses |

E4 no se compra y no se acelera: exige tiempo y evidencia. Es lo que le da sentido al
resto de la escalera.

### 5.7 El catálogo público

`/mercado` — el escaparate. Reglas:

- **Ordenado por el algoritmo de `05_ALGORITMOS.md` §4**, nunca por fecha sola.
- **Nada se oculta por ser nuevo.** El listado de una empresa recién aprobada recibe un
  empujón de exploración decreciente durante 21 días.
- **Diversidad forzada:** máximo 2 listados consecutivos de la misma empresa
  (penalización `0.7^apariciones`, el mismo patrón que ya usa el ranking de noticias).
- **Filtros:** categoría, dominio, nivel mínimo de evidencia, zona, online/local.
- **El nivel se muestra siempre**, en el listado y en la ficha. Nunca escondido.
- **Sin publicidad de AdSense en `/mercado`.** Mezclar ads con listados pagos destruye
  la distinción y trae un problema de política publicitaria encima.

### 5.8 La salida (`/mercado/salir/[id]`)

Toda salida pasa por acá. Es analítica **y** escudo legal:

1. Registra el clic (`listing_clicks`: listado, empresa, usuario o anónimo, origen,
   timestamp, user agent hash).
2. Muestra medio segundo un panel: el logo del comercio, y el texto legal de
   `08_LEGAL_Y_CONFIANZA.md` §3 — *"Estás saliendo de Brote. La compra, el precio, el
   envío y la atención son responsabilidad de [comercio]. Brote no vende ni interviene
   en la operación."*
3. Redirige con `rel="noopener noreferrer nofollow"`.

Si el usuario ya vio el aviso 3 veces en 30 días, el paso 2 se reduce a un toast y la
redirección es inmediata. La fricción tiene que enseñar, no molestar.

### 5.9 Reportes

Cualquier usuario puede reportar un listado con un motivo tipificado:
`afirmacion_falsa` · `enlace_roto` · `no_es_el_producto` · `precio_muy_distinto` ·
`no_responde` · `otro`.

- Un reporte → notificación al revisor y a la empresa, listado sigue publicado.
- **Dos reportes independientes de `afirmacion_falsa` en 30 días** → el listado se
  **despublica automáticamente** hasta que el revisor decida. Es la implementación
  operativa de la publicidad correctiva del art. 57.
- Reportes resueltos a favor de la empresa no la penalizan. Reportes confirmados sí, y
  con reincidencia bajan el nivel.

---

## 6. El puente con la app de personas

### 6.1 "Dónde conseguirlo" en las acciones

Muchas acciones de Brote son de sustitución. La tabla `activity_market_hints` mapea
`activity_id` → `categoria` + `dominios[]` + `texto_puente`.

En `/acciones/[slug]`, **debajo** de las instrucciones y **nunca** en el camino de
completar:

> **DÓNDE CONSEGUIRLO**
> *"Estas acciones se hacen más fáciles con buenos proveedores. Estos negocios están en
> el programa de Brote."*
> [3 listados, con su nivel visible] · [Ver más en el Mercado →]

**Reglas duras:**

- Nunca en el flujo de completar, ni en la celebración, ni en el set diario, ni en
  onboarding. Es exactamente la regla 2 de la política de ads que el proyecto ya tiene
  (`lib/ads/policy.ts`), aplicada acá.
- Nunca para `kid`. Para `teen`, solo categorías no comerciales sensibles y sin precio.
- Se muestra solo si hay **≥3 listados relevantes**; con menos, no se muestra nada. Un
  módulo con un listado triste es peor que ningún módulo.

### 6.2 Otras superficies

- **Explorar → nueva pestaña "Mercado"** junto a Novedades y Proyectos, respetando el
  `<SectionTabs>` existente.
- **Ficha pública del negocio** `/mercado/negocio/[slug]`: descripción, nivel, listados,
  y —si la empresa lo habilita— **su historial público de mejora**. Un negocio que
  muestra "cerramos 4 objetivos con evidencia" es la mejor publicidad que existe, y es
  el argumento de venta que justifica la cuota.
- **Sin puntos por comprar.** Jamás. Brote no premia consumo — premia acción. Cruzar esa
  línea convierte la app en un programa de afiliados y destruye la marca.

---

## 7. Notificaciones

Se agrega `business_id` a `notifications`. Regla de aislamiento: **la campana personal
nunca muestra notificaciones de empresa y viceversa.**

**A la empresa:** alta aprobada/observada · verificación exitosa/fallida · listado
publicado/observado · objetivo por vencer (7 días) · objetivo vencido · cierre aprobado
· reporte recibido · pago próximo / fallido / suscripción vencida · nivel alcanzado.

**Al revisor** (`/panel`): alta pendiente · listado pendiente · cierre pendiente ·
segundo reporte en un listado.

Email queda **fuera de alcance de la v1** (no hay proveedor gratuito confiable
configurado). Todo es in-app + push web, reutilizando la infraestructura VAPID que ya
existe. Excepción: el código de verificación por email de dominio, que sí necesita
salir — ver Fase 1 §6 para las opciones sin costo.

---

## 8. Estados y bordes

Lo que suele romperse, resuelto de antemano.

| Situación | Qué pasa |
|---|---|
| Empresa deja de pagar | 7 días de gracia con aviso → listados **despublicados** (no borrados) → Mejora sigue en modo lectura → a los 90 días se ofrece exportar y cerrar |
| Certificado vence | 30 días antes, aviso. Al vencer, la afirmación baja de E3 a E2 automáticamente y el listado se re-ordena. **No se despublica** |
| Se va el `owner` | Debe transferir la titularidad antes de salir. Si borra su cuenta de Brote, la empresa pasa al `admin` más antiguo; si no hay, queda `suspended` con aviso |
| La URL de destino muere | Chequeo semanal por cron. 2 fallos consecutivos → aviso; 4 → despublicación automática |
| Empresa duplicada | Detección por dominio y CUIT al dar de alta; se avisa al revisor, no se bloquea solo |
| Persona borra su cuenta | `business_members` se borra en cascada; la empresa sobrevive |
| Empresa quiere irse | Botón de baja: exporta todo en JSON, despublica, marca `closed`. Los datos se conservan 90 días por si vuelve |
| Gemini caído | Todo sigue funcionando con las rutas deterministas. Se marca `sin_ia` internamente; el usuario no ve un error |
| Empresa pide borrar sus datos | Mismo flujo que `delete_my_account` ya existente, adaptado |

---

## 9. Lo que define "terminado"

Al cerrar la Fase 5, todo esto debe ser cierto:

- Una persona `adult` puede crear una empresa, verificarla por dominio y ser aprobada.
- Esa empresa recibe 3-5 objetivos realistas, puede decir "no llego" y recibir una
  versión ajustada, y puede cerrar uno con evidencia.
- Esa empresa puede publicar un listado con afirmaciones tipificadas, que aparece en
  `/mercado` con su nivel visible y sale por interstitial.
- Una acción diaria relevante muestra "dónde conseguirlo" con listados reales.
- La empresa paga una cuota mensual por MercadoPago y si deja de pagar sus listados se
  despublican solos.
- `kid` y `teen` no ven nada de esto.
- Cada tabla nueva tiene RLS probada con un test que intenta leer datos ajenos.
- Nada de lo existente en la app de personas cambió de comportamiento.
