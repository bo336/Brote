# Referencia · Catálogo de palancas

> La biblioteca de acciones de mejora, por rubro. Cumple tres funciones:
>
> 1. **Es el camino sin IA** — cuando no hay `GEMINI_API_KEY` (que es hoy), los objetivos
>    salen de acá.
> 2. **Ancla a la IA** — se le pasan las palancas del rubro para que no invente.
> 3. **Es el fallback** — cuando el validador de realismo descarta una propuesta, se
>    reemplaza con una palanca de acá.

---

## Sobre los rangos de efecto

Los rangos son **órdenes de magnitud orientativos**, no promesas. Vienen de la práctica
habitual de eficiencia en PyMEs y varían enormemente con el punto de partida: un local
que nunca tocó nada tiene mucho más margen que uno que ya optimizó.

**Cómo se usan, y esto es importante:** el rango sirve para **dimensionar el objetivo**,
nunca para prometerle un resultado a la empresa. El texto que ve la empresa dice *"suele
mover entre 5% y 15%"*, con el "suele" bien visible, y el campo `confianza` del objetivo
refleja qué tan seguro es en su caso.

**Ninguna palanca promete un número.** Prometen un rango típico y un método para
medirlo.

---

## Estructura de una palanca

```ts
interface Palanca {
  slug: string;
  titulo_plantilla: string;      // con {{variables}} del dossier
  dominio: DomainSlug;           // uno de los 13 de Brote
  rubros: string[];              // '*' = cualquiera
  metrica: string;
  unidad: string;
  efecto_min: number;            // fracción, ej. 0.05
  efecto_max: number;
  horizonte: 'trimestral' | 'semestral' | 'anual';
  ambicion: 'basico' | 'intermedio' | 'avanzado';
  esfuerzo_horas_mes: number;    // NUNCA > 6
  inversion: 'ninguna' | 'baja' | 'media';
  requiere: string[];            // condiciones del dossier
  porque: string;                // 2-3 frases, voz de producto
  pasos: string[];
  como_medir: string;
  evidencia_requerida: string;
  escalon_siguiente?: string;    // slug de la palanca que sigue
}
```

El campo **`escalon_siguiente`** es el que convierte el catálogo en un programa: cuando
una empresa cierra un objetivo, el siguiente ya está definido. Sin eso, cada objetivo es
un hecho suelto.

---

## Transversales (`rubros: ['*']`)

### `medir-energia` · básico

| | |
|---|---|
| **Título** | Medir el consumo eléctrico mensual para tener una línea de base |
| **Dominio** | `energia` · **Métrica** kWh/mes · **Horizonte** trimestral |
| **Esfuerzo** | 1 h/mes · **Inversión** ninguna |
| **Porqué** | "No se puede mejorar lo que no se mide. Tres meses de facturas alcanzan para saber cuánto gastás de verdad y en qué momentos, y a partir de ahí cualquier cambio se puede evaluar." |
| **Pasos** | Juntar las últimas 3 facturas · Anotar kWh y período en una planilla · Registrar cada factura nueva · Marcar el mes más alto y anotar qué pasó ese mes |
| **Medir** | Los kWh que figuran en la factura de la distribuidora |
| **Evidencia** | Foto o PDF de las 3 facturas |
| **Sigue** | `iluminacion-led` |

> **Es la palanca más importante del catálogo.** Es la primera que recibe cualquier
> negocio sin datos, y es lo que separa un programa serio de un generador de consejos.

### `iluminacion-led` · básico

| | |
|---|---|
| **Título** | Cambiar la iluminación de {{espacio}} a LED |
| **Dominio** | `energia` · **Métrica** kWh/mes · **Efecto** 5–15% del consumo total |
| **Horizonte** | trimestral · **Esfuerzo** 2 h/mes · **Inversión** baja |
| **Requiere** | `energia.linea_base` presente · presupuesto ≠ ninguno |
| **Porqué** | "La iluminación suele ser una porción grande del consumo en locales comerciales, y es de los pocos cambios que se pagan solos en meses. Además dura mucho más, así que dejás de reponer." |
| **Pasos** | Contar las luminarias y anotar su potencia · Pedir dos presupuestos · Empezar por el área de más horas encendida · Cambiar el resto en 2 tandas · Comparar la factura 2 meses después |
| **Medir** | Comparar kWh de la factura contra el mismo mes del año anterior |
| **Evidencia** | Factura de compra + foto del antes y el después |
| **Sigue** | `apagado-programado` |

### `apagado-programado` · intermedio

| | |
|---|---|
| **Título** | Reducir el consumo fuera del horario de atención |
| **Dominio** | `energia` · **Métrica** kWh/mes · **Efecto** 3–8% |
| **Horizonte** | trimestral · **Esfuerzo** 2 h/mes · **Inversión** ninguna |
| **Porqué** | "Los equipos en espera consumen todo el tiempo que el local está cerrado, que suele ser más de la mitad del mes. Una rutina de cierre es gratis y el efecto se sostiene solo." |
| **Pasos** | Recorrer el local después de cerrar y anotar qué quedó prendido · Definir qué se puede apagar sin riesgo · Escribir una lista de cierre de 5 puntos y pegarla en la puerta · Revisar a las 4 semanas |
| **Medir** | Comparar la factura del bimestre siguiente |
| **Evidencia** | Foto de la lista de cierre + facturas del antes y el después |

### `separacion-residuos` · básico

| | |
|---|---|
| **Título** | Separar {{materiales}} del residuo mixto |
| **Dominio** | `residuos` · **Métrica** bolsas de residuo mixto/semana · **Efecto** 15–35% |
| **Horizonte** | trimestral · **Esfuerzo** 3 h/mes · **Inversión** ninguna |
| **Porqué** | "Separar cartón y vidrio saca de la bolsa negra lo que más volumen ocupa. En muchos casos hay cooperativas de recuperadores que lo pasan a buscar sin costo, y en algunos incluso lo pagan." |
| **Pasos** | Contar cuántas bolsas de mixto se sacan por semana durante 2 semanas · Poner recipientes separados donde se genera el residuo, no en el fondo · Buscar una cooperativa o punto verde cercano · Definir quién lo saca y cuándo · Volver a contar |
| **Medir** | Conteo de bolsas los viernes, en una planilla |
| **Evidencia** | Planilla del antes y el después + foto de los recipientes |
| **Sigue** | `residuo-organico` |

### `residuo-organico` · intermedio

| | |
|---|---|
| **Título** | Desviar el residuo orgánico del contenedor |
| **Dominio** | `residuos` · **Métrica** kg/semana · **Efecto** 20–40% del residuo total en gastronomía |
| **Horizonte** | semestral · **Esfuerzo** 4 h/mes · **Inversión** baja |
| **Porqué** | "El orgánico es lo más pesado y lo que más problema genera en el contenedor. Compostarlo o entregarlo a alguien que lo composte saca peso y olor de un saque." |
| **Pasos** | Pesar el orgánico de una semana típica · Buscar quién lo reciba (huerta comunitaria, vecino con compost, servicio local) · Definir el recipiente y la frecuencia · Probar un mes · Pesar de nuevo |
| **Medir** | Balanza común, una vez por semana |
| **Evidencia** | Registro de pesajes + acuerdo con quien lo recibe |

### `proveedores-locales` · intermedio

| | |
|---|---|
| **Título** | Pasar {{porcentaje}}% de tus compras a proveedores de menos de {{km}} km |
| **Dominio** | `consumo` · **Métrica** % de compras · **Efecto** 10–25% por ciclo |
| **Horizonte** | semestral · **Esfuerzo** 4 h/mes · **Inversión** ninguna |
| **Requiere** | `insumos.puede_cambiar_proveedores = true` |
| **Porqué** | "Comprar cerca baja el transporte, acorta los plazos de reposición y te da un proveedor con el que podés hablar. Además es lo que te habilita a afirmar origen local en tus productos del Mercado." |
| **Pasos** | Listar los 10 insumos que más comprás y de dónde vienen · Marcar cuáles tienen alternativa a menos de {{km}} km · Pedir precio a dos de ellos · Cambiar uno y evaluar a los 2 meses · Repetir con el siguiente |
| **Medir** | Porcentaje sobre el gasto mensual de compras, con los remitos |
| **Evidencia** | Planilla de proveedores del antes y el después |
| **Sigue** | `origen-declarado` |

### `medir-agua` · básico

| | |
|---|---|
| **Título** | Establecer la línea de base de consumo de agua |
| **Dominio** | `agua` · **Horizonte** trimestral · **Esfuerzo** 1 h/mes · **Inversión** ninguna |
| **Porqué** | "En muchos servicios el agua no se mide y se paga por canilla libre, así que no hay factura de la que aprender. Un registro propio de 3 meses te dice si hay una pérdida o un uso desproporcionado." |
| **Pasos** | Ver si hay medidor · Si hay, anotar la lectura el mismo día de cada mes · Si no hay, estimar por uso principal y registrarlo · Marcar el mes más alto |
| **Medir** | Lectura del medidor o registro estimado |
| **Evidencia** | Foto de las lecturas o la planilla |

---

## Gastronomía (panadería, café, restaurante, bar)

### `merma-cocina` · intermedio

| | |
|---|---|
| **Título** | Bajar la merma de {{producto}} un {{pct}}% |
| **Dominio** | `alimentacion` · **Métrica** kg descartados/semana · **Efecto** 15–30% |
| **Horizonte** | trimestral · **Esfuerzo** 4 h/mes · **Inversión** ninguna |
| **Porqué** | "La merma es comida que pagaste, preparaste y tirás. Bajarla es, al mismo tiempo, el cambio ambiental más grande de una cocina y el que más se nota en el margen." |
| **Pasos** | Pesar lo que se descarta durante 2 semanas, separando preparación de sobrante · Identificar los 3 productos que más se descartan · Ajustar la producción de esos 3 · Definir qué hacer con el excedente del día · Volver a pesar |
| **Medir** | Balanza al cierre, planilla diaria |
| **Evidencia** | Planilla de 4 semanas del antes y el después |
| **Sigue** | `excedente-fin-de-dia` |

### `excedente-fin-de-dia` · intermedio

| | |
|---|---|
| **Título** | Dar salida al excedente del día en lugar de descartarlo |
| **Dominio** | `alimentacion` · **Métrica** kg recuperados/semana · **Horizonte** trimestral |
| **Esfuerzo** | 3 h/mes · **Inversión** ninguna |
| **Porqué** | "Lo que sobra al cierre todavía está bueno. Venderlo con descuento en la última hora, o coordinarlo con una organización del barrio, lo saca del contenedor y suma clientes nuevos." |
| **Pasos** | Pesar el excedente de una semana · Elegir el canal: descuento de última hora, app de rescate o donación · Probar 3 semanas · Medir cuánto se recuperó |
| **Medir** | Pesaje semanal del excedente recuperado vs descartado |
| **Evidencia** | Registro de pesajes + fotos o comprobantes del canal |

### `envases-para-llevar` · intermedio

| | |
|---|---|
| **Título** | Reemplazar los envases de {{producto}} por una alternativa mejor |
| **Dominio** | `residuos` · **Métrica** unidades de plástico de un solo uso/mes · **Efecto** 30–70% |
| **Horizonte** | semestral · **Esfuerzo** 3 h/mes · **Inversión** baja |
| **Porqué** | "Los envases de un solo uso son lo más visible que entrega tu negocio y lo primero que el cliente asocia con cómo trabajás. Cambiarlos es un cambio real y además se ve." |
| **Pasos** | Contar cuántos envases usás por mes y cuánto te cuestan · Pedir muestras a 2 proveedores de alternativas · Probar con un producto durante un mes · Evaluar costo y respuesta de la gente · Extender al resto |
| **Medir** | Conteo de compras de envases en los remitos |
| **Evidencia** | Remitos del antes y el después + foto del envase nuevo |

### `envase-propio` · avanzado

| | |
|---|---|
| **Título** | Que el {{pct}}% de las ventas de mostrador use envase del cliente |
| **Dominio** | `residuos` · **Métrica** % de ventas · **Efecto** 10–20% de las ventas de mostrador |
| **Horizonte** | semestral · **Esfuerzo** 3 h/mes · **Inversión** ninguna |
| **Porqué** | "Es el paso que más cuesta porque depende de que la gente cambie un hábito, y por eso necesita un incentivo concreto y un cartel bien visible. Cuando prende, el efecto es permanente y no te cuesta nada." |
| **Pasos** | Definir el incentivo (descuento fijo o un extra) · Cartel visible en el mostrador, no en la puerta · Que el personal lo ofrezca en cada venta durante el primer mes · Registrar cuántas ventas lo usan · Ajustar el incentivo si no llega |
| **Medir** | Conteo diario en la caja |
| **Evidencia** | Registro mensual + foto del cartel |

---

## Comercio minorista

### `bolsas-reutilizables` · básico
Métrica: unidades de bolsa de un solo uso/mes · Efecto 40–80% · trimestral · 2 h/mes ·
inversión baja · Sigue: `granel-basico`

### `granel-basico` · intermedio
Métrica: % del surtido disponible a granel · Efecto 10–20% por ciclo · semestral ·
5 h/mes · inversión media · Requiere espacio físico y habilitación bromatológica si es
alimento — **el paso 1 de la palanca es averiguar eso**.

### `origen-declarado` · básico
Métrica: % de productos con origen declarado en la etiqueta o el cartel · trimestral ·
3 h/mes · inversión ninguna. Es la palanca que **habilita la afirmación
`local_estacional` en el Mercado** — el vínculo entre Mejora y Mercado hecho explícito.

### `reparacion-y-repuestos` · avanzado
Métrica: unidades reparadas o repuestos vendidos/mes · semestral · 5 h/mes · inversión
baja. Para rubros donde el producto se rompe: indumentaria, calzado, electrodomésticos,
bicicletas.

---

## Producción de alimentos

### `medir-agua-proceso` · básico
Litros/mes · trimestral · 2 h/mes · ninguna. Sigue: `recirculacion-lavado`.

### `recirculacion-lavado` · avanzado
Litros/mes · Efecto 15–40% · anual · 5 h/mes · inversión media. Requiere presupuesto ≠
ninguno.

### `subproductos` · intermedio
kg desviados/mes · semestral · 4 h/mes · ninguna.
Porqué: *"Cáscaras, sueros y recortes suelen tener destino: alimentación animal,
compostaje, o incluso otro producto. Encontrarle uso al subproducto baja el residuo y a
veces abre una línea nueva."*

### `packaging-secundario` · intermedio
kg de cartón y film/mes · Efecto 10–25% · semestral · 3 h/mes · baja.

---

## Indumentaria y textil

### `stock-y-sobreproduccion` · intermedio
Unidades sin vender al cierre de temporada · Efecto 10–25% · anual · 4 h/mes · ninguna.
Porqué: *"La prenda que no se vende es el mayor impacto ambiental del rubro, porque ya
consumió agua, energía y trabajo. Producir series más chicas y reponer lo que se vende es
mejor negocio y mejor huella."*

### `fibra-y-origen` · intermedio
% de prendas con fibra y origen declarados · trimestral · 3 h/mes · ninguna.
Habilita `materiales_renovables` y `local_estacional`.

### `retazos` · básico
kg de retazo desviado/mes · trimestral · 2 h/mes · ninguna.

### `arreglos` · avanzado
Prendas arregladas/mes · semestral · 5 h/mes · baja.

---

## Servicios profesionales y oficina

> El rubro más difícil: el impacto directo es chico. **No inventes uno grande.** Las
> palancas honestas acá son de consumo interno, digital y compras.

### `papel-cero` · básico
Resmas/mes · Efecto 30–60% · trimestral · 2 h/mes · ninguna.

### `higiene-digital` · básico
GB almacenados o correos con adjuntos pesados/mes · trimestral · 2 h/mes · ninguna.
Porqué: *"El impacto de una oficina es chico y hay que ser honestos con eso. Pero el
almacenamiento en la nube que nadie borra sí suma, y ordenarlo cuesta poco."*

### `compras-de-oficina` · intermedio
% de insumos con criterio ambiental · semestral · 3 h/mes · ninguna.

### `movilidad-equipo` · intermedio
% de viajes en transporte público, bici o a pie · Efecto 10–25% · semestral · 3 h/mes ·
ninguna. Requiere ≥ 5 personas.

---

## Belleza y cuidado personal

### `agua-en-lavado` · intermedio
Litros/servicio · Efecto 15–30% · trimestral · 3 h/mes · baja.

### `envases-retorno` · avanzado
% de envases retornados · semestral · 4 h/mes · baja.

### `composicion-declarada` · básico
% de productos con composición completa a la vista · trimestral · 3 h/mes · ninguna.
Habilita `libre_de` en el Mercado — **con el campo `sustituto` bien cargado.**

---

## Logística y transporte

### `medir-combustible` · básico
Litros/mes o litros/100 km · trimestral · 2 h/mes · ninguna. Sigue: `optimizacion-rutas`.

### `optimizacion-rutas` · intermedio
Litros/100 km o km/entrega · Efecto 5–15% · semestral · 4 h/mes · ninguna.

### `carga-consolidada` · avanzado
Entregas/viaje · Efecto 10–20% · anual · 5 h/mes · ninguna.

### `mantenimiento-preventivo` · básico
Litros/100 km · Efecto 3–8% · trimestral · 2 h/mes · baja.
Porqué: *"Presión de neumáticos, filtros y puesta a punto no son una campaña ambiental:
es mantenimiento común que casi nadie hace a tiempo y que se paga solo en combustible."*

---

## Hotelería y turismo

### `medir-consumos-por-huesped` · básico
kWh y litros por noche ocupada · trimestral · 2 h/mes · ninguna.
Porqué: *"Medir por noche ocupada y no por mes es lo que te deja comparar temporada alta
con baja. Sin eso, cualquier número engaña."*

### `cambio-de-blanco` · intermedio
Litros de agua y kg de detergente/mes · Efecto 15–30% · trimestral · 3 h/mes · ninguna.

### `amenities-a-granel` · intermedio
Unidades de envase chico/mes · Efecto 60–90% · semestral · 3 h/mes · baja.

### `desayuno-local` · intermedio
% del desayuno de origen local · semestral · 4 h/mes · ninguna.

---

## Cómo se puntúa una palanca sin IA

```ts
function puntuarPalanca(p: Palanca, d: Dossier): number {
  let s = 0;

  // 1. Impacto potencial
  s += ((p.efecto_min + p.efecto_max) / 2) * 100;

  // 2. ¿Tienen con qué medirlo? Es lo que más define si el objetivo va a funcionar.
  if (tieneInstrumento(p.metrica, d)) s += 25;
  else if (p.ambicion === 'basico') s += 15;   // las de medición son valiosas justamente ahí
  else s -= 20;

  // 3. Huecos evidentes del dossier
  if (p.dominio === 'residuos' && d.residuos.separa === false) s += 25;
  if (p.dominio === 'energia'  && d.energia.tiene_factura)     s += 15;
  if (p.dominio === 'agua'     && d.agua.es_relevante)         s += 15;

  // 4. Restricciones declaradas: no negociables
  if (d.restricciones.presupuesto === 'ninguno' && p.inversion !== 'ninguna') return -999;
  if (p.esfuerzo_horas_mes > d.restricciones.horas_mes_disponibles)          return -999;

  // 5. Ya hecho
  if (solapaConYaHecho(p, d.ya_hecho)) return -999;

  // 6. Empezar barato es empezar
  if (p.esfuerzo_horas_mes <= 2) s += 10;

  return s;
}
```

La selección final toma **uno básico, uno intermedio y el mejor puntuado restante**, en
ese orden. Es una escalera, no tres cosas sueltas — y el primero que la empresa ve es
siempre el fácil, porque cerrar el primero es lo que hace que haya un segundo.

---

## Cómo crecer este catálogo

Está pensado para expandirse, igual que el catálogo de acciones de personas creció de
170 a 369 en el repo.

**Reglas para agregar una palanca:**

1. **Medible con algo que ya tienen.** Si necesita un instrumento nuevo, no entra.
2. **≤ 6 h/mes.** Sin excepción.
3. **Dentro de su control.** Nada que dependa del municipio, del gobierno o de los
   clientes.
4. **Con un rango de efecto honesto**, y `confianza: baja` si el rango es muy ancho.
5. **Con `escalon_siguiente`** salvo que sea el último de su cadena.
6. **En voz de producto**, sin motivación ni signos de exclamación. El `porque` se lee
   como se lo explicarías a un dueño de PyME que tiene poco tiempo y no quiere que le
   vendan humo.

**Meta razonable:** ~15 palancas por rubro × 12 rubros = ~180. Con eso, ningún negocio
se queda sin próximo objetivo durante años, que es el mismo problema que el repo ya
resolvió del lado de las personas (punto F15.14: "que el usuario NUNCA se quede sin nada
que hacer").
