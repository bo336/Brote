# Referencia · Registro de certificaciones

> Seed de la tabla `certifications`. **Es una tabla, no una constante en código**,
> justamente para poder corregirla sin deploy.

---

## ⚠️ Antes de usar esto

**Esta lista es un semillero, no una fuente autorizada.**

El registro oficial de entidades certificadoras de producción orgánica lo publica SENASA
en PDF; ese archivo **no pudo leerse automáticamente** durante la investigación (bloqueo
de acceso), así que las entidades listadas abajo salen de fuentes secundarias.

**Tarea obligatoria de la Fase 3, antes de publicar el primer listado con nivel E3:**

1. Abrir [el registro de SENASA](https://www.argentina.gob.ar/senasa/programas-sanitarios/producci%C3%B3n-organica/entidades-certificadoras)
   y descargar el PDF vigente.
2. Comparar contra esta tabla.
3. Corregir, agregar y desactivar lo que corresponda.
4. Anotar en `nota` la fecha de la verificación.

Una entidad certificadora que figure acá y no esté habilitada convierte un E3 en una
afirmación falsa **hecha por nosotros**. Es el punto más frágil de todo el sistema y
merece los diez minutos de verificación manual.

---

## Seed inicial

### Orgánico — Argentina (Ley 25.127, control de SENASA)

| slug | nombre | emisor | claims habilitados | nº | vence |
|---|---|---|---|---|---|
| `oia` | Certificación orgánica OIA | Organización Internacional Agropecuaria | `organico` | sí | sí |
| `argencert` | Certificación orgánica Argencert | Argencert | `organico` | sí | sí |
| `letis` | Certificación orgánica Letis | Letis S.A. | `organico` | sí | sí |
| `food-safety` | Certificación orgánica Food Safety | Food Safety S.A. | `organico` | sí | sí |
| `ecocert-ar` | Certificación orgánica Ecocert Argentina | Ecocert | `organico` | sí | sí |

### Forestal y materiales

| slug | nombre | emisor | claims | nº | vence |
|---|---|---|---|---|---|
| `fsc` | FSC | Forest Stewardship Council | `materiales_renovables`, `certificacion_tercero` | sí | sí |
| `pefc` | PEFC | PEFC International | `materiales_renovables` | sí | sí |
| `grs` | Global Recycled Standard | Textile Exchange | `contenido_reciclado` | sí | sí |
| `rcs` | Recycled Claim Standard | Textile Exchange | `contenido_reciclado` | sí | sí |

### Compostabilidad

| slug | nombre | emisor | claims | nº | vence |
|---|---|---|---|---|---|
| `ok-compost-industrial` | OK Compost Industrial | TÜV Austria | `compostable` | sí | sí |
| `ok-compost-home` | OK Compost Home | TÜV Austria | `compostable` | sí | sí |
| `en13432` | EN 13432 | Norma europea (varios organismos) | `compostable`, `biodegradable` | sí | sí |
| `astm-d6400` | ASTM D6400 | Norma ASTM (varios organismos) | `compostable` | sí | sí |

### Bienestar animal

| slug | nombre | emisor | claims | nº | vence |
|---|---|---|---|---|---|
| `leaping-bunny` | Leaping Bunny | Cruelty Free International | `bienestar_animal` | sí | sí |
| `vegan-society` | Vegan Trademark | The Vegan Society | `bienestar_animal` | sí | sí |

### Comercio justo y social

| slug | nombre | emisor | claims | nº | vence |
|---|---|---|---|---|---|
| `fairtrade` | Fairtrade | Fairtrade International | `comercio_justo` | sí | sí |
| `wfto` | Garantía WFTO | World Fair Trade Organization | `comercio_justo` | sí | sí |

### Gestión y empresa

| slug | nombre | emisor | claims | nº | vence | nota |
|---|---|---|---|---|---|---|
| `iso14001` | ISO 14001 | Varios organismos acreditados | `certificacion_tercero` | sí | sí | **Certifica un sistema de gestión, NO un producto.** El alcance es obligatorio |
| `sistema-b` | Empresa B | Sistema B / B Lab | `certificacion_tercero` | sí | sí | Certifica la empresa, no el producto. Alcance obligatorio |
| `rainforest` | Rainforest Alliance | Rainforest Alliance | `certificacion_tercero`, `organico` | sí | sí | Verificar el alcance del certificado |

---

## SQL del seed

```sql
insert into certifications (slug, nombre, emisor, pais, claims, tiene_numero, vence, url_registro, nota) values
  ('oia','Certificación orgánica OIA','Organización Internacional Agropecuaria','AR',
   '{organico}', true, true,
   'https://www.argentina.gob.ar/senasa/programas-sanitarios/produccion-organica/entidades-certificadoras',
   'VERIFICAR contra el registro de SENASA antes de habilitar E3'),
  ('argencert','Certificación orgánica Argencert','Argencert','AR','{organico}', true, true, null,
   'VERIFICAR contra el registro de SENASA antes de habilitar E3'),
  -- … el resto
  ('iso14001','ISO 14001','Organismos acreditados', null,'{certificacion_tercero}', true, true, null,
   'Certifica un SISTEMA DE GESTIÓN, no un producto. El alcance es obligatorio en el texto público.')
on conflict (slug) do nothing;
```

---

## Reglas de uso

**1 · Una certificación solo habilita los `claims` que tiene declarados.**
Es la comprobación de `05_ALGORITMOS.md` §3.1 y evita el abuso más común: mostrar un
certificado FSC para respaldar "libre de parabenos". Está en la base, no en la cabeza
del revisor.

**2 · Certificación de empresa ≠ certificación de producto.**
ISO 14001 y Sistema B certifican a la organización. Habilitan `certificacion_tercero`
con alcance obligatorio, y **nunca** habilitan una afirmación sobre un producto puntual.

**3 · Vigencia siempre.**
Si `vence = true`, el campo `cert_vence` es obligatorio. El job diario baja de E3 a E2
cualquier afirmación con certificado vencido, y avisa 30 días antes.

**4 · El número tiene que ser verificable a mano.**
Guardamos `url_registro` cuando existe, para que el revisor pueda contrastar de un clic.
No automatizamos la consulta a registros externos: son frágiles, cambian sin aviso, y
un falso negativo automático es peor que una verificación humana de treinta segundos.

**5 · Agregar una certificación es una decisión, no un formulario.**
Solo un admin puede insertar en `certifications`. Si una empresa presenta una que no
está, va a revisión: mirás si el emisor es serio, y si lo es, la agregás. Ese momento es
lo que mantiene el registro con valor.

---

## Qué hacer con una certificación desconocida

Flujo cuando una empresa presenta algo que no está en el registro:

1. La afirmación se guarda con `cert_slug = null` y **queda en E2** si hay documento.
2. Se notifica al revisor: *"Certificación no reconocida: {nombre}"* con el archivo.
3. El revisor decide:
   - **Es seria** → la agrega al registro, la afirmación pasa a E3.
   - **No es seria** (autocertificación, sello comprado, marca inventada) → queda en E2
     con una nota, y **el texto público no muestra el sello**.
4. Se le responde a la empresa con el motivo.

**Que un sello desconocido caiga a E2 en lugar de rechazarse es intencional:** hay
certificaciones locales legítimas y chicas que no conocemos todavía. Rechazarlas de plano
sería exactamente el error de "demasiado estricto" que hunde el catálogo.
