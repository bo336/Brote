# Referencia · Matriz de QA

> Se corre entera en la Fase 5, y por bloques al cerrar cada fase.
> Formato: **cada fila es una prueba manual con un resultado esperado sin ambigüedad.**

**Cuentas necesarias:**

| Alias | Tipo | Rol |
|---|---|---|
| `A-owner` | adult | Dueño de la empresa X |
| `A-editor` | adult | Editor de la empresa X |
| `B-ajeno` | adult | Sin relación con X |
| `T-teen` | teen | — |
| `K-kid` | kid | — |
| `ADMIN` | adult | Revisor |

---

## 1 · Alta y contexto (Fase 1)

| # | Prueba | Esperado |
|---|---|---|
| 1.1 | `A-owner` crea una empresa | Llega a `submitted`, aparece en `/panel/negocios` |
| 1.2 | `K-kid` busca el punto de entrada | No existe en la UI |
| 1.3 | `K-kid` va a `/negocio/alta` a mano | Redirigido a `/` con toast |
| 1.4 | `T-teen` idem | Redirigido |
| 1.5 | Llamar `create_business` como `kid` desde SQL | Excepción `solo_adultos` |
| 1.6 | `A-owner` crea una 4ª empresa como owner | Excepción `limite_negocios` |
| 1.7 | CUIT con dígito verificador inválido | Aviso amable, permite dejarlo vacío |
| 1.8 | Alta sin sitio ni Instagram | No deja avanzar el paso 2 |
| 1.9 | Descripción de 50 caracteres | No deja avanzar el paso 3 |
| 1.10 | Cerrar el navegador en el paso 3 y volver | Todo lo cargado sigue ahí |
| 1.11 | Cambiar a contexto de negocio | Shell de negocio, **sin parpadeo** |
| 1.12 | Volver a personal | App de siempre, `BottomTabBar` presente |
| 1.13 | Editar `brote_ctx` al id de una empresa ajena | Sin acceso; la cookie se limpia |
| 1.14 | Abrir el shell de negocio con el network tab | **No** se descarga three.js |
| 1.15 | `ADMIN` aprueba desde `/panel/negocios/[id]` | `A-owner` ve el cambio en `/negocio` |
| 1.16 | Atajos `A`/`P`/`R` con el foco en la nota | **No** disparan |
| 1.17 | Todo el alta a 360px | Sin scroll horizontal, sin cortes |

## 2 · Verificación (Fase 1)

| # | Prueba | Esperado |
|---|---|---|
| 2.1 | Meta tag correcto en un sitio real | Verificado, fuerza `Fuerte` |
| 2.2 | Meta tag ausente | *"Entramos a tu sitio pero no encontramos la etiqueta…"* |
| 2.3 | Dominio inexistente | *"No pudimos entrar a tu sitio…"* |
| 2.4 | Sitio que responde 403 | Sugiere DNS o archivo |
| 2.5 | TXT correcto | Verificado |
| 2.6 | TXT sin propagar | Menciona las 24 h de propagación |
| 2.7 | 21 intentos en un día | Bloqueado con mensaje claro |
| 2.8 | Cualquier error | **Nunca** un código HTTP ni "fetch failed" |

## 3 · Mejora (Fase 2)

| # | Prueba | Esperado |
|---|---|---|
| 3.1 | Dossier completo, **sin** clave de Gemini | 3 objetivos válidos, `generated_by: reglas` |
| 3.2 | Dossier completo, con clave | 3-5 objetivos, **todos** pasan el validador |
| 3.3 | Dossier con "No sé" en todo | Objetivos de **medición**, ambición `basico` |
| 3.4 | `presupuesto: ninguno` | **Ningún** objetivo con `inversion != ninguna` |
| 3.5 | "Ya hecho" menciona LED | **No** se propone `iluminacion-led` |
| 3.6 | Revisar cada objetivo generado | `esfuerzo_horas_mes ≤ 6` en todos |
| 3.7 | Aceptar 3 objetivos | Suma de esfuerzo ≤ 12 h/mes |
| 3.8 | Aceptar un 4º | Bloqueado con copy claro |
| 3.9 | "No llego", valor **dentro** de banda | Versión nueva con esa meta |
| 3.10 | "No llego", valor **fuera** de banda | Horizonte extendido, **meta intacta** |
| 3.11 | "Ya lo hacemos" **con** evidencia | `logrado` retroactivo + escalón siguiente |
| 3.12 | "Ya lo hacemos" **sin** evidencia | Pide evidencia, **no cierra** |
| 3.13 | "No aplica" | `descartado` + alternativa del mismo dominio |
| 3.14 | "Necesito más tiempo" | Horizonte sube, meta **igual** |
| 3.15 | Después de 3 replanificaciones | Historial completo, **v1 sigue accesible** |
| 3.16 | 9 replanificaciones en una semana | La 9ª bloqueada, controles manuales activos |
| 3.17 | Cerrar con evidencia | `en_revision`, aparece en `/panel/objetivos` |
| 3.18 | `ADMIN` aprueba el cierre | `logrado`, progreso y nivel recalculados |
| 3.19 | Valor final por debajo de la meta | Se puede cerrar como `logrado_parcial` |
| 3.20 | `B-ajeno` intenta leer el dossier de X | **Sin acceso** ← crítico |
| 3.21 | `A-editor` intenta cambiar el plan | Sin permiso |
| 3.22 | Toda la sección Mejora | **Cero** confeti, puntos, emojis en controles |
| 3.23 | Barra de Progreso de Mejora al 0% | Se ve al 0%, **no al 100%** |

## 4 · Afirmaciones (Fase 3)

| # | Prueba | Esperado |
|---|---|---|
| 4.1 | `no_toxico` sin documento | No se puede enviar (arranca en E2) |
| 4.2 | `huella_carbono` sin verificador | No se puede enviar |
| 4.3 | `biodegradable` con 24 meses | Rechazado |
| 4.4 | `reciclable` sin disponibilidad | Rechazado |
| 4.5 | `contenido_reciclado` sin porcentaje | Rechazado |
| 4.6 | `libre_de` sin sustituto | Rechazado |
| 4.7 | `libre_de` "gluten" en agua mineral | Rechazado por irrelevante |
| 4.8 | `energia_renovable` con 50% de procesos | Rechazado (umbral 80%) |
| 4.9 | `reduccion_origen` sin base de comparación | Rechazado |
| 4.10 | `certificacion_tercero` sin alcance | Rechazado |
| 4.11 | ISO 14001 usada para respaldar `organico` | Rechazado (no habilita ese claim) |
| 4.12 | FSC usado para respaldar `libre_de` | Rechazado |
| 4.13 | "100% ecológico" en la descripción | Rechazado |
| 4.14 | "Cura el estrés" con certificación válida | **Rechazado igual** |
| 4.15 | "natural" en el título | **Marcado**, no rechazado; decide el revisor |
| 4.16 | Certificadora fuera del registro | Queda en E2 + aviso al revisor |
| 4.17 | Certificado vencido ayer | Baja a E2, **listado sigue publicado** |
| 4.18 | Vista previa del texto público | Coincide exacto con lo publicado |

## 5 · Mercado (Fase 3)

| # | Prueba | Esperado |
|---|---|---|
| 5.1 | Listado con una afirmación E3 y otra E1 | **Las dos con su nivel propio** |
| 5.2 | Listado E1 publicado hoy | En la primera pantalla |
| 5.3 | El mismo, 10 días después | Un E3 con fit similar le gana |
| 5.4 | Empresa con 8 listados publicados | Máximo 2 seguidos por página |
| 5.5 | Buscar `<a href={url_destino}>` en el código | **0 resultados** — todo por interstitial |
| 5.6 | Salir de un listado | Clic registrado con `origen` |
| 5.7 | Salir 3 veces del mismo comercio en 30d | 3ª vez: toast, sin hoja modal |
| 5.8 | `K-kid` entra a `/mercado` | **404** |
| 5.9 | `T-teen` entra a `/mercado` | Sin precios, categorías limitadas |
| 5.10 | `B-ajeno` lee `listings` en `draft` de X | Sin acceso |
| 5.11 | Cualquiera lee `listing_clicks` | Sin acceso |
| 5.12 | 2 reportes `afirmacion_falsa` de 2 usuarios | **Despublicación automática** |
| 5.13 | 10 reportes del mismo usuario | Cuenta **uno** |
| 5.14 | Reporte desestimado | **No** penaliza a quien reportó |
| 5.15 | Empresa recibe un reporte | 7 días de descargo antes de confirmar |
| 5.16 | `grep` "verificado\|garantizado\|aprobado" en `es.json` | Ninguno **sobre un producto** |
| 5.17 | `grep` "Precio" solo, sin "de referencia" | 0 resultados |
| 5.18 | Cada badge de nivel | Linkea a `/legal/niveles` |
| 5.19 | Catálogo con 3 listados | `<EmptyState>` honesto, no grilla con huecos |
| 5.20 | Nivel en la tarjeta | Color **+ número + palabra** |

## 6 · Integración (Fase 4)

| # | Prueba | Esperado |
|---|---|---|
| 6.1 | Acción mapeada con 3+ listados | Módulo "Dónde conseguirlo" visible |
| 6.2 | Acción mapeada con 2 listados | **No se muestra nada** |
| 6.3 | `K-kid` / `T-teen` en una acción mapeada | No lo ven |
| 6.4 | Completar una acción | El módulo **no aparece** en ese flujo |
| 6.5 | Completar una acción tras salir a un listado | **0 puntos** por la salida |
| 6.6 | CPU throttling 6× al cargar la acción | El módulo **se ve** igual |
| 6.7 | Scrollear el catálogo arriba y abajo | Una impresión por sesión, no por scroll |
| 6.8 | Comparar la analítica con `listing_clicks` | Los números coinciden |
| 6.9 | "Qué te haría subir" | Propone algo real y accionable |
| 6.10 | Notificación de facturación | **No** aparece en la campana personal |

## 7 · Cobro (Fase 4)

| # | Prueba | Esperado |
|---|---|---|
| 7.1 | Suscripción en sandbox | Llega a `activa` |
| 7.2 | Webhook con firma inválida (curl) | **Rechazado** |
| 7.3 | El mismo evento dos veces | Se aplica **una** vez |
| 7.4 | Pago fallido | `en_gracia`, banner, listados publicados con −15 |
| 7.5 | Gracia vencida | Listados **despublicados**, nada borrado |
| 7.6 | Reactivar el pago | Listados vuelven a publicarse |
| 7.7 | 4º listado en plan Semilla | Guardado como **borrador**, no perdido |
| 7.8 | Llamar el RPC de publicar sobre el límite | Rechazado **en el servidor** |
| 7.9 | `cobro_activo = false` | Todo funciona, no pide tarjeta |
| 7.10 | Prueba de 14 días, día 15 sin tarjeta | Listados despublicados, Mejora en lectura |

## 8 · Sin IA (Fase 5)

Con `GEMINI_API_KEY` quitada:

| # | Prueba | Esperado |
|---|---|---|
| 8.1 | Alta completa | Funciona; el revisor ve datos crudos |
| 8.2 | Generación de objetivos | 3 objetivos de calidad presentable |
| 8.3 | Replanificación por los 4 tipos | Funciona por reglas |
| 8.4 | Envío de listado | Solo validador; nota al revisor |
| 8.5 | Cualquier flujo | **Ningún error visible al usuario** |
| 8.6 | Revisar `ai_jobs` | `status: 'fallback'` |

## 9 · Visual y accesibilidad (Fase 5)

| # | Prueba | Esperado |
|---|---|---|
| 9.1 | Cada pantalla nueva a 360 / 768 / 1440 | Sin cortes ni scroll horizontal |
| 9.2 | Modo claro y oscuro en todo | Legible, sin colores rotos |
| 9.3 | Cada `<Progress>` nuevo | Recibe `0..1`, **no** un porcentaje |
| 9.4 | Toda barra al primer render | Ninguna al 100% por error |
| 9.5 | CPU throttling 6× | Ningún elemento invisible por `opacity: 0` |
| 9.6 | `grep` de tokens de color nuevos en `tailwind.config.ts` | Todos definidos |
| 9.7 | Navegación solo con teclado | Alta, listado y panel completables |
| 9.8 | Lector de pantalla en la ficha | Nivel de cada afirmación anunciado |
| 9.9 | Simulación de daltonismo | El nivel sigue siendo legible |
| 9.10 | Espacio de negocio | **Cero** emojis en controles |
| 9.11 | `prefers-reduced-motion` activo | Sin animaciones |

## 10 · Bordes (Fase 5)

Los 9 de `02_ESPECIFICACION.md` §8:

| # | Prueba | Esperado |
|---|---|---|
| 10.1 | Deja de pagar | Gracia → despublicar → 90 días → exportar |
| 10.2 | Certificado vence | Baja de nivel, **no** se despublica |
| 10.3 | El `owner` borra su cuenta de Brote | Pasa al `admin` más antiguo, o `suspended` |
| 10.4 | URL de destino muere | 2 fallos: aviso · 4 fallos: despublicación |
| 10.5 | Alta con CUIT ya existente | Aviso al revisor, **no** bloqueo automático |
| 10.6 | Un miembro borra su cuenta | `business_members` en cascada; la empresa sobrevive |
| 10.7 | La empresa se da de baja | Exporta JSON, despublica, `closed`, 90 días de datos |
| 10.8 | Gemini caído a mitad de una generación | Fallback silencioso a reglas |
| 10.9 | La empresa pide borrar sus datos | Flujo equivalente a `delete_my_account` |

---

## Cómo registrar los resultados

Copiá esta matriz a un archivo de trabajo y marcá cada fila. Para las que fallan,
anotá **qué pasó exactamente**, no "no anda".

**Las 12 pruebas que no se negocian.** Si alguna falla, no se lanza:

`1.5` · `1.13` · `3.20` · `4.14` · `5.5` · `5.8` · `5.12` · `5.13` · `7.2` · `7.3` ·
`8.5` · `10.2`

Son, en orden: menores bloqueados en el servidor, la cookie no autoriza, el dossier es
privado, las afirmaciones de salud se rechazan siempre, ninguna salida evade el
interstitial, los chicos no ven el Mercado, el guardián de reportes funciona y no se
puede abusar, el webhook valida firma y es idempotente, la app funciona sin IA, y un
certificado vencido no borra un listado.
