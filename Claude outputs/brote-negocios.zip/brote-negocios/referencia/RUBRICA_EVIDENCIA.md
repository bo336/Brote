# Referencia · Rúbrica de evidencia

> Las 16 afirmaciones ambientales que se pueden hacer en el Mercado, y exactamente qué
> hace falta para cada nivel. Es la fuente de `lib/mercado/claims.ts` y del prompt de
> screening.
>
> **Origen:** los criterios de sustanciación vienen de los FTC Green Guides y de
> ISO 14021 (autodeclaraciones Tipo II). Ver `01_INVESTIGACION.md` §2.

---

## Cómo leer esta tabla

Cada afirmación tiene:

- **Campos obligatorios** — los que el formulario exige. Sin ellos no se puede enviar.
- **E1 Declarado** — qué basta para que la afirmación sea *específica* y publicable.
- **E2 Documentado** — qué documento la sube de nivel.
- **E3 Certificado** — qué certificación de tercero la sube al máximo.
- **Rechazo automático** — qué la bloquea sin llegar al revisor.
- **Texto público** — cómo se renderiza para el usuario final.

**Regla que atraviesa las 16:** la afirmación siempre declara **su alcance** (a qué parte
del producto aplica). "Orgánico" sin alcance no existe: es "harina orgánica" o "algodón
orgánico" o "el 60% de los ingredientes es orgánico".

---

## 1 · `organico`

| | |
|---|---|
| **Campos** | `alcance` (qué componente), `porcentaje` si es parcial |
| **E1** | Alcance declarado. Si es parcial, porcentaje declarado |
| **E2** | Factura o remito de un proveedor certificado, o ficha del insumo |
| **E3** | Certificación de una entidad habilitada por SENASA (Ley 25.127), con número y vigencia |
| **Rechazo** | "Orgánico" sin alcance · el término solo en el título sin afirmación cargada · producto de origen animal sin alcance claro |
| **Público** | *"Harina de trigo orgánica · Certificado por {entidad}, Nº {número}, vigente hasta {fecha}"* |

> En Argentina "orgánico" está **regulado**. Usar la palabra sin certificación es
> exponer a la empresa, no solo a nosotros. Cuando el nivel es E1 o E2, el texto público
> dice explícitamente *"sin certificación orgánica"* — es el único caso donde una
> etiqueta de nivel se refuerza con una aclaración adicional.

---

## 2 · `reciclable`

| | |
|---|---|
| **Campos** | `alcance`, `material`, **`disponibilidad_reciclaje`** (obligatorio) |
| **E1** | Material declarado + dónde se recicla en la práctica |
| **E2** | Foto del símbolo del material en el producto, o ficha técnica del envase |
| **E3** | Certificación de reciclabilidad del envase |
| **Rechazo** | "Reciclable" sin decir qué parte ni dónde |
| **Público** | *"Envase de papel kraft, reciclable donde haya recolección de papel"* |

> El criterio FTC exige calificar cuando la instalación no está disponible para el 60% de
> la gente. En Argentina la recolección diferenciada es desigual, así que
> `disponibilidad_reciclaje` es **siempre obligatorio**. Opciones del selector:
> `recoleccion_diferenciada_amplia` · `puntos_verdes_ciudad` · `cooperativa_local` ·
> `retorno_al_comercio` · `consultar_en_tu_zona`.

---

## 3 · `contenido_reciclado`

| | |
|---|---|
| **Campos** | `alcance`, **`porcentaje`** (obligatorio), `post_consumo` sí/no |
| **E1** | Porcentaje declarado |
| **E2** | Ficha técnica o declaración del proveedor del material |
| **E3** | Certificación de contenido reciclado (p. ej. GRS, RCS) con número |
| **Rechazo** | "Hecho con material reciclado" sin porcentaje |
| **Público** | *"Envase con 80% de contenido reciclado post-consumo"* |

---

## 4 · `compostable`

| | |
|---|---|
| **Campos** | `alcance`, **`tipo_compostaje`** (`domiciliario` \| `industrial`), `plazo_meses` |
| **E1** | Tipo y plazo declarados |
| **E2** | Ficha técnica del material |
| **E3** | Certificación de compostabilidad (p. ej. EN 13432, ASTM D6400, OK Compost) |
| **Rechazo** | "Compostable" sin distinguir domiciliario de industrial |
| **Público** | *"Compostable en compostaje industrial, se degrada en 6 meses"* |

> La distinción domiciliario/industrial es la que más se abusa y la que más importa: un
> material que solo composta a 58 °C en una planta es basura común en la casa de alguien.

---

## 5 · `biodegradable`

| | |
|---|---|
| **Campos** | `alcance`, **`plazo_meses`**, **`condiciones`** |
| **E1** | Plazo y condiciones declarados. **`plazo_meses` ≤ 12** |
| **E2** | Ensayo o ficha técnica del material |
| **E3** | Certificación de biodegradabilidad con norma citada |
| **Rechazo** | Sin plazo · `plazo_meses > 12` · "biodegradable" a secas |
| **Público** | *"Se biodegrada en 6 meses en condiciones de suelo húmedo"* |

> El criterio FTC es descomposición **completa** en un plazo razonable, referencia: un
> año. Por eso el validador rechaza duro cualquier plazo mayor a 12 meses.

---

## 6 · `libre_de`

| | |
|---|---|
| **Campos** | `sustancia`, `alcance`, `no_agregada_intencionalmente` (checkbox obligatorio), `sustituto` |
| **E1** | Sustancia nombrada + confirmación de no agregada + qué la reemplaza |
| **E2** | Ficha de composición del producto |
| **E3** | Certificación o ensayo de laboratorio |
| **Rechazo** | Sustancia genérica ("químicos", "tóxicos") · sustancia que **nunca** se usa en esa categoría (afirmación vacía) · sin declarar el sustituto |
| **Público** | *"Sin parabenos · Conservado con alcohol bencílico"* |

> Las tres condiciones FTC están en los campos: trazas, no agregada intencionalmente, y
> sin riesgo equivalente. **El campo `sustituto` es el que cierra la tercera**: si
> reemplazaste un parabeno por algo peor, se ve.
>
> El rechazo por "sustancia que nunca se usa" es importante: *"agua mineral sin gluten"*
> es técnicamente cierto y completamente engañoso. Lista de pares
> categoría→sustancia-irrelevante en `lib/mercado/claims.ts`.

---

## 7 · `no_toxico`

| | |
|---|---|
| **Campos** | `alcance`, `para_quien` (`personas` \| `ambiente` \| `ambos`), `respaldo` |
| **E1** | **No disponible.** Esta afirmación arranca en E2 |
| **E2** | Ficha de seguridad (FDS/MSDS) o ensayo |
| **E3** | Certificación de toxicidad de tercero |
| **Rechazo** | Sin documento · cualquier deriva hacia afirmación de salud |
| **Público** | *"No tóxico para uso doméstico según ficha de seguridad del fabricante"* |

> **La única afirmación que no admite E1.** El criterio FTC exige evidencia científica
> competente para personas **y** ambiente; una autodeclaración no alcanza y el riesgo de
> daño real es alto.

---

## 8 · `energia_renovable`

| | |
|---|---|
| **Campos** | `fuente` (`solar`\|`eolica`\|`hidro`\|`biomasa`\|`mixta`), `porcentaje_procesos`, `tiene_certificados` |
| **E1** | Fuente y porcentaje declarados. **`porcentaje_procesos` ≥ 80%** |
| **E2** | Factura del proveedor de energía o foto de la instalación |
| **E3** | Certificados de energía renovable a nombre de la empresa |
| **Rechazo** | `porcentaje_procesos < 80%` · fuente sin especificar · vendió sus certificados |
| **Público** | *"Producido con energía solar (90% de los procesos)"* |

> El umbral de 80% implementa el "todos o casi todos los procesos significativos" del
> criterio FTC. Y el chequeo de certificados vendidos evita el caso que el propio FTC
> señala como engañoso: generar renovable, vender los certificados, y aun así decir que
> "usás" energía renovable.

---

## 9 · `materiales_renovables`

| | |
|---|---|
| **Campos** | `material`, `porcentaje`, `por_que_renovable` |
| **E1** | Material identificado, porcentaje, explicación de la regeneración |
| **E2** | Ficha del material o del proveedor |
| **E3** | Certificación forestal o agrícola (FSC, PEFC) con número |
| **Rechazo** | "Materiales renovables" sin nombrar cuáles |
| **Público** | *"Madera de pino de forestación, 95% del producto"* |

---

## 10 · `reduccion_origen`

| | |
|---|---|
| **Campos** | `que_se_redujo`, `porcentaje`, **`comparado_con`** (obligatorio) |
| **E1** | Base de comparación explícita |
| **E2** | Documentación del cambio (especificación anterior y actual) |
| **E3** | No aplica — se queda en E2 |
| **Rechazo** | "10% menos" sin decir menos que qué |
| **Público** | *"25% menos plástico que nuestro envase anterior"* |

> El criterio FTC es tajante: la reducción sin base de comparación es engañosa. El campo
> se llama `comparado_con` y es obligatorio; el selector ofrece `nuestro producto
> anterior` · `el estándar de la categoría` · `otro` (con texto).

---

## 11 · `recargable`

| | |
|---|---|
| **Campos** | `mecanismo_recarga`, `donde_se_recarga` |
| **E1** | Mecanismo explicado y punto de recarga indicado |
| **E2** | Foto del sistema de recarga o del punto de venta a granel |
| **E3** | No aplica |
| **Rechazo** | "Recargable" sin decir dónde ni cómo |
| **Público** | *"Recargable en nuestro local de Vicente López y por envío de repuesto"* |

---

## 12 · `huella_carbono`

| | |
|---|---|
| **Campos** | `tipo` (`medida`\|`reducida`\|`compensada`), `alcance`, `metodologia`, `verificador` |
| **E1** | **No disponible.** Arranca en E2 |
| **E2** | Informe de cálculo con metodología citada |
| **E3** | Verificación de tercero del cálculo o de la compensación |
| **Rechazo** | "Carbono neutral" sin verificación de tercero · compensación sin registro identificable · compensar algo ya exigido por ley |
| **Público** | *"Huella medida según GHG Protocol, alcances 1 y 2, verificada por {tercero}"* |

> **"Carbono neutral" es la afirmación de mayor riesgo del catálogo.** Es la más
> demandada en el mundo y la que más rápido se cae. Sin verificación de tercero,
> rechazo automático. Sin excepciones ni para el plan Bosque.

---

## 13 · `bienestar_animal`

| | |
|---|---|
| **Campos** | `tipo` (`sin_testeo`\|`vegano`\|`pastoreo`\|`libre_de_jaulas`), `alcance` |
| **E1** | Tipo y alcance declarados. Si es `sin_testeo`, aclarar si es del producto terminado o también de los ingredientes |
| **E2** | Declaración de proveedores o política escrita de la empresa |
| **E3** | Leaping Bunny, Cruelty Free International, Vegan Society, o certificación de bienestar animal |
| **Rechazo** | "Cruelty free" sin distinguir producto terminado de ingredientes |
| **Público** | *"Sin testeo en animales, producto terminado e ingredientes · Certificado por {entidad}"* |

> La distinción producto-terminado / ingredientes es el hueco clásico de esta
> afirmación, y por eso es un campo, no una nota al pie.

---

## 14 · `local_estacional`

| | |
|---|---|
| **Campos** | `origen` (localidad o provincia), `distancia_km` aproximada, `meses_temporada` si aplica |
| **E1** | Origen declarado con localidad |
| **E2** | Remito, factura de proveedor o foto del establecimiento |
| **E3** | Denominación de origen o sello regional reconocido |
| **Rechazo** | "Local" sin decir de dónde · "de estación" sin meses |
| **Público** | *"Producido en Mar del Plata, a 400 km · De estación: marzo a julio"* |

> **No viene de los Green Guides — es propia de Brote**, y es la que conecta con las
> acciones diarias del tipo "evitá comida de supermercado" y "comprá de estación". Es,
> en la práctica, la afirmación más útil del catálogo y la más fácil de sostener para una
> PyME argentina: casi cualquier productor puede decir de dónde viene su producto.

---

## 15 · `comercio_justo`

| | |
|---|---|
| **Campos** | `tipo` (`precio_justo`\|`cooperativa`\|`economia_social`\|`certificado`), `alcance` |
| **E1** | Tipo y alcance declarados |
| **E2** | Documentación de la relación comercial o de la cooperativa |
| **E3** | Fairtrade, WFTO, o registro de economía social reconocido |
| **Rechazo** | "Comercio justo" sin especificar el tipo de relación |
| **Público** | *"Elaborado por la cooperativa {nombre}, {localidad}"* |

---

## 16 · `certificacion_tercero`

Afirmación envolvente, para cuando la empresa tiene una certificación que no encaja en
las 15 anteriores.

| | |
|---|---|
| **Campos** | `cert_slug` (del registro), **`cert_numero`**, **`cert_vence`**, `alcance` |
| **E1** | — |
| **E2** | — |
| **E3** | Certificación del registro + número + vigencia + **alcance explícito** |
| **Rechazo** | Certificadora fuera del registro · sin número · vencida · alcance que excede lo que la certificación cubre |
| **Público** | *"{Certificación} · {emisor} · Nº {número} · vigente hasta {fecha} · Alcance: {alcance}"* |

> **El campo `alcance` es todo.** Una ISO 14001 certifica un *sistema de gestión
> ambiental*, no que un producto sea ecológico. Mostrarla sin alcance es exactamente el
> abuso que los criterios FTC señalan cuando dicen que un sello debe decir sobre qué
> certifica. El texto público **siempre** incluye el alcance.

---

## Lista negra global

Se rechaza en el **validador determinista** (no solo en el prompt), en cualquier campo de
texto de un listado. No admite calificador, no admite excepción.

### Afirmaciones absolutas sin sustento

```
100% ecológico · totalmente natural · no contamina · impacto cero ·
completamente sustentable · amigable con el planeta · el más ecológico ·
producto verde · eco-friendly · biodegradable al 100%
```

### Afirmaciones de salud (competencia de ANMAT)

```
cura · previene · trata · sana · desintoxica · detox · elimina toxinas ·
refuerza las defensas · fortalece el sistema inmune · adelgaza ·
antitumoral · antiviral · sin efectos secundarios
```

### Términos vagos que exigen calificador

Estos **no se rechazan**: se marcan y el revisor decide, porque a veces son parte del
nombre del producto.

```
natural · sustentable · consciente · responsable · limpio · puro · verde
```

---

## Cómo se implementa

`lib/mercado/claims.ts` exporta un registro tipado:

```ts
export const CLAIMS: Record<ClaimKind, ClaimSpec> = {
  contenido_reciclado: {
    nombre: 'Contenido reciclado',
    ayuda: 'Qué parte del producto está hecha con material recuperado.',
    campos: z.object({
      alcance: z.string().min(3),
      porcentaje: z.number().int().min(1).max(100),
      post_consumo: z.boolean(),
    }),
    e1: () => true,                                  // los campos ya la hacen específica
    e2: (c) => Boolean(c.evidencia_path),
    e3: (c) => Boolean(c.cert_slug && c.cert_numero && vigente(c.cert_vence)),
    textoPublico: (c) =>
      `${c.alcance} con ${c.porcentaje}% de contenido reciclado${c.post_consumo ? ' post-consumo' : ''}`,
    rechazos: [/reciclad[oa]/i],   // el término en el texto libre sin la afirmación cargada
  },
  // … las 15 restantes
};
```

**Un solo archivo**, consumido por el formulario, el validador, el screener de IA y la
UI pública. Si esta especificación se duplica en dos lugares, se desincronizan y el
sistema pierde su integridad en silencio.
