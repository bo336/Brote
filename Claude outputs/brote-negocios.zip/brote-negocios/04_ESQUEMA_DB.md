# 04 · Esquema de base de datos

> SQL listo para aplicar, agrupado por fase. Sigue la convención del repo: migraciones
> numeradas en `supabase/migrations/`, RLS en todo, funciones `security definer` con
> `search_path` fijo y `revoke ... from public, anon`.
>
> **Numeración:** la última migración del repo es `0037`. Estas arrancan en **`0038`**.
> Verificá el último número antes de escribir, por si el repo avanzó.

---

## 1. Convenciones obligatorias

Cada migración de esta carpeta cumple:

```sql
-- 1. Enums con guarda de duplicado (patrón que el repo ya usa)
do $$ begin create type x as enum (...); exception when duplicate_object then null; end $$;

-- 2. Toda tabla: RLS activa
alter table t enable row level security;

-- 3. Toda política: (select auth.uid()), nunca auth.uid() suelto   [lección 0021]
-- 4. Toda función: security definer + set search_path = public     [lección 0007]
-- 5. Toda función: revoke from public, anon; grant to authenticated [lección 0016]
-- 6. Toda FK: índice de cobertura                                   [lección 0017]
-- 7. Toda tabla con updated_at: trigger de touch
```

---

## 2. FASE 1 — `0038_negocios_fundaciones.sql`

### 2.1 Enums

```sql
do $$ begin create type business_status as enum
  ('draft','submitted','in_review','approved','suspended','rejected','closed');
exception when duplicate_object then null; end $$;

do $$ begin create type business_role as enum ('owner','admin','editor');
exception when duplicate_object then null; end $$;

do $$ begin create type evidence_tier as enum ('e0','e1','e2','e3','e4');
exception when duplicate_object then null; end $$;

do $$ begin create type verification_method as enum
  ('dominio_meta','dominio_dns','dominio_archivo','email_dominio','social_token','cuit_declarado');
exception when duplicate_object then null; end $$;

do $$ begin create type verification_status as enum ('pendiente','verificado','fallido','expirado');
exception when duplicate_object then null; end $$;

do $$ begin create type business_size as enum ('1','2-10','11-50','51-200','200+');
exception when duplicate_object then null; end $$;
```

### 2.2 `businesses`

```sql
create table if not exists businesses (
  id                uuid primary key default gen_random_uuid(),
  slug              text unique not null,
  nombre_comercial  text not null,
  razon_social      text,
  cuit              text,                          -- DECLARADO, nunca "verificado"
  rubro             text not null,
  tamano            business_size not null default '1',
  pais              text not null default 'AR',    -- v1 valida 'AR'; existe para el futuro
  provincia         text,
  ciudad            text,

  descripcion       text,                          -- el texto del paso 3 del alta
  logo_url          text,
  portada_url       text,

  sitio_web         text,
  instagram         text,
  whatsapp          text,
  email_contacto    text,

  status            business_status not null default 'draft',
  tier              evidence_tier   not null default 'e0',
  progreso_mejora   int             not null default 0,   -- 0..100

  score_ia          int,                           -- 0..100 del screener de alta
  informe_ia        jsonb,                         -- veredicto + riesgos + recomendación
  revision_note     text,                          -- lo que el revisor le pide
  revisado_por      uuid references profiles(id) on delete set null,
  revisado_at       timestamptz,
  ultima_revision   timestamptz,                   -- para el requisito de 12 meses de E4

  intereses         text[] not null default '{}',  -- 'mejora' | 'mercado'
  created_by        uuid references profiles(id) on delete set null,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create index if not exists idx_businesses_status   on businesses (status);
create index if not exists idx_businesses_tier     on businesses (tier);
create index if not exists idx_businesses_creador  on businesses (created_by);
create index if not exists idx_businesses_rubro    on businesses (rubro, provincia);
create unique index if not exists idx_businesses_cuit
  on businesses (cuit) where cuit is not null;
```

> **Nota sobre `cuit`:** único cuando no es nulo, para detectar duplicados. **No** es
> una validación de existencia: nadie consultó a ARCA. La UI dice "declarado".

### 2.3 `business_members`

```sql
create table if not exists business_members (
  business_id uuid not null references businesses(id) on delete cascade,
  user_id     uuid not null references profiles(id)   on delete cascade,
  role        business_role not null default 'editor',
  joined_at   timestamptz not null default now(),
  primary key (business_id, user_id)
);
create index if not exists idx_bmembers_user on business_members (user_id);
```

### 2.4 `business_verifications`

```sql
create table if not exists business_verifications (
  id           uuid primary key default gen_random_uuid(),
  business_id  uuid not null references businesses(id) on delete cascade,
  method       verification_method not null,
  token        text not null,
  target       text,                     -- dominio, handle, o casilla
  status       verification_status not null default 'pendiente',
  intentos     int not null default 0,
  ultimo_error text,                     -- mensaje HUMANO, no técnico
  evidencia_url text,                    -- captura, para social_token
  verified_at  timestamptz,
  created_at   timestamptz not null default now()
);
create index if not exists idx_bverif_business on business_verifications (business_id, status);
```

### 2.5 `ai_jobs` — el cache y la contabilidad de IA

```sql
create table if not exists ai_jobs (
  id           uuid primary key default gen_random_uuid(),
  kind         text not null,           -- 'alta' | 'objetivos' | 'replan' | 'listado'
  business_id  uuid references businesses(id) on delete cascade,
  input_hash   text not null,
  status       text not null default 'ok',   -- 'ok' | 'fallback' | 'error'
  modelo       text,
  request      jsonb,
  response     jsonb,
  tokens_in    int,
  tokens_out   int,
  created_at   timestamptz not null default now()
);
create unique index if not exists idx_ai_jobs_hash on ai_jobs (kind, input_hash);
create index if not exists idx_ai_jobs_business on ai_jobs (business_id, created_at desc);
create index if not exists idx_ai_jobs_dia on ai_jobs (created_at desc);
```

Sin RLS para `authenticated`: **solo `service_role`**. Es donde queda registrado todo lo
que se le mandó a Gemini, y sirve para auditar el gasto con un `count(*)` por día.

### 2.6 Funciones auxiliares

```sql
create or replace function brote_is_member(p_business uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from business_members
                 where business_id = p_business and user_id = (select auth.uid()));
$$;

create or replace function brote_biz_role(p_business uuid)
returns text language sql stable security definer set search_path = public as $$
  select role::text from business_members
  where business_id = p_business and user_id = (select auth.uid());
$$;

create or replace function brote_can_write(p_business uuid, p_min text default 'editor')
returns boolean language sql stable security definer set search_path = public as $$
  select case brote_biz_role(p_business)
    when 'owner'  then true
    when 'admin'  then p_min in ('admin','editor')
    when 'editor' then p_min = 'editor'
    else false end;
$$;

revoke execute on function brote_is_member(uuid)       from public, anon;
revoke execute on function brote_biz_role(uuid)        from public, anon;
revoke execute on function brote_can_write(uuid, text) from public, anon;
grant  execute on function brote_is_member(uuid)       to authenticated;
grant  execute on function brote_biz_role(uuid)        to authenticated;
grant  execute on function brote_can_write(uuid, text) to authenticated;
```

### 2.7 RLS de Fase 1

```sql
alter table businesses            enable row level security;
alter table business_members      enable row level security;
alter table business_verifications enable row level security;
alter table ai_jobs               enable row level security;

-- businesses: público solo lo aprobado; miembros ven el suyo entero
create policy "businesses publicas" on businesses for select
  using (status = 'approved');
create policy "businesses miembro" on businesses for select
  using (brote_is_member(id));
create policy "businesses crea" on businesses for insert
  with check (
    (select auth.uid()) = created_by
    and (select account_type from profiles where id = (select auth.uid())) = 'adult'
  );
create policy "businesses edita" on businesses for update
  using (brote_can_write(id, 'admin')) with check (brote_can_write(id, 'admin'));

-- members
create policy "bmembers lee" on business_members for select using (brote_is_member(business_id));
create policy "bmembers owner escribe" on business_members for all
  using (brote_biz_role(business_id) = 'owner')
  with check (brote_biz_role(business_id) = 'owner');

-- verifications: solo miembros leen; la escritura la hace la edge function (service_role)
create policy "bverif lee" on business_verifications for select using (brote_is_member(business_id));

-- ai_jobs: nadie de authenticated
-- (sin policies = sin acceso; solo service_role pasa por encima de RLS)
```

> ⚠️ **Recursión.** `businesses.status='approved'` es la primera policy y no llama a
> ninguna función, así que un `select` público no toca `business_members`. La policy de
> miembro sí, pero `brote_is_member` es `security definer`, lo que corta la recursión.
> Esto es exactamente por qué las funciones auxiliares existen. **Probalo**: un `select`
> anónimo sobre `businesses` no debe colgarse.

### 2.8 RPCs de Fase 1

```sql
-- Crea la empresa en borrador y hace owner al creador, en una sola transacción.
create or replace function create_business(
  p_nombre text, p_rubro text, p_tamano business_size,
  p_provincia text, p_ciudad text
) returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid; v_slug text; v_type text; v_owned int;
begin
  select account_type::text into v_type from profiles where id = auth.uid();
  if v_type is distinct from 'adult' then
    raise exception 'solo_adultos';
  end if;

  select count(*) into v_owned from business_members
   where user_id = auth.uid() and role = 'owner';
  if v_owned >= 3 then raise exception 'limite_negocios'; end if;

  v_slug := brote_slugify(p_nombre);
  insert into businesses (slug, nombre_comercial, rubro, tamano, provincia, ciudad, created_by)
  values (v_slug, p_nombre, p_rubro, p_tamano, p_provincia, p_ciudad, auth.uid())
  returning id into v_id;

  insert into business_members (business_id, user_id, role) values (v_id, auth.uid(), 'owner');
  return v_id;
end $$;

-- Los negocios del usuario, para el selector de contexto.
create or replace function my_businesses()
returns table (id uuid, nombre text, slug text, role text, status business_status, tier evidence_tier)
language sql stable security definer set search_path = public as $$
  select b.id, b.nombre_comercial, b.slug, m.role::text, b.status, b.tier
  from business_members m join businesses b on b.id = m.business_id
  where m.user_id = auth.uid()
  order by b.created_at;
$$;

-- Slug único y estable.
create or replace function brote_slugify(p text)
returns text language plpgsql stable set search_path = public as $$
declare base text; out text; n int := 0;
begin
  base := regexp_replace(lower(unaccent_safe(p)), '[^a-z0-9]+', '-', 'g');
  base := trim(both '-' from base);
  if base = '' then base := 'negocio'; end if;
  out := base;
  while exists (select 1 from businesses where slug = out) loop
    n := n + 1; out := base || '-' || n;
  end loop;
  return out;
end $$;
```

> `unaccent_safe` = envoltorio propio sobre `translate()` si la extensión `unaccent` no
> está habilitada. Verificá `select * from pg_extension` antes de asumirla.

**Grants:** `revoke` de `public, anon` y `grant` a `authenticated` en `create_business`
y `my_businesses`.

---

## 3. FASE 2 — `0039_mejora.sql`

```sql
do $$ begin create type goal_status as enum
  ('propuesto','activo','en_riesgo','en_revision','logrado','logrado_parcial','incumplido','descartado');
exception when duplicate_object then null; end $$;

do $$ begin create type goal_horizon as enum ('trimestral','semestral','anual');
exception when duplicate_object then null; end $$;

do $$ begin create type goal_ambition as enum ('basico','intermedio','avanzado');
exception when duplicate_object then null; end $$;

do $$ begin create type baseline_origin as enum ('factura','medicion','estimado','a_medir');
exception when duplicate_object then null; end $$;
```

### 3.1 `improvement_dossiers`

```sql
create table if not exists improvement_dossiers (
  business_id uuid primary key references businesses(id) on delete cascade,
  operacion     jsonb not null default '{}',
  energia       jsonb not null default '{}',
  residuos      jsonb not null default '{}',
  agua          jsonb not null default '{}',
  insumos       jsonb not null default '{}',
  logistica     jsonb not null default '{}',
  ya_hecho      text,
  restricciones jsonb not null default '{}',
  completitud   int not null default 0,       -- 0..100, calculado
  version       int not null default 1,
  updated_at    timestamptz not null default now(),
  created_at    timestamptz not null default now()
);
alter table improvement_dossiers enable row level security;
create policy "dossier miembro" on improvement_dossiers for all
  using (brote_is_member(business_id)) with check (brote_can_write(business_id, 'admin'));
```

> **Nunca** una policy de lectura pública acá. Es la operación interna del negocio.

### 3.2 `improvement_goals`

```sql
create table if not exists improvement_goals (
  id            uuid primary key default gen_random_uuid(),
  business_id   uuid not null references businesses(id) on delete cascade,
  version       int  not null default 1,
  parent_id     uuid references improvement_goals(id) on delete set null,  -- la versión anterior

  titulo        text not null,
  porque        text not null,
  dominio       text,                       -- uno de los 13 dominios de Brote
  palanca_slug  text,                       -- referencia al catálogo de palancas

  metrica       text not null,
  unidad        text not null,
  linea_base    numeric,
  origen_base   baseline_origin not null default 'a_medir',
  objetivo      numeric,
  valor_final   numeric,

  horizonte     goal_horizon  not null default 'trimestral',
  ambicion      goal_ambition not null default 'basico',
  esfuerzo_horas_mes  numeric not null,
  inversion     text not null default 'ninguna',   -- ninguna|baja|media
  como_medir    text not null,
  pasos         jsonb not null default '[]',
  evidencia_requerida text not null,
  si_no_llegas  text,
  confianza     text not null default 'media',     -- alta|media|baja

  status        goal_status not null default 'propuesto',
  generated_by  text not null default 'ia',        -- 'ia' | 'reglas' | 'manual'
  es_publico    boolean not null default false,

  inicia_at     timestamptz,
  vence_at      timestamptz,
  cerrado_at    timestamptz,
  aprobado_por  uuid references profiles(id) on delete set null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists idx_goals_business on improvement_goals (business_id, status);
create index if not exists idx_goals_vence    on improvement_goals (vence_at) where status = 'activo';
create index if not exists idx_goals_parent   on improvement_goals (parent_id);

alter table improvement_goals enable row level security;
create policy "goals miembro" on improvement_goals for all
  using (brote_is_member(business_id)) with check (brote_can_write(business_id, 'editor'));
create policy "goals publicos" on improvement_goals for select
  using (es_publico and status in ('logrado','logrado_parcial'));
```

### 3.3 `goal_checkins` — el historial de feedback

```sql
create table if not exists goal_checkins (
  id          uuid primary key default gen_random_uuid(),
  goal_id     uuid not null references improvement_goals(id) on delete cascade,
  business_id uuid not null references businesses(id) on delete cascade,
  autor_id    uuid references profiles(id) on delete set null,
  tipo        text not null,      -- 'no_llego'|'ya_hecho'|'no_aplica'|'mas_tiempo'|'avance'|'nota'
  mensaje     text not null,
  valor_reportado numeric,
  respuesta_ia jsonb,             -- qué devolvió la replanificación
  genero_version int,             -- la versión de objetivo que salió de acá
  created_at  timestamptz not null default now()
);
create index if not exists idx_checkins_goal on goal_checkins (goal_id, created_at desc);
alter table goal_checkins enable row level security;
create policy "checkins miembro" on goal_checkins for all
  using (brote_is_member(business_id)) with check (brote_is_member(business_id));
```

### 3.4 `goal_evidence`

```sql
create table if not exists goal_evidence (
  id          uuid primary key default gen_random_uuid(),
  goal_id     uuid not null references improvement_goals(id) on delete cascade,
  business_id uuid not null references businesses(id) on delete cascade,
  storage_path text not null,     -- bucket business-evidence
  nota        text,
  subido_por  uuid references profiles(id) on delete set null,
  created_at  timestamptz not null default now()
);
create index if not exists idx_gevidence_goal on goal_evidence (goal_id);
alter table goal_evidence enable row level security;
create policy "gevidence miembro" on goal_evidence for all
  using (brote_is_member(business_id)) with check (brote_can_write(business_id, 'editor'));
```

### 3.5 RPC de progreso

```sql
-- Progreso de Mejora: 0..100. Ciclos cerrados con evidencia, con decaimiento.
create or replace function brote_progreso_mejora(p_business uuid)
returns int language sql stable security definer set search_path = public as $$
  with cerrados as (
    select status, cerrado_at,
           case status when 'logrado' then 1.0 when 'logrado_parcial' then 0.5 else 0 end as peso,
           case ambicion when 'avanzado' then 1.5 when 'intermedio' then 1.2 else 1.0 end as mult
    from improvement_goals
    where business_id = p_business and status in ('logrado','logrado_parcial')
  )
  select least(100, coalesce(round(sum(
      peso * mult * 18                                    -- ~5-6 ciclos llegan a 100
      * exp(-extract(epoch from (now() - cerrado_at)) / (86400 * 540))  -- media vida ~18 meses
    ))::int, 0))
  from cerrados;
$$;
revoke execute on function brote_progreso_mejora(uuid) from public, anon;
grant  execute on function brote_progreso_mejora(uuid) to authenticated;
```

> **Por qué decae:** un negocio que cerró objetivos hace tres años y no volvió a hacer
> nada no es "en mejora". La media vida de 18 meses es larga a propósito: castiga el
> abandono, no la pausa estacional.

---

## 4. FASE 3 — `0040_mercado.sql`

```sql
do $$ begin create type listing_status as enum
  ('draft','pendiente','publicado','despublicado','rechazado','removido');
exception when duplicate_object then null; end $$;

do $$ begin create type listing_kind as enum ('producto','servicio');
exception when duplicate_object then null; end $$;

do $$ begin create type claim_status as enum
  ('borrador','pendiente','aprobada','rechazada','vencida');
exception when duplicate_object then null; end $$;

do $$ begin create type claim_kind as enum (
  'organico','reciclable','contenido_reciclado','compostable','biodegradable',
  'libre_de','no_toxico','energia_renovable','materiales_renovables',
  'reduccion_origen','recargable','huella_carbono','bienestar_animal',
  'local_estacional','comercio_justo','certificacion_tercero');
exception when duplicate_object then null; end $$;

do $$ begin create type report_reason as enum (
  'afirmacion_falsa','enlace_roto','no_es_el_producto','precio_muy_distinto','no_responde','otro');
exception when duplicate_object then null; end $$;
```

### 4.1 `certifications` — el registro editable

```sql
create table if not exists certifications (
  slug        text primary key,
  nombre      text not null,
  emisor      text not null,
  pais        text,
  claims      claim_kind[] not null default '{}',   -- a qué afirmaciones habilita
  tiene_numero boolean not null default true,
  vence       boolean not null default true,
  url_registro text,
  nota        text,
  activo      boolean not null default true,
  created_at  timestamptz not null default now()
);
alter table certifications enable row level security;
create policy "certs lee" on certifications for select using (activo);
```

> **Es una tabla, no una constante en código.** Es lo que permite corregir el registro
> de certificadoras de SENASA sin un deploy. Ver `referencia/CERTIFICACIONES.md` para
> el seed inicial y la advertencia sobre su verificación.

### 4.2 `business_claims`

```sql
create table if not exists business_claims (
  id            uuid primary key default gen_random_uuid(),
  business_id   uuid not null references businesses(id) on delete cascade,
  kind          claim_kind not null,
  alcance       text not null,          -- a qué aplica: "harina de trigo", "envase"
  enunciado     text not null,          -- la afirmación en palabras de la empresa
  datos         jsonb not null default '{}',   -- campos específicos del tipo (%, plazo, etc.)

  cert_slug     text references certifications(slug),
  cert_numero   text,
  cert_vence    date,
  evidencia_path text,                  -- bucket business-evidence

  tier          evidence_tier not null default 'e1',
  status        claim_status  not null default 'borrador',
  observacion   text,                   -- lo que el revisor pide
  revisado_por  uuid references profiles(id) on delete set null,
  revisado_at   timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists idx_claims_business on business_claims (business_id, status);
create index if not exists idx_claims_vence on business_claims (cert_vence)
  where cert_vence is not null and status = 'aprobada';

alter table business_claims enable row level security;
create policy "claims miembro" on business_claims for all
  using (brote_is_member(business_id)) with check (brote_can_write(business_id, 'editor'));
create policy "claims publicas" on business_claims for select
  using (status = 'aprobada' and (cert_vence is null or cert_vence >= current_date));
```

### 4.3 `listings`

```sql
create table if not exists listings (
  id            uuid primary key default gen_random_uuid(),
  business_id   uuid not null references businesses(id) on delete cascade,
  slug          text unique not null,
  tipo          listing_kind not null default 'producto',
  titulo        text not null,
  descripcion   text not null,
  imagenes      text[] not null default '{}',
  categoria     text not null,
  dominios      text[] not null default '{}',
  precio_referencia numeric,
  moneda        text default 'ARS',
  url_destino   text not null,
  disponibilidad text not null default 'online',  -- online|local|ambas
  zonas         text[] not null default '{}',

  status        listing_status not null default 'draft',
  score         numeric not null default 0,       -- MATERIALIZADO, ver 05_ALGORITMOS §4
  score_at      timestamptz,
  tier_efectivo evidence_tier not null default 'e1',  -- máximo tier de sus claims

  screening_ia  jsonb,
  observacion   text,
  publicado_at  timestamptz,
  link_fallos   int not null default 0,
  link_check_at timestamptz,

  created_by    uuid references profiles(id) on delete set null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists idx_listings_orden on listings (status, score desc, id)
  where status = 'publicado';
create index if not exists idx_listings_business on listings (business_id, status);
create index if not exists idx_listings_cat on listings (categoria) where status = 'publicado';
create index if not exists idx_listings_dominios on listings using gin (dominios);

alter table listings enable row level security;
create policy "listings publicos" on listings for select using (status = 'publicado');
create policy "listings miembro" on listings for all
  using (brote_is_member(business_id)) with check (brote_can_write(business_id, 'editor'));
```

### 4.4 `listing_claims` — la regla antihalo, en SQL

```sql
create table if not exists listing_claims (
  listing_id uuid not null references listings(id)        on delete cascade,
  claim_id   uuid not null references business_claims(id) on delete cascade,
  primary key (listing_id, claim_id)
);
create index if not exists idx_lclaims_claim on listing_claims (claim_id);
alter table listing_claims enable row level security;
create policy "lclaims lee" on listing_claims for select using (true);
create policy "lclaims escribe" on listing_claims for all
  using (exists (select 1 from listings l
                 where l.id = listing_id and brote_can_write(l.business_id, 'editor')))
  with check (exists (select 1 from listings l
                 where l.id = listing_id and brote_can_write(l.business_id, 'editor')));
```

> **Esta tabla es el mecanismo antihalo.** El tier de un listado sale de las
> afirmaciones **que ese listado tiene enganchadas**, no del tier de la empresa. Si el
> código en algún momento hace `listing.tier = business.tier`, el sistema perdió su
> integridad. La columna se llama `tier_efectivo` justamente para recordarlo.

### 4.5 `listing_clicks` y `listing_reports`

```sql
create table if not exists listing_clicks (
  id          bigserial primary key,
  listing_id  uuid not null references listings(id) on delete cascade,
  business_id uuid not null references businesses(id) on delete cascade,
  user_id     uuid references profiles(id) on delete set null,
  origen      text,                    -- 'catalogo'|'accion'|'perfil_negocio'|'busqueda'
  created_at  timestamptz not null default now()
);
create index if not exists idx_clicks_listing on listing_clicks (listing_id, created_at desc);
create index if not exists idx_clicks_business on listing_clicks (business_id, created_at desc);
alter table listing_clicks enable row level security;
-- Sin policy de select: la empresa lee agregados por RPC, nunca filas.

create table if not exists listing_reports (
  id          uuid primary key default gen_random_uuid(),
  listing_id  uuid not null references listings(id) on delete cascade,
  business_id uuid not null references businesses(id) on delete cascade,
  user_id     uuid references profiles(id) on delete set null,
  motivo      report_reason not null,
  detalle     text,
  estado      text not null default 'abierto',   -- abierto|confirmado|desestimado
  resuelto_por uuid references profiles(id) on delete set null,
  resuelto_at timestamptz,
  created_at  timestamptz not null default now()
);
create index if not exists idx_reports_listing on listing_reports (listing_id, estado);
create unique index if not exists idx_reports_unico
  on listing_reports (listing_id, user_id) where user_id is not null;
alter table listing_reports enable row level security;
create policy "reports inserta" on listing_reports for insert
  with check ((select auth.uid()) = user_id);
```

> El índice único evita que una sola persona reporte el mismo listado diez veces para
> forzar la despublicación automática. Es el ataque obvio; queda cerrado en el esquema.

### 4.6 Trigger de despublicación automática

```sql
create or replace function brote_report_guard()
returns trigger language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if new.motivo = 'afirmacion_falsa' then
    select count(distinct user_id) into n from listing_reports
     where listing_id = new.listing_id and motivo = 'afirmacion_falsa'
       and estado = 'abierto' and created_at > now() - interval '30 days';
    if n >= 2 then
      update listings set status = 'despublicado',
             observacion = 'Despublicado automáticamente: dos reportes de afirmación.'
       where id = new.listing_id and status = 'publicado';
    end if;
  end if;
  return new;
end $$;

create trigger trg_report_guard after insert on listing_reports
for each row execute function brote_report_guard();
```

### 4.7 RPC del catálogo

```sql
-- Catálogo paginado por cursor. Nunca offset.
create or replace function mercado_listados(
  p_categoria text default null,
  p_dominio   text default null,
  p_tier_min  evidence_tier default 'e1',
  p_zona      text default null,
  p_cursor_score numeric default null,
  p_cursor_id uuid default null,
  p_limit     int default 24
) returns setof jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'id', l.id, 'slug', l.slug, 'titulo', l.titulo, 'tipo', l.tipo,
    'imagen', coalesce(l.imagenes[1], null), 'categoria', l.categoria,
    'dominios', l.dominios, 'precio', l.precio_referencia,
    'tier', l.tier_efectivo, 'score', l.score,
    'negocio', jsonb_build_object('slug', b.slug, 'nombre', b.nombre_comercial,
                                  'logo', b.logo_url, 'tier', b.tier))
  from listings l join businesses b on b.id = l.business_id
  where l.status = 'publicado' and b.status = 'approved'
    and (p_categoria is null or l.categoria = p_categoria)
    and (p_dominio   is null or p_dominio = any(l.dominios))
    and (p_zona      is null or l.disponibilidad in ('online','ambas') or p_zona = any(l.zonas))
    and l.tier_efectivo >= p_tier_min
    and (p_cursor_score is null
         or (l.score, l.id) < (p_cursor_score, p_cursor_id))
  order by l.score desc, l.id desc
  limit least(p_limit, 48);
$$;
```

> La **re-ordenación por diversidad** (máx. 2 seguidos por empresa) se aplica **en el
> servidor de Next**, sobre la página devuelta, con el mismo patrón `0.7^apariciones`
> que usa el ranking de noticias. Hacerlo en SQL con window functions sobre un cursor
> es posible pero frágil; en TypeScript es 15 líneas y se testea.

---

## 5. FASE 4 — `0041_negocios_cobro_e_integracion.sql`

```sql
do $$ begin create type biz_plan as enum ('semilla','raiz','bosque');
exception when duplicate_object then null; end $$;

do $$ begin create type biz_sub_status as enum
  ('pendiente','activa','en_gracia','pausada','cancelada','vencida');
exception when duplicate_object then null; end $$;

create table if not exists business_subscriptions (
  id            uuid primary key default gen_random_uuid(),
  business_id   uuid not null references businesses(id) on delete cascade,
  plan          biz_plan not null default 'semilla',
  status        biz_sub_status not null default 'pendiente',
  provider      text not null default 'mercadopago',
  external_id   text unique,
  monto         numeric,
  moneda        text default 'ARS',
  precio_bloqueado boolean not null default false,   -- fundadores
  periodo_fin   timestamptz,
  gracia_fin    timestamptz,
  raw           jsonb not null default '{}',
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists idx_bsubs_business on business_subscriptions (business_id, status);
create index if not exists idx_bsubs_periodo  on business_subscriptions (periodo_fin)
  where status in ('activa','en_gracia');
alter table business_subscriptions enable row level security;
create policy "bsubs owner lee" on business_subscriptions for select
  using (brote_biz_role(business_id) = 'owner');

-- Puente acciones ↔ mercado
create table if not exists activity_market_hints (
  activity_id uuid not null references activities(id) on delete cascade,
  categoria   text not null,
  dominios    text[] not null default '{}',
  texto_puente text,
  activo      boolean not null default true,
  primary key (activity_id, categoria)
);
alter table activity_market_hints enable row level security;
create policy "hints lee" on activity_market_hints for select using (activo);

-- Notificaciones de empresa: se reutiliza la tabla existente
alter table notifications add column if not exists business_id uuid
  references businesses(id) on delete cascade;
create index if not exists idx_notif_business on notifications (business_id, created_at desc)
  where business_id is not null;
```

> **Aislamiento de la campana.** La consulta existente de notificaciones personales
> debe pasar a filtrar `business_id is null`. Es un cambio de una línea que si se olvida
> hace que a una persona le lleguen avisos de facturación a la campana personal. Está
> marcado como criterio de aceptación en la Fase 4.

```sql
create or replace function brote_biz_plan(p_business uuid)
returns biz_plan language sql stable security definer set search_path = public as $$
  select coalesce((select plan from business_subscriptions
                   where business_id = p_business
                     and status in ('activa','en_gracia')
                   order by created_at desc limit 1), 'semilla');
$$;

create or replace function brote_biz_activo(p_business uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from business_subscriptions
                 where business_id = p_business and status in ('activa','en_gracia'));
$$;
```

---

## 6. FASE 5 — `0042_negocios_endurecimiento.sql`

Contenido: el job diario, el de enlaces, el de facturación, el recálculo de `score`, y
los ajustes que la QA encuentre.

```sql
create or replace function brote_business_daily()
returns void language plpgsql security definer set search_path = public as $$
begin
  -- 1. Certificados vencidos: la afirmación baja de nivel
  update business_claims set tier = 'e2', status = 'vencida'
   where status = 'aprobada' and cert_vence is not null and cert_vence < current_date;

  -- 2. Objetivos vencidos
  update improvement_goals set status = 'incumplido'
   where status in ('activo','en_riesgo') and vence_at < now();

  -- 3. En riesgo: vencen en 7 días y sin check-in en 30
  update improvement_goals g set status = 'en_riesgo'
   where g.status = 'activo' and g.vence_at < now() + interval '7 days'
     and not exists (select 1 from goal_checkins c
                     where c.goal_id = g.id and c.created_at > now() - interval '30 days');

  -- 4. Progreso y tier de cada negocio
  update businesses b set progreso_mejora = brote_progreso_mejora(b.id)
   where b.status = 'approved';
  perform brote_recalcular_tiers();

  -- 5. Score del catálogo
  perform brote_recalcular_scores();
end $$;
```

Las funciones `brote_recalcular_tiers()` y `brote_recalcular_scores()` implementan
literalmente lo que dice `05_ALGORITMOS.md` §3 y §4. **No las inventes: están
especificadas ahí con sus pesos.**

---

## 7. Buckets de Storage

```sql
insert into storage.buckets (id, name, public)
values ('business-logos','business-logos', true),
       ('listing-images','listing-images', true),
       ('business-evidence','business-evidence', false)
on conflict (id) do nothing;

-- Evidencia: solo miembros del negocio dueño del prefijo, o admin.
create policy "evidence lee miembro" on storage.objects for select
  using (bucket_id = 'business-evidence'
         and brote_is_member((storage.foldername(name))[1]::uuid));
create policy "evidence sube miembro" on storage.objects for insert
  with check (bucket_id = 'business-evidence'
              and brote_can_write((storage.foldername(name))[1]::uuid, 'editor'));
```

> El `business_id` es el **primer segmento** de la ruta justamente para que esta policy
> sea una sola línea. No cambies el layout de rutas sin reescribirla.

---

## 8. Resumen: 14 tablas nuevas

| Fase | Tablas |
|---|---|
| 1 | `businesses`, `business_members`, `business_verifications`, `ai_jobs` |
| 2 | `improvement_dossiers`, `improvement_goals`, `goal_checkins`, `goal_evidence` |
| 3 | `certifications`, `business_claims`, `listings`, `listing_claims`, `listing_clicks`, `listing_reports` |
| 4 | `business_subscriptions`, `activity_market_hints` (+ columna en `notifications`) |

Volumen estimado con 100 empresas y 1.000 listados: **muy por debajo de 50 MB**, contra
los 500 MB de la capa gratuita. El único crecimiento real es `listing_clicks`; se le
aplica retención de **180 días** en el job diario, con un agregado mensual conservado
para siempre (mismo criterio que la retención de noticias de la migración `0024`).
