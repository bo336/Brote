# 03 · Arquitectura

> Cómo se inserta todo esto en el proyecto que ya existe, sin tocar lo que funciona.

---

## 1. Lo que hay hoy (leído del repo, no supuesto)

- **Next.js 14** App Router, TypeScript strict, React 18.
- Grupos de rutas: `app/(app)/` (shell autenticado con `TopBar` + `BottomTabBar` +
  `Sidebar`), `app/(auth)/`, `app/legal/`, `app/onboarding/`, `app/api/cron/`.
- **Supabase**: `@supabase/ssr`, helpers en `lib/supabase/{client,server,route,middleware}.ts`,
  RLS en todas las tablas, RPCs `security definer` con `search_path` fijo y
  `revoke ... from public, anon` (ver migración `0016`).
- `middleware.ts` refresca sesión y bloquea rutas.
- **TanStack Query** para datos de cliente, **Zustand** para estado de sesión/UI.
- **next-intl** sin locale en la URL (cookie `NEXT_LOCALE`).
- **Edge Functions** en Deno: `pip-chat`, `recommend-activities`, `refresh-news`,
  `send-push`, `verify-completion`, con `_shared/gemini.ts` (timeout, reintento, JSON,
  fallback) y `_shared/cors.ts`.
- **pg_cron + pg_net** para trabajos programados; fallback por `/api/cron/*` con
  `CRON_SECRET`.
- Tipos: `Database` laxo + tipos precisos a mano en `lib/supabase/rows.ts`.

**Regla:** todo lo nuevo usa estos mismos mecanismos. Cero librerías nuevas, cero
patrones nuevos. La única dependencia nueva permitida en todo el proyecto es el SDK de
MercadoPago en la Fase 4, y solo si no se resuelve con `fetch` (se resuelve con `fetch`
— ver `09_MONETIZACION.md`).

---

## 2. Mapa de rutas nuevas

```
app/
├── (app)/                          ← EXISTENTE, se toca lo mínimo
│   ├── acciones/[slug]/page.tsx    ← + módulo "Dónde conseguirlo" (Fase 4)
│   ├── explorar/page.tsx           ← + pestaña "Mercado" (Fase 4)
│   └── mercado/                    ← NUEVO. Vive acá para heredar el shell de persona
│       ├── page.tsx                    catálogo
│       ├── [slug]/page.tsx             ficha de listado
│       ├── negocio/[slug]/page.tsx     ficha pública de la empresa
│       └── salir/[listingId]/page.tsx  interstitial de salida
│
├── (business)/                     ← NUEVO GRUPO. Shell propio, formal
│   ├── layout.tsx                      sin BottomTabBar, sin Pip, sin mundo, sin ads
│   └── negocio/
│       ├── page.tsx                    resumen
│       ├── alta/page.tsx               formulario de alta (5 pasos)
│       ├── verificacion/page.tsx
│       ├── mejora/
│       │   ├── page.tsx                programa
│       │   ├── dossier/page.tsx
│       │   └── [goalId]/page.tsx       ficha de objetivo + feedback
│       ├── listados/
│       │   ├── page.tsx
│       │   ├── nuevo/page.tsx
│       │   └── [id]/page.tsx
│       ├── analitica/page.tsx
│       ├── equipo/page.tsx
│       └── plan/page.tsx
│
├── (app)/panel/                    ← EXISTENTE, se extiende
│   ├── negocios/page.tsx               cola de altas
│   ├── negocios/[id]/page.tsx          ficha de revisión
│   ├── listados/page.tsx               cola de listados
│   ├── objetivos/page.tsx              cola de cierres
│   └── reportes/page.tsx
│
└── api/
    ├── cron/verificar-enlaces/route.ts     ← NUEVO (Fase 5)
    └── pagos/mercadopago/webhook/route.ts  ← NUEVO (Fase 4)
```

### Por qué `/mercado` va en `(app)` y `/negocio` en `(business)`

El Mercado lo consume **una persona**: quiere la barra de siempre, su avatar, poder
volver a Hoy de un toque. El espacio de negocio lo consume **un profesional en modo
trabajo**: quiere un panel, no una app de hábitos. Grupos distintos = layouts distintos
sin un solo `if` condicional dentro de un layout compartido, que es donde estas cosas
se pudren.

---

## 3. Cambio de contexto persona ↔ empresa

**El punto que más fácil se hace mal.** Requisito: el servidor tiene que saber en qué
contexto está el usuario **antes** de renderizar, o hay parpadeo.

### 3.1 Dónde vive el contexto

Una cookie, legible en el servidor:

```
brote_ctx = "personal" | "biz:<uuid>"
```

- `httpOnly: false` (el cliente la lee para pintar el selector), `sameSite: 'lax'`,
  `secure` en producción, 1 año.
- **La cookie es una preferencia de UI, jamás una autorización.** Toda consulta valida
  la membresía contra `business_members` vía RLS. Si alguien edita la cookie a mano, no
  gana nada: no hay una sola query que confíe en ella.

### 3.2 Cómo se resuelve

`lib/negocio/context.ts`:

```ts
// Servidor. Devuelve el negocio activo o null, SIEMPRE validando membresía.
export async function getActiveBusiness(): Promise<ActiveBusiness | null>
```

Lee la cookie, y si dice `biz:<id>` consulta `business_members` con el cliente de
servidor. Si el usuario no es miembro → devuelve `null` **y limpia la cookie**. Se usa
en `app/(business)/layout.tsx` y en cada `page.tsx` de negocio.

### 3.3 Middleware

En `middleware.ts`, junto al refresco de sesión que ya existe:

- `/negocio/*` sin sesión → `/auth/login?next=...`
- `/negocio/*` con sesión pero sin negocio activo → `/negocio/alta`
- `/negocio/alta` con cuenta `kid` o `teen` → `/` con toast
- `/panel/*` sin flag de admin → 404 (ya existe este patrón, se respeta)

**No** poner lógica de negocio en el middleware más allá de estos redirects: corre en
cada request y es la forma más cara de equivocarse.

### 3.4 El selector

En el menú del avatar del `TopBar` (persona) y en el encabezado del shell de negocio.
Al elegir: `POST` a un server action que setea la cookie → `router.refresh()`. Nunca un
`window.location` a mano: rompe el estado de React Query sin necesidad.

> **Copy del selector**
> Encabezado: *"Estás viendo"*
> Opciones: *"Tu cuenta personal"* / *"[Nombre del negocio]"*
> Pie: *"Crear un negocio"* (solo `adult`, solo si tiene menos de 3 como `owner`)

### 3.5 Aislamiento de datos de cliente

React Query cachea por clave. Si una clave no incluye el negocio activo, un usuario que
cambia de empresa ve datos de la anterior. **Toda clave de query de negocio empieza con
`['biz', businessId, ...]`.** Sin excepción. Y al cambiar de contexto, el server action
también invalida el cache del cliente vía `refresh()`.

---

## 4. Seguridad y RLS

### 4.1 El principio

Todas las tablas nuevas con RLS activada. El acceso de una persona a datos de una
empresa **siempre** pasa por una función auxiliar, nunca por un `exists` copiado a mano
en 14 políticas distintas (así es como una queda mal escrita).

```sql
create or replace function brote_is_member(p_business uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from business_members
    where business_id = p_business and user_id = (select auth.uid())
  );
$$;

create or replace function brote_biz_role(p_business uuid)
returns text language sql stable security definer set search_path = public as $$
  select role::text from business_members
  where business_id = p_business and user_id = (select auth.uid());
$$;
```

**Detalles que el repo ya aprendió y hay que repetir:**

- `(select auth.uid())` y no `auth.uid()` suelto — se evalúa una vez por consulta en
  lugar de una por fila. Es exactamente la corrección de la migración `0021`.
- `security definer` + `set search_path = public` en toda función.
- `revoke execute ... from public, anon` y `grant` solo a `authenticated`. Esta es la
  lección de la migración `0016`, donde el `EXECUTE` por defecto dejó funciones internas
  invocables por anónimos.
- Índice de cobertura sobre cada FK nueva (lección de `0017`).

### 4.2 Matriz de acceso

| Tabla | Lectura pública | Lectura miembro | Escritura |
|---|---|---|---|
| `businesses` | Solo `status='approved'` **y** columnas públicas | Todo el registro propio | `owner`/`admin` |
| `business_members` | No | Su empresa | `owner` |
| `business_verifications` | No | Su empresa | Sistema (edge function) |
| `business_claims` | Solo las aprobadas y vigentes | Su empresa | `owner`/`admin`/`editor` |
| `listings` | Solo `status='published'` | Su empresa | `owner`/`admin`/`editor` |
| `listing_clicks` | No | Agregado por RPC, nunca fila a fila | Sistema |
| `listing_reports` | No | Solo el conteo, no el reportante | Cualquier autenticado inserta |
| `improvement_dossiers` | **No, nunca** | Su empresa | `owner`/`admin` |
| `improvement_goals` | Solo si `es_publico` y `logrado` | Su empresa | Su empresa |
| `goal_checkins` | No | Su empresa | Su empresa |
| `ai_jobs` | No | No | Solo `service_role` |
| `business_subscriptions` | No | `owner` | Solo `service_role` |
| `certifications` | Sí (catálogo) | Sí | Solo admin |

**El dossier no se expone nunca.** Contiene la operación interna de un negocio. Que sea
imposible leerlo desde fuera es un compromiso de venta, y se prueba con un test en la
Fase 5.

### 4.3 Storage

Tres buckets nuevos:

| Bucket | Público | Contenido | Límite |
|---|---|---|---|
| `business-logos` | Sí | Logos y portadas | 1 MB, imagen |
| `listing-images` | Sí | Fotos de listados | 2 MB c/u, máx 4 |
| `business-evidence` | **No** | Certificados, facturas, documentos | 5 MB, pdf/jpg/png |

`business-evidence` es privado y se sirve por **URL firmada de 60 segundos** generada en
el servidor solo para miembros o admin. Ruta de archivo:
`business-evidence/<business_id>/<claim_id|goal_id>/<uuid>.<ext>` — el `business_id` como
primer segmento permite escribir la policy de Storage con un simple prefijo.

Las imágenes pasan por `lib/utils/image-compress.ts`, que ya existe en el repo.

---

## 5. Edge Functions nuevas

| Función | Fase | Qué hace | Fallback |
|---|---|---|---|
| `verify-business` | 1 | Chequea meta tag / DNS TXT / archivo / captura IG | Verificación manual por el revisor |
| `business-goals` | 2 | Genera y replanifica objetivos | Palancas del catálogo, determinista |
| `screen-listing` | 3 | Puntúa listado y afirmaciones | Solo validador determinista |
| `mp-subscribe` | 4 | Crea el preapproval de MercadoPago | Error legible + contacto manual |

Todas siguen el patrón de `supabase/functions/_shared/gemini.ts` que ya existe:
timeout, un reintento, parseo de JSON tolerante, y **fallback que nunca lanza**.

**Regla de oro:** una edge function jamás se llama durante el render de una página.
Se llama desde un server action o desde un cliente en respuesta a una acción explícita
del usuario, y la UI muestra un estado "procesando" con `<Skeleton>`.

---

## 6. Trabajos programados

Se suman a los 3 crons que ya existen, siguiendo la convención `brote-*`:

| Job | Frecuencia | Qué hace |
|---|---|---|
| `brote-business-daily` | Diario 01:00 AR | Vencimientos de certificados, objetivos por vencer y vencidos, decaimiento del Progreso de Mejora, recálculo de niveles |
| `brote-link-health` | Semanal, lunes 03:00 AR | HEAD a cada `url_destino`; 2 fallos → aviso, 4 → despublicar |
| `brote-billing` | Diario 02:00 AR | Gracia, despublicación por falta de pago, avisos de cobro próximo |

Todos con fallback por `/api/cron/*` protegido con `CRON_SECRET`, igual que los
existentes.

---

## 7. Módulos nuevos en `lib/`

```
lib/negocio/
├── context.ts          getActiveBusiness, setActiveBusiness (server action)
├── roles.ts            puede(rol, accion) — tabla de permisos en un solo lugar
├── niveles.ts          cálculo de nivel de empresa y de afirmación
├── verificacion.ts     tokens, métodos, estados
└── plan.ts             límites por plan (listados, objetivos, miembros)

lib/mercado/
├── claims.ts           las 16 afirmaciones: schema Zod por tipo, calificadores
├── ranking.ts          el algoritmo de orden (§4 de 05_ALGORITMOS)
├── categorias.ts       las 12 categorías
└── validador.ts        validación determinista de listados

lib/mejora/
├── palancas.ts         carga y filtrado del catálogo de palancas
├── realismo.ts         el validador de objetivos (§5 de 05_ALGORITMOS)
└── progreso.ts         cálculo del Progreso de Mejora

lib/api/
├── negocios.ts         queries de empresa
├── mercado.ts          queries del catálogo
└── mejora.ts           queries de objetivos
```

`lib/mercado/claims.ts` es el archivo más importante del Mercado: define, para cada
tipo de afirmación, el schema Zod de sus campos, qué calificadores son obligatorios, qué
evidencia sube de nivel y qué patrones se rechazan. **Un solo lugar**, consumido por el
formulario, el validador, el screener de IA y la UI pública. Si eso se duplica, la
integridad del sistema se desincroniza.

---

## 8. Tipos

Siguiendo lo que el repo ya hace: tipos precisos a mano en `lib/supabase/rows.ts` (o un
`rows-negocio.ts` si el archivo crece demasiado), y `npm run gen:types` cuando haga
falta regenerar.

Todo enum de Postgres tiene su unión de literales de TypeScript **derivada a mano y
comentada con la migración que la define**, para que no se desincronicen en silencio.

---

## 9. Rendimiento

- El catálogo se pagina **por cursor**, no por offset. Con `order by score desc, id`
  y un cursor compuesto. (El feed social del repo pagina por los primeros 40 y quedó
  anotado como deuda — no repetir ese patrón acá.)
- El `score` de ranking se **materializa** en una columna de `listings`, recalculada por
  el cron diario y en cada evento relevante (aprobación, reporte, cambio de nivel). **No
  se calcula en la query.** Ordenar por una expresión compleja sobre miles de filas es
  la forma garantizada de tener un catálogo lento.
- Índice: `(status, score desc)` y GIN sobre `dominios[]` y `categoria`.
- Las imágenes de listados usan `next/image` con `sizes` explícito.
- El shell de negocio **no carga three.js, ni framer-motion pesado, ni Leaflet**. Es un
  panel: tiene que abrir instantáneo. Verificar en la Fase 5 que el bundle de
  `(business)` no importe nada de `components/mundo/`.

---

## 10. Qué NO se toca del repo existente

Lista explícita, para que ninguna fase se pase de la raya:

- Nada de `components/mundo/`, `lib/mundo*`, `lib/ranks.ts`, `lib/points.ts`.
- El RPC `complete_activity` y toda la cadena de puntos. **Comprar no da puntos.**
- Las tablas `organizations`, `competitions`, `profiles.plan`, `subscriptions`.
- `lib/ads/policy.ts` — se lee para copiar su filosofía, no se modifica.

Cambios permitidos en archivos existentes, y son estos y solo estos:

| Archivo | Cambio | Fase |
|---|---|---|
| `middleware.ts` | Redirects de `/negocio/*` | 1 |
| `components/nav/TopBar.tsx` | Selector de contexto en el menú del avatar | 1 |
| `app/(app)/panel/page.tsx` | Enlaces a las colas nuevas | 1 |
| `lib/supabase/rows.ts` | Tipos nuevos | todas |
| `messages/es.json`, `messages/en.json` | Strings nuevos | todas |
| `app/(app)/acciones/[slug]/page.tsx` | Módulo "Dónde conseguirlo" | 4 |
| `app/(app)/explorar/page.tsx` | Pestaña "Mercado" | 4 |
| `vercel.json` | Cron nuevo | 5 |
| `CONTINUE.md`, `IMPROVEMENT_PLAN.md` | Bitácora | 5 |
