# FASE 3 · Mercado

> **Objetivo:** que una empresa publique productos y servicios con afirmaciones
> ambientales tipificadas y con nivel de evidencia, y que un usuario los encuentre,
> entienda qué está mirando y salga hacia el sitio del comercio.
>
> Es la fase con más riesgo legal y de reputación. **Nada acá es opcional.**

**Leer antes:** `02_ESPECIFICACION.md` §5 · `04_ESQUEMA_DB.md` §4 · `05_ALGORITMOS.md`
§3 y §4 · `06_PROMPTS_IA.md` §4 · `referencia/RUBRICA_EVIDENCIA.md` (completo) ·
`referencia/CERTIFICACIONES.md` · `08_LEGAL_Y_CONFIANZA.md` (completo) ·
`07_DISENO_UI.md` §4.6-4.9.

**Prerrequisito:** Fase 2 terminada, con una empresa aprobada y verificada por dominio.

---

## 0. Tarea previa obligatoria

**Antes de escribir código:**

- [ ] Abrir el [registro de SENASA de entidades certificadoras](https://www.argentina.gob.ar/senasa/programas-sanitarios/producci%C3%B3n-organica/entidades-certificadoras),
      descargar el PDF vigente y **verificar la lista** de `referencia/CERTIFICACIONES.md`
- [ ] Corregir, agregar o desactivar lo que corresponda antes del seed
- [ ] Anotar la fecha de verificación en el campo `nota` de cada fila

Una certificadora listada que no esté habilitada convierte un E3 en una afirmación falsa
**hecha por nosotros**. Son diez minutos y es el punto más frágil del sistema.

---

## 1. Migración `0040_mercado.sql`

De `04_ESQUEMA_DB.md` §4:

- [ ] 4 enums, incluido `claim_kind` con los **16** valores
- [ ] `certifications` + RLS + **seed verificado**
- [ ] `business_claims` + 2 índices + RLS
- [ ] `listings` + 4 índices + RLS
- [ ] `listing_claims` + índice + RLS  ← la regla antihalo
- [ ] `listing_clicks` + 2 índices + RLS **sin política de select**
- [ ] `listing_reports` + índice + **índice único `(listing_id, user_id)`**
- [ ] Trigger `brote_report_guard()`
- [ ] RPC `mercado_listados()` paginado por cursor
- [ ] `brote_recalcular_scores()` y `brote_recalcular_tiers()`, exactamente como
      `05_ALGORITMOS.md` §3 y §4 los especifican
- [ ] Bucket `listing-images`

---

## 2. `lib/mercado/claims.ts` — el archivo más importante

**Un solo lugar**, consumido por el formulario, el validador, el screener de IA y la UI
pública. Si esto se duplica, la integridad del sistema se desincroniza en silencio.

- [ ] Las **16** afirmaciones de `referencia/RUBRICA_EVIDENCIA.md`, cada una con:
      `nombre`, `ayuda`, schema Zod de `campos`, funciones `e1`/`e2`/`e3`,
      `textoPublico()`, `rechazos[]`
- [ ] `no_toxico` y `huella_carbono` **no tienen E1** — arrancan en E2
- [ ] `biodegradable` rechaza `plazo_meses > 12`
- [ ] `energia_renovable` rechaza `porcentaje_procesos < 80`
- [ ] `libre_de` exige `no_agregada_intencionalmente` **y** `sustituto`
- [ ] `libre_de` rechaza sustancias irrelevantes para la categoría (tabla de pares)
- [ ] `certificacion_tercero` exige `alcance` y lo incluye **siempre** en el texto público
- [ ] Lista negra global: absolutos + afirmaciones de salud + términos que solo se marcan

**Test unitario obligatorio:** para cada una de las 16, un caso válido y un caso que debe
rechazarse. Son 32 asserts y son lo que sostiene todo el sistema de evidencia.

---

## 3. `lib/mercado/validador.ts`

Determinista. **Corre siempre, con o sin IA.**

- [ ] Campos obligatorios por tipo de afirmación (desde `claims.ts`)
- [ ] URL de destino: `https`, HEAD request con timeout 8s, sin redirect a otro dominio
      no declarado
- [ ] Al menos 1 imagen, máximo 4, ≤2 MB cada una
- [ ] Título 10-70 caracteres, descripción 80-2000
- [ ] Lista negra sobre título **y** descripción
- [ ] Afirmaciones de salud → **rechazo duro**, sin importar la certificación
- [ ] Rubros incompatibles → rechazo
- [ ] Precio de referencia: si viene, numérico y > 0

---

## 4. `lib/mercado/ranking.ts`

Implementar `05_ALGORITMOS.md` §4, **con los pesos exactos**.

- [ ] `credibilidad(listing)` — §3.4, con `cobertura` y `frescura_evidencia`
- [ ] `fit(listing, usuario)` — §4.2, con 0.5 neutro sin sesión
- [ ] `actividad(listing, negocio)` — §4.3
- [ ] `salud(listing)` — §4.4, con el **piso de 50 impresiones** para el CTR
- [ ] `exploracion(listing)` — §4.5, decaimiento a 7 días, corte a 21
- [ ] `penalizaciones(listing)` — §4.6
- [ ] `reordenarPorDiversidad(items)` — §4.7, factor `0.7^apariciones`
- [ ] **Comentario arriba de la fórmula**, literal:

```ts
// El plan de la empresa NO entra en esta fórmula, nunca.
// Si algún día se agrega un término de plan acá, el catálogo pierde lo único
// que lo hace distinto de un directorio pago. Ver 09_MONETIZACION.md §2.1.
```

- [ ] Lo materializado es `0.40·C + 0.15·A + 0.10·S + 0.10·X − P`; el `0.25·F` se suma en
      vivo en el servidor de Next

---

## 5. Formulario de listado

### 5.1 `app/(business)/negocio/listados/nuevo/page.tsx`

- [ ] Pasos: básicos → imágenes → destino → **afirmaciones**
- [ ] Imágenes: subida a `listing-images`, compresión con
      `lib/utils/image-compress.ts`, reordenables, la primera es la principal
- [ ] Destino: normalización a `https`, verificación en vivo con estado visible
- [ ] Categoría de las 12; dominios de los 13 (múltiple, máximo 3)

### 5.2 El paso de afirmaciones — el corazón

- [ ] `<ChipRail>` con los 16 tipos, cada uno con su `ayuda` al lado
- [ ] Al elegir un tipo, **aparecen sus campos específicos**, desde el schema Zod
- [ ] **Vista previa en vivo** del texto público, con la etiqueta de nivel
- [ ] Al lado del botón de subir evidencia: *"→ sube a Nivel 2"*
- [ ] Al elegir certificación: selector desde `certifications` + número + vencimiento
- [ ] **Cero campos de texto libre para la afirmación.** No hay dónde escribir "es
      ecológico". Ese es todo el mecanismo
- [ ] Máximo 5 afirmaciones por listado
- [ ] Copy de encabezado, literal:
      *"Elegí qué querés afirmar de este producto. Cada una tiene su propio nivel de
      evidencia — no hace falta que tengas certificaciones para empezar."*

### 5.3 Reutilización de afirmaciones

- [ ] Una `business_claim` ya aprobada se puede **enganchar** a otro listado sin volver
      a revisarla
- [ ] Pero el revisor ve **a qué listados está enganchada** y puede desenganchar
- [ ] **Alerta al revisor** si una afirmación se engancha a un listado de categoría muy
      distinta a su `alcance`. Es el intento de halo más común: la certificación orgánica
      de la harina apareciendo en el producto de limpieza

---

## 6. Screening

### 6.1 Edge function `screen-listing`

- [ ] Prompt literal de `06_PROMPTS_IA.md` §4
- [ ] Corre **después** del validador determinista, nunca en lugar de él
- [ ] Cache por `input_hash`, límite 20/día por empresa
- [ ] Guarda en `listings.screening_ia`
- [ ] **El `nivel_sugerido` es sugerencia.** El nivel real lo calcula
      `lib/negocio/niveles.ts` desde la evidencia efectiva. Si la IA dice E3 y no hay
      número de certificado en la base, es E2. **La base gana siempre**
- [ ] Sin IA: solo el validador, y el revisor ve la nota *"Revisado solo por reglas —
      sin análisis automático."*

### 6.2 `/panel/listados`

- [ ] Cola de listados pendientes
- [ ] Al abrir: el listado **renderizado como lo vería un usuario**, con las
      observaciones de la IA al costado. Ver el resultado real es lo que evita aprobar
      algo que se lee mal
- [ ] Por afirmación: nivel calculado, nivel sugerido por IA, problemas, texto sugerido
- [ ] Acciones: publicar · pedir cambios · rechazar
- [ ] Atajos de teclado, igual que en la cola de negocios

### 6.3 Publicación acelerada

- [ ] Después de la **primera** aprobación, una empresa con verificación fuerte, sin
      reportes confirmados y con plan Raíz o Bosque entra en acelerada
- [ ] Sus listados se publican solos si el validador y el screener no marcan nada
- [ ] Van a una **cola de auditoría posterior** en `/panel/listados?modo=auditoria`
- [ ] Sin esto sos el cuello de botella para siempre

---

## 7. El catálogo público

### 7.1 `app/(app)/mercado/page.tsx`

- [ ] Hero con el gradiente **una sola vez**
- [ ] `<ChipRail>` de categorías + filtros de nivel mínimo, zona y orden
- [ ] Grilla 2/3/4 columnas
- [ ] **Nivel siempre visible** en la tarjeta, con color **+ número + palabra**
- [ ] Tokens `nivel.1/2/3` nuevos en `tailwind.config.ts`; nivel 4 = gradiente en el borde
- [ ] Scroll infinito **por cursor**, con `<Skeleton>` y `<BackToTop>`
- [ ] Re-ordenación por diversidad aplicada sobre cada página
- [ ] **Cero AdSense en `/mercado`**
- [ ] Cabecera "Qué es esto" de `08_LEGAL_Y_CONFIANZA.md` §4.4
- [ ] Vacío: `<EmptyState>` en voz de Pip, no una pantalla en blanco

### 7.2 `app/(app)/mercado/[slug]/page.tsx`

- [ ] Layout de `07_DISENO_UI.md` §4.8: jerarquía Apple, **un solo CTA**
- [ ] `.leaf-clip` en la imagen principal — **la única de la página**
- [ ] Precio: *"Precio de referencia informado por el comercio"*. **Nunca "Precio"**
- [ ] **"QUÉ AFIRMA ESTE PRODUCTO"**: cada afirmación con su nivel propio y su texto
      público completo
- [ ] Pie legal de `08_LEGAL_Y_CONFIANZA.md` §4.3
- [ ] Enlaces a `/legal/niveles` y a reportar

**El detalle que más importa de toda la fase:** que un producto muestre una afirmación en
E3 y otra en E1 al mismo tiempo. Es la regla antihalo hecha interfaz, y es lo que hace
que un usuario confíe en el catálogo entero.

### 7.3 `app/(app)/mercado/negocio/[slug]/page.tsx`

- [ ] Descripción, nivel, verificación, ubicación, listados
- [ ] Historial público de mejora **solo si** `es_publico` y el plan lo permite
      (el gating de plan llega en la Fase 4; acá dejá el punto de enganche)
- [ ] Insignia de fundador si corresponde

### 7.4 `app/(app)/mercado/salir/[listingId]/page.tsx`

- [ ] Registrar el clic en `listing_clicks` con `origen`
- [ ] Hoja modal con el texto **literal** de `08_LEGAL_Y_CONFIANZA.md` §4.1
- [ ] Redirección con `rel="noopener noreferrer nofollow"`
- [ ] A partir de la 3ª vez en 30 días para el mismo comercio → toast + redirección
      inmediata
- [ ] **Ninguna salida puede saltearse este paso.** Verificar que no exista ningún
      `<a href={url_destino}>` directo en toda la base de código

---

## 8. Menores

- [ ] `kid`: `/mercado` devuelve **404**, no una pantalla vacía
- [ ] `teen`: solo categorías no sensibles, **sin precios**
- [ ] Se aplica en el **RPC y en la RLS**, no escondiendo componentes
- [ ] `mercado_listados()` recibe el `account_type` y filtra en el servidor

---

## 9. Reportes

- [ ] Botón en la ficha, motivos tipificados, `otro` con detalle obligatorio
- [ ] Un usuario no puede reportar dos veces el mismo listado (índice único)
- [ ] Trigger de 2 reportes de `afirmacion_falsa` de usuarios distintos → despublicación
- [ ] `/panel/reportes`: cola con listado, motivo, reportante y estado
- [ ] **Derecho de descargo:** antes de confirmar, la empresa recibe el motivo y tiene
      **7 días** para responder con evidencia
- [ ] Confirmar → penalización + aviso + 30 días para corregir
- [ ] Desestimar → sin efecto, **no penaliza a quien reportó de buena fe**

---

## 10. Página pública de niveles

- [ ] `app/legal/niveles/page.tsx`, con el `LegalDoc` que ya existe
- [ ] Los 4 niveles con su texto exacto de `08_LEGAL_Y_CONFIANZA.md` §4.2
- [ ] Qué revisa Brote y qué no
- [ ] Cómo reportar
- [ ] **Linkeada desde cada badge de nivel de toda la app.** Que sea pública y explícita
      es parte de la defensa legal

---

## 11. Criterios de aceptación

- [ ] Las 16 afirmaciones se pueden cargar y cada una exige sus campos
- [ ] `no_toxico` sin documento **no** se puede enviar
- [ ] `biodegradable` con 24 meses se rechaza
- [ ] `reciclable` sin disponibilidad se rechaza
- [ ] `contenido_reciclado` sin porcentaje se rechaza
- [ ] "100% ecológico" en la descripción se rechaza
- [ ] "Cura el estrés" se rechaza aunque tenga certificación
- [ ] Un certificado FSC **no** puede respaldar `libre_de`
- [ ] Un certificado vencido deja la afirmación en E2, **el listado sigue publicado**
- [ ] Un listado con una afirmación E3 y otra E1 **muestra las dos con su nivel**
- [ ] Un listado nuevo E1 aparece en la primera pantalla el día 1
- [ ] A los 10 días, un E3 con fit similar le gana
- [ ] Una empresa con 8 listados no muestra más de 2 seguidos
- [ ] Toda salida pasa por el interstitial — verificado con `grep` de `url_destino`
- [ ] El clic se registra con su `origen`
- [ ] Dos reportes de dos usuarios → despublicación automática
- [ ] Diez reportes del mismo usuario → cuenta uno
- [ ] `kid` recibe 404 en `/mercado`; `teen` no ve precios
- [ ] Un usuario ajeno no puede leer `listings` en `draft`
- [ ] Nadie puede leer filas de `listing_clicks`
- [ ] Con Gemini apagado, publicar funciona igual (solo validador + revisión manual)
- [ ] Ningún badge dice "verificado", "garantizado" o "aprobado" **sobre un producto** —
      probar con `grep` sobre `messages/es.json`
- [ ] La palabra "precio" nunca aparece sola
- [ ] Los tests de `claims.ts` pasan: 16 casos válidos + 16 rechazos
- [ ] `npm run typecheck` y `npm run build` limpios

---

## 12. Definición de terminado

```
✔ Registro de certificaciones VERIFICADO contra SENASA
✔ Migración 0040 aplicada
✔ claims.ts con las 16 afirmaciones y sus 32 tests pasando
✔ Ranking implementado con los pesos exactos y el comentario de advertencia
✔ Publicar → aprobar → aparecer en el catálogo → salir por interstitial, de punta a punta
✔ Regla antihalo visible: un producto con dos niveles distintos en pantalla
✔ Menores bloqueados en el servidor
✔ /legal/niveles publicada y linkeada desde cada badge
✔ Checklist legal de 08_LEGAL_Y_CONFIANZA.md §10 revisado
✔ typecheck + build limpios
✔ CONTINUE.md actualizado con F16.3
```

---

## 13. Lo que NO se hace

- ❌ El puente con acciones diarias (Fase 4)
- ❌ Analítica para la empresa (Fase 4)
- ❌ Cobro y límites por plan (Fase 4) — dejá los puntos de enganche, no los uses
- ❌ Reseñas de usuarios (backlog de Fase 5, con su diseño antifraude)
- ❌ Búsqueda por texto libre: en la v1 alcanza con filtros. Si se agrega, que sea
      insensible a acentos, como ya aprendió el repo con el catálogo de acciones
