# FASE 5 · Endurecimiento y lanzamiento

> **Objetivo:** que esto se pueda poner delante de una empresa real que va a pagar.
> Seguridad, legales, performance, accesibilidad, QA completa, y el manual para operarlo.
>
> **Al terminar esta fase no queda nada pendiente del pedido original.**

**Leer antes:** `referencia/QA_MATRIZ.md` · `08_LEGAL_Y_CONFIANZA.md` §10 ·
`09_MONETIZACION.md` §10 · y todo lo anterior.

**Prerrequisito:** Fases 1 a 4 terminadas.

---

## 1. Migración `0042_negocios_endurecimiento.sql`

- [ ] `brote_business_daily()` completa (`04_ESQUEMA_DB.md` §6)
- [ ] `brote_recalcular_tiers()` y `brote_recalcular_scores()` finales
- [ ] Retención de `listing_clicks`: 180 días de detalle + agregado mensual permanente
- [ ] Los tres crons registrados: `brote-business-daily` (01:00), `brote-link-health`
      (lunes 03:00), `brote-billing` (02:00)
- [ ] `vercel.json` con los fallbacks de `/api/cron/*`
- [ ] Los arreglos que salgan de la QA

---

## 2. Auditoría de seguridad

### 2.1 RLS — pruebas reales, no lectura de políticas

Con **dos usuarios reales** (A miembro de la empresa X, B ajeno):

- [ ] B no lee `businesses` de X en estado `draft`
- [ ] B **no lee `improvement_dossiers` de X** ← el más importante de todos
- [ ] B no lee `improvement_goals` no públicos de X
- [ ] B no lee `goal_checkins` ni `goal_evidence` de X
- [ ] B no lee `business_verifications` de X
- [ ] B no lee `business_subscriptions` de X
- [ ] B no lee **ninguna** fila de `listing_clicks`
- [ ] B no lee `ai_jobs`
- [ ] B no lee `listings` en `draft` de X
- [ ] B no puede modificar nada de X
- [ ] Un `editor` no puede gestionar el equipo ni el plan
- [ ] Un `admin` no puede eliminar la empresa
- [ ] Editar la cookie `brote_ctx` al id de X no le da a B ningún acceso

### 2.2 Grants

```sql
-- Ninguna función nueva debe ser ejecutable por anon.
select p.proname
from pg_proc p join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public'
  and has_function_privilege('anon', p.oid, 'execute')
  and p.proname ~ '(business|listing|mercado|goal|claim|biz)';
-- Tiene que devolver 0 filas.
```

- [ ] Correr los **advisors de Supabase** y dejarlos limpios de items accionables
- [ ] Índice de cobertura en cada FK nueva

### 2.3 Storage

- [ ] `business-evidence` es privado: una URL directa **falla**
- [ ] La URL firmada de 60s funciona y **expira**
- [ ] B no puede leer evidencia de X aunque adivine la ruta
- [ ] Límites de tamaño y tipo aplicados en el servidor, no solo en el input

### 2.4 Superficie de la API

- [ ] Ningún secreto en el bundle del cliente: `grep` de `SERVICE_ROLE`, `MP_ACCESS`,
      `GEMINI` en `.next/static`
- [ ] El webhook de MercadoPago rechaza firma inválida
- [ ] Los RPCs validan el rol, no confían en el cliente
- [ ] Rate limiting en: envío de listado, replanificación, verificación, reportes

---

## 3. Menores

- [ ] `kid` → 404 en `/mercado`, `/mercado/[slug]`, `/negocio/*`
- [ ] `kid` → `create_business` lanza excepción llamado directamente por SQL
- [ ] `teen` → sin precios, sin categorías sensibles, sin crear empresa
- [ ] `teen` y `kid` → nunca ven "Dónde conseguirlo"
- [ ] Probado **con tres cuentas reales**, una de cada tipo, como el repo ya hizo con el
      feed social

---

## 4. Legales

Checklist completo de `08_LEGAL_Y_CONFIANZA.md` §10:

- [ ] `/legal/negocios` publicado
- [ ] **Revisado por un abogado argentino de consumo** ← el único costo real de arranque
- [ ] `/legal/privacidad` ampliado: dossier, clics, qué se manda a Gemini
- [ ] `/legal/niveles` publicado y linkeado desde **cada** badge
- [ ] Interstitial en el 100% de las salidas (verificado con `grep`)
- [ ] `grep` sobre `messages/es.json`: ningún "verificado", "garantizado" o "aprobado"
      **sobre un producto**
- [ ] "precio" nunca aparece solo
- [ ] Despublicación inmediata probada
- [ ] Trigger de dos reportes probado con dos usuarios distintos
- [ ] Lista negra de afirmaciones de salud activa en el validador determinista
- [ ] Rubros incompatibles bloqueados
- [ ] Aceptación de términos registrada: quién, cuándo, qué versión

---

## 5. Performance

- [ ] `/mercado` con 500 listados: primera carga < 2s en 4G simulada
- [ ] El bundle de `(business)` **no incluye** three.js, Leaflet ni framer pesado —
      verificar con `@next/bundle-analyzer` o el network tab
- [ ] `mercado_listados()` con 5.000 filas: < 100 ms (probar con `explain analyze`)
- [ ] Paginación por cursor, **sin offset** en ninguna consulta
- [ ] `next/image` con `sizes` explícito en todas las imágenes del catálogo
- [ ] `score` materializado; **ninguna consulta lo calcula al vuelo**
- [ ] Cache de las páginas públicas del Mercado con revalidación

---

## 6. Accesibilidad

- [ ] Foco visible AA en todo control nuevo
- [ ] Contraste AA en texto, AAA en los números de las franjas oscuras
- [ ] **El nivel nunca se comunica solo por color**: siempre color + número + palabra
- [ ] `prefers-reduced-motion` respetado
- [ ] Tablas con encabezados asociados y `<caption>` accesible
- [ ] Formularios: cada input con `<label>`, errores asociados por `aria-describedby`
- [ ] Navegación completa por teclado del alta, del formulario de listado y del panel
- [ ] Atajos del panel no disparan con el foco en un input
- [ ] Lector de pantalla: la ficha de listado se lee en orden lógico y el nivel de cada
      afirmación se anuncia

---

## 7. QA funcional

Correr entera `referencia/QA_MATRIZ.md`. Los recorridos completos:

- [ ] **Alta:** crear → verificar por dominio → aprobar → entrar al espacio
- [ ] **Mejora:** dossier → objetivos → aceptar → "no llego" → replanificar → cerrar con
      evidencia → aprobar → nivel sube
- [ ] **Mercado:** listado → afirmaciones → screening → aprobar → aparece → salir
- [ ] **Consumo:** persona entra a una acción → ve "Dónde conseguirlo" → toca → sale
- [ ] **Cobro:** prueba → suscribirse → pagar → fallar → gracia → vencer → despublicar
- [ ] **Reportes:** reportar → descargo → confirmar → penalizar
- [ ] **Bordes:** los 9 de `02_ESPECIFICACION.md` §8, uno por uno

### 7.1 Con Gemini apagado

- [ ] Quitar `GEMINI_API_KEY` y correr los cinco recorridos completos
- [ ] **Ningún error visible al usuario en ninguno**
- [ ] Los objetivos siguen siendo de calidad presentable
- [ ] `ai_jobs` registra `status: 'fallback'`

### 7.2 Visual

- [ ] Cada pantalla nueva a 360px, 768px y 1440px
- [ ] Modo claro y oscuro
- [ ] **Ninguna barra de progreso al 100% desde el primer render** — es el bug que el
      repo ya tuvo dos veces por pasar porcentaje a `<Progress>`, que toma `0..1`
- [ ] **Ningún elemento invisible** por animación de entrada desde `opacity: 0` — probar
      con throttling de CPU
- [ ] Ningún token de Tailwind inexistente (el caso `bg-brote-aqua` del repo)
- [ ] Cero emojis como control en el espacio de negocio

---

## 8. Arranque en frío

La parte de producto, no de código.

### 8.1 Datos de demostración

- [ ] **3 empresas de ejemplo** en un entorno de preview (nunca en producción), con
      listados y objetivos reales, para mostrar en reuniones de venta
- [ ] `/mercado` con menos de 12 listados usa un `<EmptyState>` honesto, no una grilla
      con huecos:
      *"Estamos armando el Mercado. Si tenés un negocio que produce distinto,
      escribinos."*

### 8.2 Los primeros 30

- [ ] Página pública `/negocios` explicando el programa, con formulario de interés
- [ ] Insignia de fundador implementada
- [ ] Precio bloqueado 12 meses funcionando
- [ ] Un documento de una página para mandar por WhatsApp: qué es, qué recibís, cuánto
      sale, cómo entrar

### 8.3 El orden de la conversación

De `09_MONETIZACION.md` §1. Que quede escrito en el material de venta:

> **Se vende Mejora primero, Mercado después.** El programa de objetivos entrega valor
> el día uno, sin necesidad de que exista tráfico. Vender el Mercado primero es prometer
> lo que todavía no podés entregar.

---

## 9. Documentación

### 9.1 `NEGOCIOS.html` en la raíz del repo

Siguiendo el estilo de `OPERACIONES.html` y `PUBLICIDAD.html`, en español:

- [ ] Cómo aprobar una empresa, con capturas
- [ ] Cómo leer el informe de la IA y en qué fijarse
- [ ] Cómo aprobar un listado y cuándo desconfiar de una afirmación
- [ ] Cómo agregar una certificación al registro
- [ ] Cómo manejar un reporte y el derecho de descargo
- [ ] Cómo cambiar precios y planes
- [ ] Cómo prender el cobro (la bandera `cobro_activo`)
- [ ] Qué hacer si Gemini se cae
- [ ] Los tres crons: qué hacen y cómo verificar que corrieron
- [ ] Costos actuales y en qué punto dejan de ser cero

### 9.2 Bitácora del repo

- [ ] `CONTINUE.md`: bloque **F16** con las 5 fases y su estado
- [ ] `IMPROVEMENT_PLAN.md`: sección `### F16 — NEGOCIOS` con el mismo formato que usan
      F12 a F15, incluida la sección de **deuda conocida** (que sea honesta: si algo
      quedó a medias, se anota, no se declara hecho)
- [ ] `README.md`: mención de las dos secciones nuevas
- [ ] `.env.example`: `MP_ACCESS_TOKEN`, `MP_WEBHOOK_SECRET`, y el remitente de email si
      se configuró

---

## 10. Backlog explícito

**Lo que queda fuera a propósito.** Anotado para que no se confunda con un olvido:

- **Reseñas de usuarios sobre negocios.** Necesita diseño antifraude (verificación de
  compra imposible sin ser el vendedor, defensa contra reseñas de competidores,
  moderación). Abrirlo sin eso es regalarle al sistema su primer vector de abuso.
- **Slots destacados del plan Bosque.** Etiquetados, fuera del orden orgánico.
- **Búsqueda por texto libre** en el Mercado. Insensible a acentos, como el catálogo de
  acciones del repo.
- **Chat empresa ↔ usuario.** Complica el rol de intermediario; evaluarlo con abogado.
- **Expansión a otros países.** El esquema ya lleva `pais`.
- **Certificación propia de Brote.** Cambiaría por completo la exposición legal. Es una
  decisión de negocio, no una feature.
- **Emails transaccionales completos.** Requiere un proveedor y un dominio.

---

## 11. Criterios de aceptación de la fase

- [ ] Las 4 auditorías de seguridad pasadas, **con dos usuarios reales**
- [ ] Advisors de Supabase limpios de items accionables
- [ ] Checklist legal completo, incluida la revisión del abogado
- [ ] `referencia/QA_MATRIZ.md` corrida entera
- [ ] Los cinco recorridos funcionan **con y sin Gemini**
- [ ] Performance dentro de los umbrales
- [ ] Accesibilidad verificada, incluido lector de pantalla en la ficha
- [ ] `NEGOCIOS.html` escrito y suficiente para operar sin preguntar nada
- [ ] Bitácora del repo actualizada, con deuda conocida honesta
- [ ] `npm run typecheck` y `npm run build` limpios
- [ ] Los tres crons registrados y **verificados con una corrida manual**

---

## 12. Definición de terminado — el proyecto completo

```
✔ Una persona adulta crea una empresa, la verifica por dominio y vos la aprobás
✔ Esa empresa recibe objetivos realistas, dice "no llego", recibe una versión
  ajustada, y cierra uno con evidencia
✔ Publica un listado con afirmaciones tipificadas, aparece en /mercado con su
  nivel visible, y la salida pasa por el interstitial legal
✔ Una acción diaria relevante muestra dónde conseguirlo, con listados reales
✔ La empresa paga por MercadoPago; si deja de pagar, sus listados se despublican
  solos y no se pierde nada
✔ kid y teen no ven nada de esto, verificado en el servidor
✔ Cada tabla nueva tiene RLS probada con un intento real de acceso ajeno
✔ Todo funciona sin clave de Gemini
✔ Nada de la app de personas cambió de comportamiento
✔ El dueño puede operar todo desde /panel sin tocar SQL
```

---

## 13. Después de la Fase 5

No es código: es la secuencia de `09_MONETIZACION.md` §10.

1. Conseguí **10 empresas a mano, gratis**, en modo fundador.
2. Sentate con ellas. Mirá cómo usan el producto. Arreglá lo que rompan.
3. Cuando **10 empresas usen Mejora dos meses seguidos** y al menos 5 digan que lo
   recomendarían, prendé `cobro_activo`.
4. A las fundadoras se les cobra recién al mes 4, con el precio bloqueado.

**El número que importa no es el ingreso del mes 1: es la renovación del mes 2.** Si las
empresas del mes 1 no renuevan, el problema es el producto, y ningún ajuste de precio lo
arregla.
