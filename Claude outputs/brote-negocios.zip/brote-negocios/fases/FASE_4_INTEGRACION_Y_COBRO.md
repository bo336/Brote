# FASE 4 · Integración y cobro

> **Objetivo:** conectar el Mercado con la app de personas, darle a la empresa una
> analítica honesta, y cobrar la cuota mensual por MercadoPago.
>
> Es la fase donde el sistema pasa de "funciona" a "vale la pena pagarlo".

**Leer antes:** `02_ESPECIFICACION.md` §6-§8 · `04_ESQUEMA_DB.md` §5 ·
`09_MONETIZACION.md` (completo) · `08_LEGAL_Y_CONFIANZA.md` §9 · `lib/ads/policy.ts` del
repo (para copiar su filosofía de dónde sí y dónde no).

**Prerrequisito:** Fase 3 terminada, con al menos 3 listados publicados de prueba.

---

## 1. Migración `0041_negocios_cobro_e_integracion.sql`

De `04_ESQUEMA_DB.md` §5:

- [ ] Enums `biz_plan`, `biz_sub_status`
- [ ] `business_subscriptions` + 2 índices + RLS
- [ ] `activity_market_hints` + RLS
- [ ] **Columna `business_id` en `notifications`** + índice parcial
- [ ] `brote_biz_plan()`, `brote_biz_activo()` con grants
- [ ] RPC de analítica agregada (nunca filas de `listing_clicks`)

### 1.1 El cambio de una línea que no se puede olvidar

```sql
-- La consulta de notificaciones personales AHORA debe filtrar:
--   where user_id = auth.uid() and business_id is null
```

Sin esto, a una persona le llegan avisos de facturación de su empresa a la campana
personal. Está en los criterios de aceptación.

---

## 2. El puente: "Dónde conseguirlo"

### 2.1 Mapeo

- [ ] Poblar `activity_market_hints` para las acciones de **sustitución**: "evitá comida
      de supermercado", "comprá a granel", "comprá de estación", "elegí productos de
      limpieza concentrados", y las equivalentes del catálogo del repo
- [ ] Empezar con **20-30 acciones**, no con las 369. Las que tienen una categoría del
      Mercado que las respalda de verdad
- [ ] `texto_puente` por acción, en voseo, específico

### 2.2 El módulo en `app/(app)/acciones/[slug]/page.tsx`

- [ ] **Debajo** de las instrucciones. **Nunca** en el camino de completar
- [ ] Encabezado `DÓNDE CONSEGUIRLO` como eyebrow + `texto_puente`
- [ ] 3 listados con su nivel visible + enlace al Mercado filtrado

**Las cinco reglas duras** — son la regla 2 de `lib/ads/policy.ts` aplicada acá:

- [ ] ❌ Nunca en el flujo de completar, ni en la celebración, ni en el set diario, ni en
      onboarding
- [ ] ❌ Nunca para `kid`. Para `teen`, sin precios y solo categorías no sensibles
- [ ] ❌ Se muestra **solo si hay ≥3 listados relevantes**. Con menos, no se muestra nada
- [ ] ❌ **Cero puntos por comprar.** Jamás. Verificar que no toque `complete_activity`
- [ ] ✅ `origen: 'accion'` en el clic, para poder medir de dónde viene el tráfico

> **Cuidado con la animación de entrada.** El repo perdió dos veces un componente por
> arrancar en `opacity: 0` con el frame loop estrangulado (CountUp y NewsNudge). Este
> módulo se renderiza **visible** y anima desde ahí, o no anima.

### 2.3 Pestaña en Explorar

- [ ] Tercera pestaña "Mercado" en el `<SectionTabs>` existente
- [ ] Vista compacta con los mejores del momento + enlace a `/mercado`
- [ ] Respetar que Explorar **abre en Novedades** (punto F14.2 del repo)

---

## 3. Analítica

### 3.1 `app/(business)/negocio/analitica/page.tsx`

- [ ] Franja `<PulseStrip>` oscura, **una sola vez**, con `<CountUp>`: impresiones,
      salidas, tasa, reportes resueltos
- [ ] Todos los números **reales**. Si no hay datos, `<EmptyState>`, no ceros
- [ ] Tabla por listado: impresiones, salidas, tasa. Estilada (encabezado, hover, orden)
- [ ] Origen del tráfico: catálogo / acciones / ficha / búsqueda
- [ ] Serie temporal de 30 días con `recharts`, que ya está en el repo

### 3.2 Impresiones

- [ ] Contar una impresión cuando la tarjeta entra al viewport (IntersectionObserver),
      con **debounce y deduplicación por sesión**
- [ ] Agregar por día en una tabla resumen: **no** una fila por impresión, o
      `listing_clicks` explota
- [ ] Retención: 180 días de detalle, agregado mensual para siempre

### 3.3 El bloque "Qué te haría subir"

**El motor de retención.** Reglas deterministas sobre el estado real:

- [ ] Afirmación en E1 con evidencia posible → *"Subir la ficha técnica llevaría
      'contenido reciclado' a Nivel 2 (+18% estimado de visibilidad)"*
- [ ] Objetivo activo cerca de vencer → *"Cerrar el objetivo de energía te sube el
      Progreso de Mejora a 78"*
- [ ] Listado sin imagen o con descripción corta → *"Los listados con 3 imágenes reciben
      más visitas"*
- [ ] Certificado por vencer → aviso con la fecha
- [ ] Máximo 3 sugerencias, ordenadas por impacto estimado

### 3.4 El aviso de honestidad

- [ ] Al pie, **siempre visible**, el texto literal de `09_MONETIZACION.md` §6
- [ ] Incluye la sugerencia del `?ref=brote` — es gratis, funciona con la analítica que
      ya usan, y es el tipo de detalle que hace que te recomienden

---

## 4. MercadoPago

### 4.1 Edge function `mp-subscribe`

- [ ] `POST /preapproval` con `fetch`. **Sin SDK** — son 300 kB para tres llamadas
- [ ] `external_reference = business_id` ← el hilo que conecta todo
- [ ] Access token **solo del lado servidor**, nunca en el cliente
- [ ] Devuelve `init_point`
- [ ] Precio desde `app_state`, **nunca hardcodeado**

### 4.2 Webhook `app/api/pagos/mercadopago/webhook/route.ts`

**Las cuatro reglas, en orden de importancia:**

- [ ] **1. Validar la firma `x-signature`.** Un webhook sin validar es una API pública
      para regalar suscripciones. Es lo primero que hay que escribir y lo primero que
      hay que testear
- [ ] **2. Nunca confiar en el cuerpo.** Trae un id; con ese id se consulta la API, y
      **esa** respuesta es la verdad
- [ ] **3. Idempotencia.** Clave única por `(external_id, evento)`. MercadoPago
      reintenta; el mismo evento dos veces no puede activar ni cobrar dos veces
- [ ] **4. Responder 200 rápido.** El trabajo pesado va aparte
- [ ] Mapear estados según la tabla de `09_MONETIZACION.md` §4.4
- [ ] Loguear todo en `business_subscriptions.raw`

### 4.3 `app/(business)/negocio/plan/page.tsx`

- [ ] Los 3 planes con la tabla comparativa de `09_MONETIZACION.md` §2
- [ ] Botón **"Suscribirme"**, no "MercadoPago" (punto F15.1 del repo). El logo va chico,
      debajo, como sello de confianza
- [ ] Prueba de 14 días **sin tarjeta**, con los días restantes visibles
- [ ] Estado de la suscripción, próximo cobro, cómo cancelar
- [ ] Insignia y precio de fundador si corresponde
- [ ] `back_url` → `/negocio/plan?estado=pendiente`, **informativo, nunca fuente de
      verdad**

### 4.4 Cron `brote-billing`

- [ ] Diario 02:00 AR
- [ ] Aviso 3 días antes del cobro
- [ ] Pago fallido → `en_gracia` + `gracia_fin` a 7 días + banner + notificación diaria
- [ ] Gracia vencida → `vencida` + **despublicar** listados (no borrar) + Mejora en
      lectura
- [ ] 90 días después → ofrecer exportar y cerrar
- [ ] Fallback por `/api/cron/*` con `CRON_SECRET`, igual que los crons existentes

---

## 5. Gating

### 5.1 `lib/negocio/plan.ts`

- [ ] `LIMITES` exacto de `09_MONETIZACION.md` §5
- [ ] `puedePublicar`, `puedeCrearObjetivo`, `puedeReplanificar`, `puedeInvitar`
- [ ] **Aplicado en el servidor, en el RPC.** Esconder un botón no es gating

### 5.2 Cómo se comunica

- [ ] **Nunca un muro.** Siempre una invitación con el número a la vista
- [ ] Copy literal de `09_MONETIZACION.md` §5.1
- [ ] **Nunca se pierde trabajo:** un listado sobre el límite se guarda como borrador

### 5.3 La bandera de cobro

- [ ] `app_state.cobro_activo` (booleano)
- [ ] Apagada → todo funciona en modo fundador, sin pedir tarjeta
- [ ] Prendida → aplica la prueba de 14 días y los límites
- [ ] **Se prende de un clic, no con un deploy.** Es la decisión del dueño, y la
      secuencia de `09_MONETIZACION.md` §10 dice cuándo tomarla

---

## 6. Notificaciones de empresa

- [ ] `business_id` en cada notificación de empresa
- [ ] **Campana personal filtra `business_id is null`** ← el cambio de una línea
- [ ] Campana propia en el shell de negocio
- [ ] Eventos de `02_ESPECIFICACION.md` §7
- [ ] Push web reutilizando la infraestructura VAPID existente
- [ ] Preferencias por tipo, en `/negocio` (una empresa quiere el aviso de pago pero
      quizá no el de cada impresión)

---

## 7. Kit de marca

- [ ] `app/api/sello/[slug].svg` — SVG del badge de nivel, cacheado 1 h, se actualiza solo
- [ ] Snippet HTML copiable en `/negocio` con el `<a>` + `<img>` hacia su ficha
- [ ] 3 placas para redes generadas con `sharp` (ya está en dependencias): nombre, nivel,
      objetivos cerrados
- [ ] Texto sugerido para anunciarlo, en voseo, listo para copiar

**Cada sello es un backlink hacia Brote desde el sitio de la empresa.** Va en todos los
planes justamente por eso.

---

## 8. Historial público de mejora

- [ ] Toggle `es_publico` por objetivo, en la ficha
- [ ] Gated por plan (Raíz y Bosque)
- [ ] Se muestra en `/mercado/negocio/[slug]`: objetivos logrados con su métrica y fecha
- [ ] **Nunca** se expone el dossier, ni siquiera parcialmente
- [ ] Copy: *"Este comercio comparte su historial de mejora."*

---

## 9. Criterios de aceptación

- [ ] "Dónde conseguirlo" aparece en una acción mapeada, con 3 listados reales
- [ ] **No** aparece si hay menos de 3
- [ ] **No** aparece para `kid` ni `teen`
- [ ] **No** aparece en el flujo de completar ni en la celebración
- [ ] Comprar **no** da un solo punto
- [ ] El módulo se ve aunque el frame loop esté estrangulado (probar con throttling)
- [ ] Las impresiones se cuentan una vez por sesión, no por scroll
- [ ] La analítica muestra números reales y coincide con `listing_clicks`
- [ ] "Qué te haría subir" propone algo accionable y verdadero
- [ ] Suscripción de prueba en el sandbox de MercadoPago llega a `activa`
- [ ] **El webhook rechaza una firma inválida** ← probalo a mano con curl
- [ ] El mismo evento dos veces **no** activa dos veces
- [ ] Pago fallido → `en_gracia`, banner, listados **siguen publicados** con −15 de score
- [ ] Gracia vencida → listados despublicados, **nada borrado**
- [ ] El límite de listados se aplica **en el RPC**, no solo en la UI
- [ ] Al superar el límite, el listado se guarda como borrador
- [ ] Con `cobro_activo = false`, todo funciona sin pedir tarjeta
- [ ] Una notificación de empresa **no** aparece en la campana personal
- [ ] El sello SVG se renderiza y linkea a la ficha correcta
- [ ] `npm run typecheck` y `npm run build` limpios

---

## 10. Definición de terminado

```
✔ Migración 0041 aplicada, incluido el filtro de notificaciones personales
✔ El puente acciones↔Mercado funciona y respeta las 5 reglas duras
✔ Analítica con números reales y el aviso de honestidad visible
✔ MercadoPago cobra en sandbox, con firma validada e idempotencia probadas
✔ Gracia de 7 días funcionando; nada se borra nunca
✔ Gating en el servidor, comunicado sin muros
✔ Bandera cobro_activo apagada, lista para que la prendas vos
✔ Kit de marca generando sellos
✔ typecheck + build limpios
✔ CONTINUE.md actualizado con F16.4
```

---

## 11. Lo que NO se hace

- ❌ Prender el cobro. La bandera queda apagada; la secuencia de
      `09_MONETIZACION.md` §10 dice cuándo
- ❌ Slots destacados del plan Bosque (backlog de Fase 5)
- ❌ Cualquier término de plan en la fórmula de ranking. **Nunca**
- ❌ Emails transaccionales más allá del código de verificación
