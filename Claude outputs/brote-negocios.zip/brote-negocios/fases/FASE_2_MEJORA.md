# FASE 2 · Mejora

> **Objetivo:** que una empresa aprobada reciba objetivos ambientales realistas, pueda
> decir "no llego a esto" y recibir una versión ajustada, y pueda cerrar uno con
> evidencia.
>
> Es la fase que **justifica que alguien pague**. Si sale bien, el Mercado es un extra;
> si sale mal, ninguna empresa renueva.

**Leer antes:** `02_ESPECIFICACION.md` §4 · `04_ESQUEMA_DB.md` §3 · `05_ALGORITMOS.md`
§5 y §6 · `06_PROMPTS_IA.md` §1-3 y §7 · `referencia/CATALOGO_PALANCAS.md` ·
`07_DISENO_UI.md` §4.4-4.5.

**Prerrequisito:** Fase 1 terminada y una empresa aprobada de prueba.

---

## 1. Orden de construcción

**Construí el camino sin IA primero.** Es el que va a estar activo el día del
lanzamiento (no hay `GEMINI_API_KEY` seteada), y además obliga a que el catálogo de
palancas y el validador de realismo estén bien antes de que la IA los use.

```
1. Catálogo de palancas + validador de realismo   ← la base
2. Dossier                                         ← la entrada
3. Generación por reglas                           ← funciona sin IA
4. Ciclo de vida del objetivo + evidencia          ← el producto
5. Feedback y replanificación (determinista)       ← lo que lo hace vivo
6. Recién ahí: la capa de IA sobre todo eso        ← una mejora, no una dependencia
```

---

## 2. Migración `0039_mejora.sql`

De `04_ESQUEMA_DB.md` §3:

- [ ] 4 enums
- [ ] `improvement_dossiers` + RLS **sin política pública** (crítico)
- [ ] `improvement_goals` + 3 índices + RLS
- [ ] `goal_checkins` + índice + RLS
- [ ] `goal_evidence` + índice + RLS
- [ ] `brote_progreso_mejora(uuid)` con grants
- [ ] Añadir `progreso_mejora` a `businesses` si no se creó en la Fase 1

**Verificación:**

```sql
-- El dossier NO debe ser legible por un usuario que no es miembro.
-- Probar con dos usuarios reales, no confiar en la lectura de la policy.
```

---

## 3. Catálogo de palancas

### 3.1 `lib/mejora/palancas.ts`

- [ ] Tipo `Palanca` exacto de `referencia/CATALOGO_PALANCAS.md`
- [ ] **Todas** las palancas de ese documento, transcritas con su `porque`, `pasos`,
      `como_medir` y `evidencia_requerida` **literales** (ya están escritos en voz de
      producto — no los reescribas)
- [ ] `palancasPara(rubro, tamano)` con filtrado
- [ ] `puntuarPalanca(palanca, dossier)` — el algoritmo del documento
- [ ] `rellenarPlantilla(palanca, dossier, negocio)` — sustituye `{{variables}}`

Meta de esta fase: **mínimo 6 palancas transversales + 4 por cada uno de los 12 rubros
= ~54**. El documento de referencia trae el esqueleto de todas; completar las que faltan
siguiendo las 6 reglas de su sección final.

### 3.2 `lib/mejora/realismo.ts`

- [ ] `validarObjetivo()` con las **10 reglas** de `05_ALGORITMOS.md` §5.2, literal
- [ ] `BANDAS`, `FUERA_DE_CONTROL`, `METODOS_VALIDOS`, `CAMPOS_OBLIGATORIOS`
- [ ] `asignarAmbicion()` de §5.3
- [ ] **Tests unitarios de este archivo.** Es el único módulo del proyecto donde un test
      unitario es obligatorio: es lo que impide que un objetivo malo llegue a un cliente
      que paga. Casos mínimos: los 11 de la tabla de `05_ALGORITMOS.md` §7

---

## 4. Dossier

### 4.1 `app/(business)/negocio/mejora/dossier/page.tsx`

- [ ] 8 bloques de `02_ESPECIFICACION.md` §4.1
- [ ] Un bloque por pantalla, con progreso
- [ ] **"No sé" como respuesta válida y explícita en cada campo numérico.** No es un
      campo vacío: es un valor. Dispara objetivos de medición en lugar de reducción
- [ ] `completitud` calculada y visible: *"Tu dossier está al 60%. Cuanto más completo,
      mejores los objetivos."*
- [ ] Editable siempre; al guardar cambios ofrece **replanificar** (no lo hace solo)
- [ ] Autoguardado por bloque

### 4.2 Bloque "Ya hecho"

- [ ] Textarea + chips de sugerencia por rubro
- [ ] **Es el campo más importante del dossier.** Proponerle a alguien algo que ya hizo
      es la forma más rápida de perder credibilidad. Que el copy lo diga:
      *"Contanos qué cambiaste en los últimos 2 años, para no proponerte algo que ya
      hacés."*

### 4.3 Bloque "Restricciones"

- [ ] `presupuesto`: `ninguno` / `hasta_X` / `caso_por_caso`
- [ ] `horas_mes_disponibles`: número, con default 6
- [ ] `local`: alquilado / propio (define si puede tocar la instalación)

---

## 5. Generación de objetivos

### 5.1 Camino sin IA — `lib/mejora/generador.ts`

- [ ] `objetivosPorReglas(dossier, negocio)` de `06_PROMPTS_IA.md` §7.1
- [ ] Selección: uno básico, uno intermedio, el mejor restante
- [ ] Todos pasan por `validarObjetivo()` antes de guardarse
- [ ] `generated_by: 'reglas'`
- [ ] Guardar como `status: 'propuesto'`

### 5.2 Camino con IA — edge function `business-goals`

- [ ] `supabase/functions/business-goals/index.ts`, modo `generar`
- [ ] Prompt **literal** de `06_PROMPTS_IA.md` §2, incluidos los 5 ejemplos de contraste
- [ ] `responseMimeType: 'application/json'` + `responseSchema`
- [ ] Cache por `input_hash` en `ai_jobs` **antes** de llamar
- [ ] Límite: 4 generaciones/semana por empresa
- [ ] **Post-proceso obligatorio:**
      1. `validarObjetivo()` en cada uno
      2. Descartar inválidos **en silencio**
      3. Completar con palancas hasta llegar a 3
      4. Ordenar por ambición ascendente
- [ ] Si Gemini falla, no hay clave, o el JSON no parsea tras un reintento → **camino de
      reglas**, `status: 'fallback'` en `ai_jobs`. **El usuario no ve ningún error**

### 5.3 La presentación

- [ ] Los objetivos llegan como **propuesta**, no como hecho consumado
- [ ] Cada uno con `[Aceptar]` y `[Descartar]`
- [ ] Aceptar → `activo`, setea `inicia_at` y `vence_at` según el horizonte
- [ ] Descartar → pide el motivo en una línea (alimenta futuras generaciones)
- [ ] Máximo 3 activos: al llegar, los demás quedan disponibles pero no aceptables,
      con copy claro

---

## 6. Ciclo de vida

### 6.1 `app/(business)/negocio/mejora/page.tsx`

- [ ] Layout de `07_DISENO_UI.md` §4.4
- [ ] Barra de Progreso de Mejora con `<Progress>` — **cuidado: toma `0..1`, no un
      porcentaje.** El repo ya se equivocó dos veces con esto
- [ ] Activos con eyebrow (dominio · horizonte · estado), título, antes→después, barra
- [ ] Chips de ambición y esfuerzo/mes **siempre visibles**
- [ ] `en_riesgo` en ámbar, `incumplido` en rojo
- [ ] Cerrados abajo, con tilde y fecha. **Sin celebración, sin confeti, sin puntos**

### 6.2 `app/(business)/negocio/mejora/[goalId]/page.tsx`

- [ ] Dos columnas en escritorio, apiladas en móvil
- [ ] Izquierda: título, porqué, métrica, método, **pasos como checklist real que se
      guarda**, evidencia requerida, "si no llegás"
- [ ] Derecha: el cuadro de ajuste + historial de versiones

### 6.3 Cierre con evidencia

- [ ] Formulario: valor final de la métrica + subida de archivo a `business-evidence`
- [ ] Comprimir imágenes con `lib/utils/image-compress.ts`, límite 5 MB
- [ ] `status` → `en_revision`, notificación al revisor
- [ ] `/panel/objetivos` — cola de cierres: objetivo, antes/después, archivo por URL
      firmada de 60s
- [ ] Aprobar → `logrado` o `logrado_parcial`, recalcular `progreso_mejora` y `tier`
- [ ] Pedir corrección → vuelve a `activo` con la observación

**El parcial importa:** que exista es lo que hace que la gente reporte la verdad en lugar
de abandonar el objetivo. Que el copy lo diga sin dramatismo:
*"No llegaste al número pero avanzaste. Cuenta como medio ciclo."*

---

## 7. Feedback y replanificación

**El corazón de la fase.**

### 7.1 UI

- [ ] Cuadro permanente: *"¿Algo no cierra? Contame y lo ajustamos."*
- [ ] 4 atajos que precargan el texto: `No llego a ese número` · `Esto ya lo hacemos` ·
      `No aplica a mi negocio` · `Necesito más tiempo`
- [ ] `no_llego` abre además un campo numérico: *"¿A cuánto sí llegás?"*
- [ ] `ya_hecho` abre: *"¿Desde cuándo? ¿Con qué lo podés mostrar?"*

### 7.2 Motor determinista

Antes que la IA, y sigue siendo el fallback:

```ts
export function replanificarPorReglas(goal: Goal, checkin: Checkin, ctx: Dossier): Goal {
  switch (checkin.tipo) {
    case 'no_llego': {
      const nuevaMeta = checkin.valor_reportado;
      const delta = Math.abs((goal.linea_base - nuevaMeta) / goal.linea_base);
      // Si el valor sigue en banda, se usa. Si no, se extiende el plazo y se mantiene
      // el número. Bajar la meta enseña que las metas se negocian.
      return delta >= BANDAS[goal.horizonte][0]
        ? { ...goal, version: goal.version + 1, objetivo: nuevaMeta, parent_id: goal.id }
        : { ...goal, version: goal.version + 1, horizonte: subir(goal.horizonte),
            vence_at: recalcular(goal.inicia_at, subir(goal.horizonte)), parent_id: goal.id };
    }
    case 'mas_tiempo':
      return { ...goal, version: goal.version + 1, horizonte: subir(goal.horizonte),
               vence_at: recalcular(goal.inicia_at, subir(goal.horizonte)), parent_id: goal.id };
    case 'no_aplica':
      return { ...goal, status: 'descartado' };  // + proponer alternativa del mismo dominio
    case 'ya_hecho':
      return checkin.tiene_evidencia
        ? { ...goal, status: 'logrado', cerrado_at: new Date() }
        : goal;                                  // se pide la evidencia, no se cierra
    default:
      return goal;
  }
}
```

### 7.3 Motor con IA

- [ ] Modo `replanificar` de la edge function
- [ ] Prompt literal de `06_PROMPTS_IA.md` §3
- [ ] Recibe: objetivo actual + **historial completo** de check-ins + resumen del dossier
- [ ] Salida validada con `validarObjetivo()`; si no valida → camino determinista
- [ ] Límite 8/semana; al llegar, copy claro y controles manuales disponibles

### 7.4 Versionado

- [ ] Toda replanificación crea una fila nueva con `parent_id` a la anterior
- [ ] **Nunca se borra ni se pisa una versión**
- [ ] La UI muestra "Versión N · ver historial", con qué dijo la empresa y qué se cambió
- [ ] El historial es lo que convierte esto en un programa serio y lo que se audita
      para el nivel E4

---

## 8. Nivel E4 y progreso

- [ ] `brote_progreso_mejora()` conectado y mostrado
- [ ] Recalcular `businesses.tier` al aprobar un cierre
- [ ] Copy que enseña la escalera: *"4 ciclos cerrados con evidencia. Con certificación
      de tercero vigente llegás a Nivel 4."*

---

## 9. Verificación por captura de Instagram

Ahora que existe la infraestructura de IA, se completa lo que quedó manual en la Fase 1:

- [ ] Prompt de visión de `06_PROMPTS_IA.md` §6
- [ ] Aprobación automática **solo** si los 4 checks dan bien
- [ ] Aun aprobado, el método queda registrado como **fuerza media**
- [ ] Cualquier otro caso → revisión manual

---

## 10. Criterios de aceptación

- [ ] Un dossier completo genera 3 objetivos válidos **sin clave de Gemini**
- [ ] Con clave, genera 3-5 y **todos pasan el validador**
- [ ] Un dossier con "No sé" en todo genera objetivos de **medición**, ambición `basico`
- [ ] Un dossier con `presupuesto: ninguno` no genera **ningún** objetivo con inversión
- [ ] Un objetivo que ya está en "ya hecho" **no se propone**
- [ ] Ningún objetivo tiene `esfuerzo_horas_mes > 6`
- [ ] La suma de esfuerzo de los activos nunca supera 12 h/mes
- [ ] "No llego" con un valor en banda → nueva versión con esa meta
- [ ] "No llego" con un valor fuera de banda → **extiende el plazo, mantiene el número**
- [ ] "Ya lo hacemos" con evidencia → `logrado` retroactivo + escalón siguiente
- [ ] "Ya lo hacemos" sin evidencia → pide la evidencia, **no cierra nada**
- [ ] El historial de versiones se ve completo y **nada se borró**
- [ ] Cerrar un objetivo con evidencia lo deja `en_revision` y aparece en `/panel`
- [ ] Aprobar el cierre sube el progreso y recalcula el nivel
- [ ] Un usuario ajeno **no puede leer** `improvement_dossiers` (probado con dos cuentas)
- [ ] Con Gemini apagado a propósito, **todo el flujo funciona** y no aparece un error
- [ ] Cero confeti, cero puntos, cero emojis en controles
- [ ] Los tests unitarios de `realismo.ts` pasan, incluidos los 11 casos de la tabla

### 10.1 Prueba de calidad de los prompts

Antes de dar la fase por cerrada, correr el set de evaluación de `06_PROMPTS_IA.md` §8:

- [ ] 10 dossiers ficticios escritos a mano, 5 con datos incompletos a propósito
- [ ] ≥80% de objetivos pasan el validador sin arreglos
- [ ] **0** objetivos con número inventado
- [ ] **0** objetivos que repitan algo de "ya hecho"
- [ ] Lectura a ojo: ningún objetivo suena a jardín de infantes

**Si no pasa, ajustá el prompt antes de que lo vea una empresa real.**

---

## 11. Definición de terminado

```
✔ Migración 0039 aplicada; el dossier es ilegible desde afuera (probado)
✔ ~54 palancas cargadas y puntuables
✔ validarObjetivo() con las 10 reglas y sus tests pasando
✔ Generación funciona con y sin Gemini, sin diferencia visible de calidad
✔ Los 4 tipos de feedback replanifican correctamente
✔ El historial de versiones nunca pierde nada
✔ Cierre con evidencia + aprobación + recálculo de nivel, de punta a punta
✔ Set de evaluación de 10 dossiers pasado
✔ typecheck + build limpios
✔ CONTINUE.md actualizado con F16.2
```

---

## 12. Lo que NO se hace

- ❌ Listados y `/mercado` (Fase 3)
- ❌ Cobro (Fase 4)
- ❌ Compartir públicamente el historial de mejora (Fase 4, gated por plan)
- ❌ Cualquier gamificación: puntos, insignias, rachas, ligas de empresas
