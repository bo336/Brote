# FASE 1 · Fundaciones

> **Objetivo:** que una empresa pueda existir en Brote. Entidad, membresías, cambio de
> contexto, shell propio, alta, verificación de identidad y cola de revisión.
>
> **Sin IA todavía. Sin listados. Sin objetivos.** Al terminar esta fase, una persona
> crea una empresa, la verifica, vos la aprobás y ella entra a un espacio de trabajo
> vacío pero real.

**Leer antes de empezar:** `00_LEEME.md` · `02_ESPECIFICACION.md` §3 · `03_ARQUITECTURA.md`
· `04_ESQUEMA_DB.md` §2 · `07_DISENO_UI.md` §3 y §4.2-4.3 · `BROTE_DESIGN_SYSTEM.md` del repo.

---

## 1. Prerrequisitos

- [ ] Confirmar el número de la última migración en `supabase/migrations/`. Esta carpeta
      asume `0037`; si el repo avanzó, corré el número.
- [ ] Verificar que la extensión `unaccent` esté disponible (`select * from pg_extension`).
      Si no, implementar `unaccent_safe()` con `translate()`.
- [ ] Leer `middleware.ts`, `components/nav/TopBar.tsx` y `app/(app)/panel/page.tsx`:
      son los tres archivos existentes que se van a tocar.

---

## 2. Migración `0038_negocios_fundaciones.sql`

Copiar de `04_ESQUEMA_DB.md` §2, completo:

- [ ] 6 enums con guarda de duplicado
- [ ] `businesses` + 5 índices
- [ ] `business_members` + índice
- [ ] `business_verifications` + índice
- [ ] `ai_jobs` + 3 índices
- [ ] `brote_is_member`, `brote_biz_role`, `brote_can_write`, `brote_slugify`
- [ ] RLS en las 4 tablas con las políticas del documento
- [ ] RPCs `create_business`, `my_businesses`
- [ ] `revoke ... from public, anon` + `grant ... to authenticated` en **todas** las
      funciones nuevas
- [ ] Buckets `business-logos` y `business-evidence` con sus policies de Storage

**Verificación de la migración, antes de seguir:**

```sql
-- 1. Un select anónimo sobre businesses no debe colgarse (prueba de no-recursión)
set role anon; select count(*) from businesses; reset role;

-- 2. Ninguna función nueva puede ser ejecutable por anon
select p.proname, has_function_privilege('anon', p.oid, 'execute')
from pg_proc p join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public' and p.proname like 'brote_%' or p.proname in
  ('create_business','my_businesses');
-- Todas tienen que dar false.
```

---

## 3. Contexto persona ↔ empresa

### 3.1 `lib/negocio/context.ts`

```ts
export type ActiveBusiness = {
  id: string; nombre: string; slug: string;
  role: 'owner'|'admin'|'editor';
  status: BusinessStatus; tier: EvidenceTier;
};

// Servidor. SIEMPRE valida membresía contra la base; la cookie es solo preferencia.
export async function getActiveBusiness(): Promise<ActiveBusiness | null>;

// Server action. Setea la cookie y devuelve para que el caller haga router.refresh().
export async function setActiveContext(ctx: 'personal' | string): Promise<void>;
```

- [ ] Cookie `brote_ctx`, `sameSite: 'lax'`, `secure` en prod, 1 año, **no** `httpOnly`
- [ ] Si la cookie apunta a un negocio del que no es miembro → devolver `null` **y
      limpiar la cookie**
- [ ] Nunca usar la cookie como autorización: toda consulta valida por RLS

### 3.2 `lib/negocio/roles.ts`

Tabla de permisos en un solo lugar:

```ts
export const PERMISOS = {
  editar_negocio:   ['owner','admin'],
  gestionar_equipo: ['owner'],
  gestionar_plan:   ['owner'],
  crear_listado:    ['owner','admin','editor'],
  gestionar_objetivos: ['owner','admin','editor'],
  eliminar_negocio: ['owner'],
} as const;

export function puede(rol: BusinessRole | null, accion: keyof typeof PERMISOS): boolean;
```

### 3.3 `middleware.ts`

- [ ] `/negocio/*` sin sesión → `/auth/login?next=<ruta>`
- [ ] `/negocio/*` con sesión sin negocio activo → `/negocio/alta`
- [ ] `/negocio/alta` con cuenta `kid`/`teen` → `/` con parámetro para el toast
- [ ] **Nada más.** No metas lógica de negocio: corre en cada request

### 3.4 Selector de contexto

- [ ] Componente `components/negocio/ContextSwitcher.tsx`
- [ ] En el menú del avatar del `TopBar` **y** en el encabezado del shell de negocio
- [ ] Llama a `setActiveContext` y después `router.refresh()`. **Nunca**
      `window.location`
- [ ] "Crear un negocio" visible solo para `adult` con < 3 negocios como `owner`

---

## 4. Shell de negocio

### 4.1 `app/(business)/layout.tsx`

- [ ] Barra superior 56px: logo, selector de contexto, avatar
- [ ] Barra lateral 220px en ≥1024px; `<ChipRail>` horizontal en móvil
- [ ] Chip de nivel fijo al pie de la lateral
- [ ] **Verificar que NO importe:** `components/mundo/*`, `components/pip/*`,
      `components/rewards/*`, `components/nav/BottomTabBar`, `components/ads/*`
- [ ] Fondo: canvas crema/tinta del tema. **Nunca** gris de plantilla
- [ ] Si `getActiveBusiness()` devuelve `null` → redirigir a `/negocio/alta`

### 4.2 `app/(business)/negocio/page.tsx` — Resumen

En esta fase muestra: estado de la solicitud, estado de verificación, y los próximos
pasos. La franja `<PulseStrip>` con métricas llega en la Fase 4 — **no la pongas con
números en cero**, es exactamente el "stat inventado" que el sistema de diseño prohíbe.

Estados a cubrir:

| `status` | Qué muestra |
|---|---|
| `draft` | "Te falta terminar el alta" + botón a `/negocio/alta` |
| `submitted` / `in_review` | "Lo estamos revisando" + estado de verificación + qué puede ir haciendo |
| `approved` | Bienvenida + próximos pasos (Fase 2 y 3 los llenan) |
| `rejected` | Motivo + cuándo puede volver a aplicar |
| `suspended` | Motivo + a quién escribir |

---

## 5. Alta en 5 pasos

### 5.1 `app/(business)/negocio/alta/page.tsx`

- [ ] Un paso por pantalla, barra de progreso `N de 5`
- [ ] Autoguardado al cambiar de paso, con leyenda *"Guardado"* discreta
- [ ] Cada paso entra sin scroll en un móvil de 360px
- [ ] Validación con Zod + `react-hook-form` (ambos ya están en el repo)
- [ ] Usar `<Input>`, `<Textarea>`, `<Select>`, `<Field>` de `components/ui/input.tsx`

**Paso 1 · Quiénes son** — nombre, razón social, CUIT, rubro (12 opciones), tamaño,
provincia, ciudad.

- [ ] **Validar el dígito verificador del CUIT en el cliente**, con mensaje amable:
      *"Ese CUIT no parece válido, ¿lo revisás? También podés dejarlo vacío."*
- [ ] Provincias: reutilizar `lib/data/cities.ts` (que hoy guarda provincias — ver la
      deuda F15.4 del repo)

**Paso 2 · Dónde encontrarlos** — sitio, Instagram, WhatsApp, email.

- [ ] **Al menos uno** de sitio o Instagram, obligatorio
- [ ] Normalizar: aceptar `@handle`, `instagram.com/handle` y la URL completa; guardar
      siempre el handle limpio
- [ ] Normalizar el sitio a `https://` con dominio, sin path

**Paso 3 · Qué hacen** — textarea guiado, mínimo 120 caracteres.

- [ ] Placeholder exacto de `02_ESPECIFICACION.md` §3.2
- [ ] Tres chips que **inyectan preguntas** en el textarea si el texto < 200 caracteres
- [ ] Contador de caracteres visible

**Paso 4 · Qué querés hacer acá** — checkboxes de intereses.

**Paso 5 · Verificación** — se puede saltear con *"Lo hago después"*.

### 5.2 Envío

- [ ] Server action: `status` → `submitted`, notificación al revisor
- [ ] Pantalla de espera con el copy de `07_DISENO_UI.md` §4.2
- [ ] **Sin IA en esta fase.** El campo `score_ia` queda nulo; el revisor ve los datos
      crudos

---

## 6. Verificación de identidad

### 6.1 Edge function `verify-business`

`supabase/functions/verify-business/index.ts`. Siguiendo el patrón de las existentes:
CORS de `_shared/cors.ts`, timeout, **nunca lanza**.

**Método `dominio_meta`:**
- [ ] `fetch` del dominio raíz, timeout 8s, seguir hasta 3 redirects
- [ ] Buscar `<meta name="brote-site-verification" content="TOKEN">` con regex tolerante
      (comillas simples o dobles, atributos en cualquier orden)
- [ ] User-Agent identificable: `BroteVerify/1.0 (+https://brote.../legal/verificacion)`

**Método `dominio_dns`:**
- [ ] Resolver TXT por DNS-over-HTTPS (`https://dns.google/resolve?name=X&type=TXT`)
- [ ] Buscar `brote-site-verification=TOKEN`

**Método `dominio_archivo`:**
- [ ] `fetch` de `https://dominio/.well-known/brote-verify.txt`, comparar contenido

**Método `email_dominio`:**
- [ ] Código de 6 dígitos, válido 30 minutos
- [ ] ⚠️ **Requiere un remitente.** Opciones sin costo, en orden de preferencia:
      1. Resend con dominio propio (capa gratuita generosa)
      2. Brevo / SMTP gratuito
      3. **Si no hay ninguno configurado: no ofrezcas este método todavía.** Ocultalo
         del listado en lugar de mostrarlo roto. Los tres de dominio alcanzan

**Método `social_token`:**
- [ ] Subir captura a `business-evidence`
- [ ] En esta fase: **queda en revisión manual siempre**. El análisis con Gemini Vision
      llega en la Fase 2, cuando ya exista la infraestructura de IA

**Reintentos:** 1 cada 10 minutos, 20/día. Guardar `intentos` y `ultimo_error`.

### 6.2 `app/(business)/negocio/verificacion/page.tsx`

- [ ] Métodos como filas con hairline, ordenados por fuerza, con chip `Fuerte`/`Media`
- [ ] Snippet copiable con botón `[Copiar]` y confirmación visual
- [ ] **El error siempre es humano y accionable.** Nunca "fetch failed", nunca un código
      HTTP. Mapa de errores:

| Causa técnica | Lo que ve la empresa |
|---|---|
| Timeout / DNS | *"No pudimos entrar a tu sitio. ¿Está andando? Probá abrirlo en otra pestaña."* |
| 200 sin token | *"Entramos a tu sitio pero no encontramos la etiqueta. Fijate que esté dentro del `<head>` y que hayas publicado los cambios."* |
| 404 | *"Esa dirección no existe. Revisá que el dominio esté bien escrito."* |
| 403 / 401 | *"Tu sitio nos bloqueó el acceso. Probá con el método de DNS o con el archivo."* |
| TXT sin token | *"El registro TXT todavía no se ve. A veces tarda hasta 24 horas en propagarse."* |

Esto es literalmente el punto F15.5 del backlog del repo.

---

## 7. Cola de revisión

### 7.1 `app/(app)/panel/negocios/page.tsx`

- [ ] Filas con hairline, ordenadas por antigüedad
- [ ] Por fila: nombre, rubro, provincia, tamaño, antigüedad, estado de verificación,
      chips de riesgo (calculados por reglas en esta fase)
- [ ] Filtros: `pendientes` / `todas` / `rechazadas`
- [ ] Contador en `/panel` con el número de pendientes

### 7.2 `app/(app)/panel/negocios/[id]/page.tsx`

- [ ] Layout de `07_DISENO_UI.md` §4.10. El bloque de IA queda vacío en esta fase
- [ ] Chequeos técnicos visibles: verificación, sitio responde, CUIT válido, duplicado
- [ ] Tres botones + campo de nota
- [ ] Atajos: `A` aprobar, `P` pedir datos, `R` rechazar, `J`/`K` navegar
- [ ] **Los atajos no disparan si el foco está en un input**
- [ ] Cada acción escribe `revisado_por`, `revisado_at`, `ultima_revision` y notifica

### 7.3 Detección de duplicados

- [ ] Por dominio normalizado del sitio
- [ ] Por CUIT
- [ ] Por nombre normalizado + provincia (fuzzy simple: sin acentos, minúsculas, sin
      "S.A.", "SRL", etc.)
- [ ] **Avisa, no bloquea.** El revisor decide

---

## 8. Notificaciones

- [ ] Reutilizar la tabla `notifications` existente
- [ ] En esta fase se usan sin `business_id` (la columna llega en la Fase 4), con un
      `notif_type` `system` y el enlace a `/negocio`
- [ ] Eventos: alta enviada, aprobada, observada, rechazada, verificación exitosa,
      verificación fallida tras 3 intentos

---

## 9. i18n

- [ ] Todo string nuevo en `messages/es.json`, bajo la clave `negocio.*`
- [ ] `messages/en.json` andamiado (puede repetir el español, como ya hace el repo)
- [ ] **Cero strings hardcodeados en componentes**

---

## 10. Criterios de aceptación

Cada uno se prueba a mano antes de dar la fase por cerrada.

- [ ] Una cuenta `adult` crea una empresa y llega a `submitted`
- [ ] Una cuenta `kid` **no ve** el punto de entrada y, si va a `/negocio/alta` a mano,
      es redirigida
- [ ] Una cuenta `teen` idem
- [ ] El RPC `create_business` **rechaza** a un `kid` aunque se lo llame directamente
      (probar con `set role` en SQL, no solo por UI)
- [ ] La verificación por meta tag funciona contra un sitio real de prueba
- [ ] La verificación falla con un mensaje **humano** cuando el token no está
- [ ] El selector cambia de contexto y `/negocio` renderiza el shell correcto **sin
      parpadeo**
- [ ] Editar la cookie `brote_ctx` a un negocio ajeno **no da acceso a nada**
- [ ] Un usuario que no es miembro no puede leer ese `businesses` por la API
- [ ] El shell de negocio **no carga** three.js — verificar en el network tab
- [ ] El revisor aprueba desde `/panel/negocios/[id]` y la empresa lo ve en `/negocio`
- [ ] Los atajos de teclado funcionan y no disparan escribiendo en la nota
- [ ] Todo el flujo funciona a 360px de ancho
- [ ] Modo oscuro correcto en todas las pantallas nuevas
- [ ] `npm run typecheck` y `npm run build` limpios

---

## 11. Definición de terminado

```
✔ Migración 0038 aplicada y verificada (incluida la prueba de no-recursión)
✔ Una empresa puede crearse, verificarse y ser aprobada de punta a punta
✔ El cambio de contexto funciona en ambos sentidos, sin parpadeo
✔ Menores bloqueados en el servidor, no solo en la UI
✔ Cola de revisión usable en menos de 2 minutos por empresa
✔ Nada de la app de personas cambió de comportamiento
✔ typecheck + build limpios
✔ CONTINUE.md actualizado con el estado de F16.1
```

---

## 12. Lo que NO se hace en esta fase

Escrito para que no se cuele:

- ❌ Nada de IA. `score_ia` e `informe_ia` quedan nulos
- ❌ Listados, catálogo, `/mercado`
- ❌ Objetivos, dossier, Mejora
- ❌ Cobro, planes, MercadoPago
- ❌ Analítica (no hay qué medir)
- ❌ La franja `<PulseStrip>` con métricas en cero
