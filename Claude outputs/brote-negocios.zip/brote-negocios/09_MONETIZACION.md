# 09 · Monetización

> Cuota mensual desde el día uno, por MercadoPago. Este documento define los planes, el
> precio, el cobro, el gating y —lo más difícil— **por qué una empresa pagaría el primer
> mes, cuando todavía no hay tráfico**.

---

## 1. El problema real

Estás vendiendo acceso a una audiencia que **todavía no existe**. Ningún argumento de
"llegá a miles de usuarios" es honesto hoy, y una PyME lo huele en treinta segundos.

**La solución está en el diseño del producto, no en el discurso de venta:** el programa
de **Mejora** entrega valor el primer día, con cero visitas al Mercado. Un plan de
objetivos ambientales realista, con seguimiento y evidencia, es algo por lo que una PyME
paga hoy — hay consultoras que cobran cientos de dólares por menos.

Entonces el orden del argumento es:

> **Pagás por el programa de mejora. El Mercado viene incluido y crece con nosotros.**

No al revés. Vender el Mercado primero es prometer lo que no podés entregar todavía, y
es la forma más rápida de perder al primer cliente que consigas.

### 1.1 Las cuatro cosas que la empresa recibe el día 1

Y las cuatro existen desde la Fase 2 y 3, sin necesidad de un solo usuario más:

1. **Un plan de mejora con números reales**, anclado en el estándar internacional para
   PyMEs, adaptado a su rubro y a sus restricciones.
2. **Un sistema de seguimiento con evidencia** — el historial de versiones que puede
   mostrarle a un cliente corporativo que le pide "qué hacen ustedes en sostenibilidad".
3. **Una ficha pública verificada** en un catálogo curado, con un nivel de evidencia que
   se gana y que sirve como señal frente a terceros.
4. **El derecho a decir que están en el programa**, con un kit de marca para su sitio y
   sus redes (ver §7).

El punto 2 es el que más subestimamos y el que más se vende: **cada vez más licitaciones
y clientes grandes piden evidencia ambiental a sus proveedores chicos, y la PyME no tiene
con qué responder.** Brote le da un documento.

---

## 2. Los planes

Tres, con nombres del universo de Brote.

| | **Semilla** | **Raíz** | **Bosque** |
|---|---|---|---|
| Listados publicados | 3 | 15 | Ilimitados |
| Objetivos activos | 2 | 3 | 3 |
| Replanificaciones IA | 4/mes | 8/mes | 15/mes |
| Miembros del equipo | 1 | 3 | 10 |
| Analítica | Básica | Completa + export | Completa + export |
| Historial público de mejora | — | ✅ | ✅ |
| Kit de marca | ✅ | ✅ | ✅ |
| Destacado en su categoría | — | — | 1 slot/mes |
| Publicación acelerada | — | ✅ | ✅ |
| Soporte | Email | Email | Email prioritario |

**Semilla es la puerta de entrada real.** 3 listados alcanzan para un negocio chico y
2 objetivos activos ya dan un programa. La fricción de empezar tiene que ser mínima, que
fue tu requisito explícito.

### 2.1 Qué NO se compra nunca

Esto es lo que separa a Brote de un directorio pago cualquiera:

- ❌ **No se compra nivel de evidencia.** E1→E4 sale de documentos, punto.
- ❌ **No se compra posición en el ranking.** Los pesos de `05_ALGORITMOS.md` §4 no tienen
  un término de plan.
- ❌ **No se compra la aprobación de un listado ni el cierre de un objetivo.**

Lo único que el plan compra es **capacidad** (cuántos listados, cuántos objetivos,
cuántas replanificaciones) y **conveniencia** (analítica, publicación acelerada,
equipo). El slot de "destacado" del plan Bosque es un espacio **etiquetado como
destacado**, visualmente distinto, fuera del orden orgánico — igual que hace cualquier
marketplace serio. Nunca un empujón encubierto dentro del ranking.

> Si en algún momento se agrega un término de plan al ranking, el sistema perdió lo
> único que lo hacía distinto. Dejalo escrito en el código, arriba de la fórmula.

---

## 3. Precio

### 3.1 El método, no el número

**No pongo un número en pesos acá y quiero ser claro sobre por qué:** con la inflación
argentina, cualquier cifra que escriba hoy está mal en tres meses. Lo que sí puedo darte
es cómo fijarlo y cómo mantenerlo.

**Anclas para calcular, en orden de utilidad:**

1. **Ancla de dolor:** el plan Semilla tiene que costar **menos que una hora del
   contador** de esa PyME. Si el dueño duda más de diez segundos, está caro.
2. **Ancla de comparación:** miralo contra lo que ya paga por *estar en algún lado* —
   una suscripción de tienda online, una herramienta de facturación, el plan de datos de
   un celular. Ese es el bolsillo mental del que sale.
3. **Ancla de referencia internacional:** el equivalente en USD de un SaaS de entrada
   para PyME es **USD 8–15/mes** para Semilla, **USD 25–40** para Raíz, **USD 60–90**
   para Bosque. Convertí al tipo de cambio del día y **redondeá hacia abajo** a una cifra
   cómoda.

**Cómo mantenerlo:** guardá el precio en `app_state` (no hardcodeado), con actualización
manual. Cuando lo subas, avisá con **30 días** de anticipación y respetá el precio de
fundador (§3.2).

### 3.2 Fundadores

Los primeros **30 negocios** aprobados:

- **Precio bloqueado 12 meses** (`business_subscriptions.precio_bloqueado = true`).
- **Insignia de fundador** en su ficha pública, permanente.
- Acceso al plan **Raíz** al precio de **Semilla** durante 6 meses.

No es generosidad: es que los primeros 30 son los que hacen que el catálogo exista, y su
riesgo es mucho mayor que el de quien llega cuando ya hay tráfico. Que lo diga el copy.

### 3.3 Prueba gratuita

**14 días, sin tarjeta.** Con tarjeta al inicio la conversión de alta se desploma en un
segmento que desconfía de dejar datos de pago.

La empresa completa el alta, recibe sus objetivos, publica hasta 3 listados. Al día 11
recibe un aviso; al día 14, si no cargó medio de pago, los listados se despublican y
**Mejora queda en modo lectura** (ve todo, no puede cerrar objetivos ni pedir ajustes).

Nunca se borra nada. Puede volver cuando quiera y sigue donde estaba.

---

## 4. MercadoPago

### 4.1 Qué usar

**Suscripciones (preapproval)** de MercadoPago, con débito automático. Es lo estándar en
Argentina y lo que la gente reconoce.

> **Nota de producto:** el botón dice **"Suscribirme"**, no "MercadoPago". Es el punto
> F15.1 del backlog del repo — MercadoPago es el procesador, no el producto. El logo va
> chico, debajo, como sello de confianza.

### 4.2 Sin SDK

`fetch` contra la API REST. **No agregues el SDK de MercadoPago**: son 300 kB para tres
llamadas, y el proyecto tiene una disciplina de dependencias que vale la pena mantener.
Todo desde edge functions y route handlers, con el access token del lado servidor.

### 4.3 El flujo

```
/negocio/plan
  │ elige plan
  ▼
edge fn `mp-subscribe`
  │ POST /preapproval  { reason, auto_recurring, payer_email, back_url, external_reference }
  │ external_reference = business_id      ← el hilo que conecta todo
  ▼
init_point → el usuario paga en MercadoPago
  │
  ├─► back_url → /negocio/plan?estado=pendiente   (informativo, NUNCA fuente de verdad)
  │
  └─► webhook POST /api/pagos/mercadopago/webhook   ← LA fuente de verdad
        │ 1. Validar la firma  x-signature
        │ 2. Volver a consultar la API por el id (nunca confiar en el body)
        │ 3. Mapear estado → business_subscriptions
        │ 4. Responder 200 rápido; el trabajo pesado va aparte
```

**Las cuatro reglas del webhook**, en orden de importancia:

1. **Validar la firma.** Un webhook sin validar es una API pública para regalar
   suscripciones.
2. **Nunca confiar en el cuerpo.** Trae un id; con ese id se consulta la API y **esa**
   respuesta es la verdad.
3. **Idempotencia.** MercadoPago reintenta. Clave única por `(external_id, evento)`;
   el mismo evento dos veces no puede cobrar ni activar dos veces.
4. **Responder 200 rápido.** Si tarda, reintenta y se duplica el trabajo.

### 4.4 Mapeo de estados

| MercadoPago | `biz_sub_status` | Efecto |
|---|---|---|
| `pending` | `pendiente` | Sin acceso pago |
| `authorized` | `activa` | Acceso completo, `periodo_fin` = próximo cobro |
| pago rechazado | `en_gracia` | 7 días, `gracia_fin` seteado, aviso diario |
| `paused` | `pausada` | Listados despublicados, Mejora en lectura |
| `cancelled` | `cancelada` | Igual que pausada + encuesta de baja |
| gracia vencida | `vencida` | Listados despublicados, aviso, datos intactos 90 días |

### 4.5 La gracia importa

**7 días** antes de despublicar. Una tarjeta vencida es el motivo de baja más común en
Argentina y no tiene nada que ver con la intención de seguir. Cortar el mismo día
convierte un problema de tarjeta en una baja definitiva.

Durante la gracia: banner permanente en el espacio de negocio, notificación diaria,
**listados siguen publicados** pero con `−15` de penalización de score.

---

## 5. Gating

Un solo lugar: `lib/negocio/plan.ts`.

```ts
export const LIMITES: Record<BizPlan, Limites> = {
  semilla: { listados: 3,  objetivos: 2, replanificaciones: 4,  miembros: 1,
             analitica: 'basica',   historialPublico: false, destacados: 0, acelerada: false },
  raiz:    { listados: 15, objetivos: 3, replanificaciones: 8,  miembros: 3,
             analitica: 'completa', historialPublico: true,  destacados: 0, acelerada: true },
  bosque:  { listados: Infinity, objetivos: 3, replanificaciones: 15, miembros: 10,
             analitica: 'completa', historialPublico: true,  destacados: 1, acelerada: true },
};

export function puedePublicar(plan: BizPlan, publicados: number) {
  return publicados < LIMITES[plan].listados;
}
```

**El gating se aplica en el servidor**, en el RPC. Esconder un botón en el cliente no es
gating.

### 5.1 Cómo se comunica el límite

Nunca un muro. Siempre una invitación con el número a la vista:

> *"Llegaste a los 3 listados del plan Semilla. Con Raíz podés publicar hasta 15 y tus
> listados se publican sin espera."*
> `[Ver planes]` · `[Ahora no]`

Y jamás se pierde trabajo: un listado por encima del límite se guarda como **borrador**,
listo para publicarse cuando cambien de plan.

---

## 6. Analítica: lo que la empresa realmente ve

`/negocio/analitica`. **Honestidad primero**, porque es donde se decide la renovación.

```
ANALÍTICA · ÚLTIMOS 30 DÍAS

  1.847        94         5,1%        3
  IMPRESIONES  SALIDAS    TASA        REPORTES RESUELTOS

TUS LISTADOS
──────────────────────────────────────────────────────────
Harina orgánica 1kg          842 impresiones   51 salidas  6,1%
Pan de masa madre            619 impresiones   28 salidas  4,5%
Curso de panadería casera    386 impresiones   15 salidas  3,9%

DE DÓNDE VINIERON
Catálogo 61% · Acciones diarias 24% · Tu ficha 11% · Búsqueda 4%

QUÉ TE HARÍA SUBIR
· Subir la ficha técnica del envase llevaría "contenido reciclado"
  a Nivel 2 (+18% estimado de visibilidad)
· Cerrar el objetivo de energía te sube el Progreso de Mejora a 78
```

**El aviso de honestidad, siempre visible al pie:**

> *Medimos hasta que salís de Brote. Lo que pase después —si compraron, cuánto— pasa en
> tu sitio y no lo vemos. Si querés atribuir ventas, agregá `?ref=brote` a tu enlace de
> destino y miralo en tu propia analítica.*

Ese párrafo hace dos cosas: te saca de una promesa que no podés cumplir, y le da a la
empresa una herramienta real. El truco del `?ref=brote` es gratis, funciona con Google
Analytics o cualquier cosa que ya usen, y es el tipo de detalle que hace que te
recomienden.

**El bloque "Qué te haría subir" es el motor de retención.** Convierte la analítica de un
reporte pasivo en una lista de próximos pasos, y cada paso empuja hacia más evidencia —
que es exactamente lo que el sistema quiere que pase.

---

## 7. Kit de marca

Incluido en todos los planes. Costo de desarrollo: bajo. Valor percibido: alto.

- **Sello para su sitio**: un snippet HTML con el badge de su nivel, que linkea a su
  ficha en Brote. Se actualiza solo (SVG servido desde `/api/sello/[slug].svg`).
- **Placas para redes**: 3 imágenes generadas con su nombre, su nivel y sus objetivos
  cerrados. Se generan con `sharp`, que ya está en las dependencias del repo.
- **Texto sugerido** para que lo anuncien, en voseo, listo para copiar.

Cada sello es un backlink hacia Brote desde el sitio de la empresa. **Treinta empresas =
treinta enlaces entrantes** hacia un dominio nuevo. Es adquisición gratis, y es el
motivo por el que el kit va en todos los planes y no solo en los caros.

---

## 8. Proyección honesta

Sin humo. Con el precio en el rango de §3.3 y **conversión de prueba a pago del 40%**
(optimista pero alcanzable con onboarding manual y 30 clientes):

| Mes | Altas | Activas de pago | Ingreso mensual aprox. |
|---|---|---|---|
| 1 | 10 | 0 (en prueba) | — |
| 2 | 15 | 4 | 4 × Semilla |
| 3 | 20 | 12 | ~10 Semilla + 2 Raíz |
| 6 | — | 45 | ~35 Semilla + 8 Raíz + 2 Bosque |
| 12 | — | 120 | ~85 Semilla + 25 Raíz + 10 Bosque |

**A 120 empresas activas esto cubre infraestructura de sobra y empieza a pagar tiempo.**
El cuello de botella no va a ser técnico: va a ser **cuántas empresas podés dar de alta
y acompañar vos solo**. Por eso el objetivo de "menos de 2 minutos por revisión" es una
decisión de negocio, no una de UX.

**El número que hay que mirar de verdad no es el ingreso: es la renovación del mes 2.**
Si las empresas del mes 1 no renuevan, el problema es el producto y no el precio, y
ningún ajuste de pricing lo arregla.

---

## 9. Costos

| Concepto | Costo |
|---|---|
| Supabase | USD 0 (capa gratuita) |
| Vercel | USD 0 (Hobby) |
| Gemini | USD 0 (~43 req/día contra 1.500) |
| MercadoPago | Comisión por transacción — sale del ingreso |
| **Revisión legal de términos** | **El único costo real de arranque. Presupuestalo.** |
| Dominio propio | Opcional; el `.vercel.app` funciona pero le resta credibilidad frente a una empresa que va a pagar |

**Los dos gastos que sí conviene hacer**, en este orden: la revisión legal de los
términos, y un dominio propio. Una PyME que va a poner su tarjeta mira la URL.

---

## 10. Cuándo activar el cobro

**No en la Fase 4 automáticamente.** La secuencia sensata:

1. Fases 1-3 terminadas y probadas.
2. Fase 4 construida, con el cobro **detrás de una bandera en `app_state`**, apagada.
3. **Conseguí las primeras 10 empresas a mano, gratis, en modo fundador.** Sentate con
   ellas, mirá cómo usan el producto, arreglá lo que rompan.
4. Cuando 10 empresas usen Mejora dos meses seguidos y al menos 5 digan que lo
   recomendarían, **prendé el cobro**.
5. A las fundadoras se les cobra recién al mes 4, con su precio bloqueado.

Cobrar antes de saber si el producto retiene es cobrar por un producto que no conocés.
La bandera existe precisamente para que esa decisión sea tuya y de un clic, no un deploy.
