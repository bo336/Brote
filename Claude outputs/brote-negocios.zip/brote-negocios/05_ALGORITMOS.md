# 05 · Algoritmos

> Los cuatro mecanismos que deciden si esto es un producto serio o un directorio más:
> **niveles de evidencia**, **orden del catálogo**, **realismo de objetivos** y
> **progreso**. Todo con números concretos. Nada acá es "a criterio del implementador".

---

## 1. Por qué estos algoritmos y no otros

Los dos problemas que planteaste tienen forma matemática:

**Problema A — "que los productos cumplan de verdad sin reducir mucho la oferta".**
Un filtro binario resuelve la credibilidad y mata la oferta. Un ranking gradual resuelve
las dos: **nada se excluye por falta de trayectoria, todo se ordena por evidencia.**
La exclusión queda reservada para la violación, no para la novedad.

**Problema B — "objetivos reales, ni infantiles ni inalcanzables".**
Esto es un problema de **calibración**, y la calibración necesita un ancla externa. El
ancla es SBTi: **4,2% anual**. Todo lo demás se deriva de ahí.

---

## 2. Definiciones

| Símbolo | Qué es |
|---|---|
| `C` | Credibilidad de un listado (0-1) |
| `F` | Ajuste al usuario / fit (0-1) |
| `A` | Actividad del negocio (0-1) |
| `S` | Salud de servicio (0-1) |
| `X` | Empujón de exploración (0-1, decae) |
| `P` | Penalizaciones (0-1, resta) |
| `score` | Valor materializado en `listings.score` |

---

## 3. Motor de niveles de evidencia

### 3.1 Nivel de una afirmación

Se evalúa **por afirmación**, nunca por empresa (regla D2 · antihalo).

```
nivel(afirmacion) =
  e3  si  tiene certificacion del registro
          Y cert_numero no es nulo
          Y (cert_vence es nulo O cert_vence >= hoy)
          Y la certificacion habilita ese claim_kind
          Y el revisor la aprobo

  e2  si  la empresa tiene verificacion de identidad FUERTE
          Y hay evidencia_path con documento
          Y el revisor la aprobo
          Y pasa el validador de calificadores obligatorios

  e1  si  pasa el validador de calificadores obligatorios
          Y el revisor la aprobo

  e0  en cualquier otro caso  (no se muestra)
```

**"Verificación fuerte"** = método `dominio_meta`, `dominio_dns`, `dominio_archivo` o
`email_dominio`. `social_token` es media. `cuit_declarado` no es verificación.

**"Habilita ese claim_kind"** es la comprobación que cierra el hueco más grande: un
certificado FSC no puede sostener una afirmación de "libre de parabenos". La columna
`certifications.claims[]` lo hace explícito y el revisor no tiene que saberlo de memoria.

### 3.2 Tier efectivo de un listado

```
tier_efectivo(listing) = MAX( nivel(c) para c en listing_claims )
                         y 'e1' si no tiene afirmaciones aprobadas
```

**Importante:** es el máximo *entre las afirmaciones de ese listado*. Un listado puede
tener una afirmación en E3 y otra en E1; la ficha muestra **cada afirmación con su
nivel**, y el tier efectivo solo se usa para el orden. Nunca se muestra "producto E3"
como si todo el producto estuviera certificado.

### 3.3 Tier de la empresa

```
e4  si  tier_empresa >= e3
        Y ciclos_cerrados_con_evidencia >= 2
        Y reportes_confirmados_abiertos = 0
        Y ultima_revision > hoy - 12 meses
e3  si  existe al menos una afirmacion aprobada y vigente en e3
e2  si  verificacion fuerte  Y  al menos una afirmacion en e2
e1  si  status = 'approved'
e0  en otro caso
```

Se recalcula en el job diario y en cada evento que pueda moverlo (aprobación de
afirmación, vencimiento de certificado, cierre de objetivo aprobado, reporte
confirmado).

### 3.4 Credibilidad `C`

```
C = base(tier_efectivo) × cobertura × frescura_evidencia
```

| tier | base |
|---|---|
| e1 | 0.35 |
| e2 | 0.65 |
| e3 | 0.90 |
| e4 (empresa) | +0.10 al listado, tope 1.0 |

```
cobertura = 0.7 + 0.3 × (afirmaciones_aprobadas / afirmaciones_declaradas)
```

Castiga al listado que declara cinco cosas y probó una. Nunca baja de 0.7: declarar
más no puede ser peor que declarar menos, o nadie declararía nada.

```
frescura_evidencia = 1.0                       si revisado hace < 12 meses
                     0.9                       12-24 meses
                     0.8                       > 24 meses
```

**Por qué el 0.35 de E1 no es más bajo:** con 0.15 un negocio declarado nunca aparece y
no hay catálogo. Con 0.35 aparece, pero un E3 con la misma relevancia siempre le gana.
Ese es el equilibrio exacto que pediste.

---

## 4. Orden del catálogo

### 4.1 La fórmula

```
score = 100 × ( 0.40·C + 0.25·F + 0.15·A + 0.10·S + 0.10·X ) − P
```

Los pesos suman 1. **La credibilidad pesa más que todo lo demás junto salvo el fit**,
que es lo que hace que este catálogo sea distinto de un directorio pago.

### 4.2 `F` — Fit (0-1)

Personalizado cuando hay usuario, genérico cuando no.

```
F = 0.45·afinidad_dominio + 0.25·cercania + 0.20·relevancia_categoria + 0.10·completitud
```

- `afinidad_dominio` — intersección entre `listing.dominios` y los intereses del perfil
  (`profiles.interests`, que ya existe). Sin sesión: 0.5.
- `cercania` — 1.0 si `online`; si es local, 1.0 misma ciudad, 0.7 misma provincia,
  0.3 fuera. Reutiliza `profiles.city` (que hoy guarda provincias, ver deuda F15.4 del
  repo — **usá la columna, no el nombre**).
- `relevancia_categoria` — 1.0 si el usuario filtró esa categoría o si viene de una
  acción mapeada; 0.6 en navegación libre.
- `completitud` — tiene imagen, descripción > 200 caracteres, precio de referencia.

### 4.3 `A` — Actividad (0-1)

```
A = 0.4·frescura_listado + 0.3·participacion_mejora + 0.3·respuesta
```

- `frescura_listado` — `exp(-dias_desde_actualizacion / 120)`. Un listado que nadie tocó
  en un año se hunde solo.
- `participacion_mejora` — `progreso_mejora / 100`. **Acá es donde el programa de
  objetivos se convierte en visibilidad**, y es el argumento de venta central: mejorar
  te hace visible.
- `respuesta` — reportes de `no_responde` / `enlace_roto` resueltos a tiempo.

### 4.4 `S` — Salud de servicio (0-1)

```
S = 0.5·salud_enlace + 0.3·(1 − tasa_reportes) + 0.2·señal_ctr
```

- `salud_enlace` — 1.0 con 0 fallos, 0.5 con 1, 0 con 2+.
- `tasa_reportes` — reportes confirmados / clics, ventana 90 días, tope 1.
- `señal_ctr` — clics / impresiones normalizado contra la mediana de su categoría.
  **Requiere ≥50 impresiones**; por debajo de eso vale 0.5 (neutro). Sin ese piso el
  ruido de los primeros días decide el ranking.

> **Lo que NO medimos: ventas.** No las vemos y no queremos verlas. Medir solo el clic
> saliente es una limitación real y hay que ser honestos sobre ella con la empresa en
> el panel de analítica.

### 4.5 `X` — Empujón de exploración (0-1)

El mecanismo que evita que el catálogo se congele.

```
X = exp(-dias_desde_publicacion / 7)      durante los primeros 21 días
X = 0                                      después
```

Día 0: 1.0. Día 7: 0.37. Día 21: 0.05. Aporta como máximo 10 puntos del score, lo que
alcanza para que un listado nuevo aparezca en la primera pantalla sin desplazar a un E3
consolidado. **Es exactamente lo que hace que un negocio nuevo pague la cuota el
segundo mes.**

### 4.6 `P` — Penalizaciones (resta directa)

| Situación | Resta |
|---|---|
| Certificación vencida hace < 30 días | 5 |
| Certificación vencida hace > 30 días | 15 |
| Reporte de afirmación abierto | 20 |
| Reporte confirmado en 90 días | 30 |
| Enlace caído (2 fallos) | 25 |
| Sin actualizar en > 12 meses | 10 |
| Suscripción en gracia | 15 |

Con suscripción `vencida` el listado ya no está publicado, así que no puntúa.

### 4.7 Re-ordenación por diversidad

Después de traer la página ordenada por `score`, en el servidor de Next:

```ts
// Mismo patrón que el re-rank de fuentes de noticias (migración 0019).
const vistos = new Map<string, number>();
const salida = [];
for (const item of candidatos) {
  const n = vistos.get(item.negocio.slug) ?? 0;
  item.scoreAjustado = item.score * Math.pow(0.7, n);
  vistos.set(item.negocio.slug, n + 1);
}
salida.push(...candidatos.sort((a, b) => b.scoreAjustado - a.scoreAjustado));
```

Con el factor 0.7 el tercer listado de un mismo negocio vale 49% de su score. En la
práctica: rarísimo ver 3 seguidos de la misma empresa, y **nunca hace falta un límite
duro** que produciría huecos raros cuando hay poca oferta.

### 4.8 Cuándo se recalcula

`score` está materializado. Se recalcula:

- En el job diario, para todo lo publicado.
- **Inmediatamente** al: publicar, aprobar una afirmación, vencer un certificado,
  confirmar un reporte, cambiar de estado la suscripción, cerrar un objetivo aprobado.

`F` **no** está materializado: es por usuario. Se aplica en la capa de servidor sobre
los candidatos que devolvió el RPC. Materializar `0.40·C + 0.15·A + 0.10·S + 0.10·X − P`
y sumar `0.25·F` en vivo es lo que hace que el catálogo sea a la vez personalizado y
rápido.

---

## 5. Realismo de objetivos

> El algoritmo que hace que un objetivo sea profesional. **Corre siempre**, sobre lo que
> devuelva la IA y sobre lo que salga del catálogo de palancas. Un objetivo que no lo
> pasa nunca se le muestra a la empresa.

### 5.1 El ancla

SBTi exige a una PyME **4,2% × (año objetivo − año base)** de contracción absoluta.
De ahí:

| Horizonte | Reducción esperada en métrica continua | Máximo permitido |
|---|---|---|
| Trimestral | **1,0% – 2,0%** | 8% |
| Semestral | **2,0% – 4,0%** | 12% |
| Anual | **4,0% – 8,0%** | 20% |

El **máximo** solo se admite si el objetivo es un **evento único y discreto** que la
empresa declaró factible (cambiar un proveedor, reemplazar la luminaria, cambiar el
envase). Un cambio de proveedor puede mover 20% de golpe; una campaña de concientización
interna no.

Para objetivos de **sustitución** (porcentaje de SKU, de compras o de envíos que
cambian), la banda es **10% – 25% por ciclo**, porque son escalones, no curvas.

### 5.2 Las diez reglas, en código

```ts
// lib/mejora/realismo.ts
export function validarObjetivo(g: ObjetivoPropuesto, ctx: Dossier): Resultado {
  const fallos: string[] = [];

  // R1 · Esfuerzo acotado. La regla que evita que sea la tarea principal.
  if (g.esfuerzo_horas_mes > 6) fallos.push('esfuerzo_excede_6h');
  if (sumaEsfuerzoActivos(ctx) + g.esfuerzo_horas_mes > 12) fallos.push('carga_total_excede_12h');

  // R2 · Máximo 3 activos.
  if (contarActivos(ctx) >= 3) fallos.push('demasiados_activos');

  // R3 · Ambición dentro de banda.
  const delta = Math.abs((g.linea_base - g.objetivo) / g.linea_base);
  const [min, max] = BANDAS[g.horizonte];
  if (g.origen_base !== 'a_medir') {
    if (delta < min) fallos.push('ambicion_insignificante');
    if (delta > max && !g.es_evento_unico) fallos.push('ambicion_irreal');
  }

  // R4 · Sin línea de base, el objetivo es medir.
  if (g.origen_base === 'a_medir' && g.metrica_tipo === 'reduccion')
    fallos.push('reduccion_sin_base');

  // R5 · Respeta la restricción de inversión declarada.
  if (ctx.restricciones.presupuesto === 'ninguno' && g.inversion !== 'ninguna')
    fallos.push('requiere_inversion_no_declarada');

  // R6 · Nada fuera de control del negocio.
  if (FUERA_DE_CONTROL.some(p => g.titulo.toLowerCase().includes(p)))
    fallos.push('fuera_de_control');

  // R7 · Nada que ya hicieron.
  if (solapaConYaHecho(g, ctx.ya_hecho)) fallos.push('ya_realizado');

  // R8 · Método de medición con un instrumento que ya tienen.
  if (!METODOS_VALIDOS.includes(g.metodo_tipo)) fallos.push('medicion_no_disponible');

  // R9 · Alcance 3 se mide, no se pone como meta.
  if (g.alcance === 3 && g.metrica_tipo === 'reduccion') fallos.push('alcance3_como_meta');

  // R10 · Campos completos. Sin excepciones.
  for (const campo of CAMPOS_OBLIGATORIOS)
    if (g[campo] == null || g[campo] === '') fallos.push(`falta_${campo}`);

  return { valido: fallos.length === 0, fallos };
}
```

```ts
const BANDAS = {
  trimestral: [0.010, 0.08],
  semestral:  [0.020, 0.12],
  anual:      [0.040, 0.20],
};

const FUERA_DE_CONTROL = [
  'que el municipio', 'que tus clientes', 'que el gobierno', 'que tus proveedores decidan',
  'lograr que la gente', 'convencer a la ciudad', 'cambiar la legislación',
];

const METODOS_VALIDOS = [
  'factura',        // eléctrica, de gas, de agua
  'conteo',         // unidades, bolsas, viajes
  'pesaje',         // balanza común
  'remito',         // documento de proveedor
  'planilla',       // registro propio
  'foto_fechada',   // evidencia visual con fecha
];
```

**Qué pasa con un objetivo inválido:** se descarta en silencio y se reemplaza por una
palanca del catálogo que sí valide. **Nunca se le muestra a la empresa un objetivo
descartado ni un mensaje de error de la IA.** Si de 5 propuestas quedan 2, se completan
con el catálogo hasta llegar a 3.

### 5.3 Asignación de ambición

```
basico       si  origen_base = 'a_medir'                       (medir es el primer paso)
             o   delta <= banda_min × 1.5
             o   esfuerzo <= 2 h/mes

intermedio   si  delta esta en la banda central
             y   esfuerzo entre 2 y 4 h/mes

avanzado     si  delta >= banda_max × 0.7
             y   requiere cambio estructural (proveedor, equipo, proceso)
             y   confianza != 'baja'
```

Un objetivo `avanzado` con `confianza: baja` es una promesa vacía: se degrada a
`intermedio` con la meta bajada al centro de la banda.

### 5.4 Replanificación

Cuando llega un check-in:

| Tipo | Qué hace el motor |
|---|---|
| `no_llego` + valor alcanzable | Nueva versión con objetivo = valor declarado, si sigue ≥ banda mínima. Si queda por debajo → **extiende el horizonte** en lugar de bajar la meta. Esa preferencia importa: bajar la meta enseña que las metas se negocian; extender el plazo enseña que se cumplen más lento |
| `ya_hecho` con evidencia | Objetivo → `logrado` retroactivo; se propone el escalón siguiente de la misma palanca |
| `ya_hecho` sin evidencia | Se pide la evidencia; no se cierra nada |
| `no_aplica` | `descartado` + una palanca alternativa del mismo dominio |
| `mas_tiempo` | Horizonte sube un escalón, meta **intacta**, ambición se recalcula |
| `avance` | Solo registra progreso, sin cambiar nada |

**Toda replanificación crea una versión nueva con `parent_id` apuntando a la anterior.**
Nada se borra. La ficha del objetivo muestra "Versión 3 · ver historial", y ese historial
es la evidencia de que el programa es serio. También es lo que se audita para E4.

### 5.5 Ejemplos calibrados

Para que quede claro qué es "bueno" y qué no:

| ❌ Mal | Por qué | ✅ Bien |
|---|---|---|
| "Ser carbono neutral este año" | Fuera de banda, sin base, sin método, sin control | "Medir el consumo eléctrico mensual del local durante 3 meses usando las facturas, para tener una línea de base" |
| "Reducí un 5% tu basura" | Sin base, sin método, sin pasos, sin unidad | "Bajar de 6 a 5 bolsas de residuo mixto por semana separando cartón y vidrio, medido contando bolsas los viernes" |
| "Concientizá a tus clientes sobre el ambiente" | Inmedible, fuera de control | "Ofrecer descuento por traer envase propio y registrar cuántos lo usan; meta: 15% de las ventas del mostrador en 3 meses" |
| "Instalá paneles solares" | Inversión no declarada | "Pedir tres presupuestos de eficiencia energética y elegir uno para evaluar el año que viene" (esfuerzo: 2 h, inversión: ninguna) |
| "Reducí 50% las emisiones en 3 meses" | 6× fuera de banda | "Bajar 2% el consumo de gas del horno ajustando el precalentado, comparando facturas de dos bimestres" |

Estos cinco pares van **literalmente dentro del prompt** como ejemplos de contraste
(`06_PROMPTS_IA.md` §2). Es lo que más levanta la calidad del output de un modelo.

---

## 6. Progreso de Mejora

```
progreso = min(100, Σ  peso × multiplicador × 18 × e^(−antigüedad_dias / 540) )

peso          = 1.0 (logrado) | 0.5 (logrado_parcial)
multiplicador = 1.5 (avanzado) | 1.2 (intermedio) | 1.0 (basico)
```

Calibración: **5 a 6 ciclos cerrados llegan a 100**. Media vida de 18 meses: castiga el
abandono sin castigar una pausa estacional (una heladería no cierra objetivos en julio).

El progreso alimenta `A` en el ranking (§4.3) y es un requisito de E4 — pero **nunca
sube un nivel por sí solo**. Eso es intencional: si el esfuerzo comprara nivel, el nivel
dejaría de significar evidencia.

---

## 7. Cómo probar que esto funciona

Van como tests en la Fase 5:

| Prueba | Resultado esperado |
|---|---|
| Listado E1 nuevo vs E3 de un año, mismo fit | E1 aparece en la primera pantalla el día 1; el E3 le gana desde el día 10 |
| Empresa con 8 listados publicados | Máximo 2 seguidos en cualquier página |
| Certificado vence hoy | Afirmación baja a E2, score cae, listado **sigue publicado** |
| Dos reportes de afirmación de dos usuarios distintos | Despublicado automáticamente |
| Diez reportes del mismo usuario | Solo cuenta uno (índice único) |
| Objetivo "reducir 40% en un trimestre" | Rechazado por `ambicion_irreal` y reemplazado |
| Objetivo con `esfuerzo: 20 h/mes` | Rechazado por `esfuerzo_excede_6h` |
| Dossier con presupuesto `ninguno` | Ningún objetivo devuelto exige inversión |
| Dossier sin datos de consumo | El primer objetivo es medir, ambición `basico` |
| Negocio con 6 ciclos cerrados | `progreso_mejora` = 100 |
| Negocio con 6 ciclos cerrados hace 3 años | `progreso_mejora` < 30 |
